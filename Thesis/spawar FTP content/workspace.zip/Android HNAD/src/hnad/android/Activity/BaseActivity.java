package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Service.HnadService;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;


/**
 * This is the base class for all of the other Activities that bind to the {@link HnadService}. This
 * class does all of the basic setup for binding and leaves stub methods to implement any extra set-up.
 * It creates the custom title bar and Listener for the HnadService.
 * 
 * We don't want to instantiate a version of this class since it has no UI
 * defined. That is left to the subclasses.
 * 
 * @author Cory Sohrakoff
 *
 */
public abstract class BaseActivity extends Activity {
	// For debugging
    private static final String TAG = BaseActivity.class.getName();
    private static final boolean D = true;    
    
    // Layout Views
    private TextView mTitle;
    private ProgressBar mProgressBar; // indeterminate progress bar
    
    /**
     * Reference to the HnadService.
     */
    private HnadService mHnadService;
    
    /**
     * Get the HnadService. Could be null.
     * @return HnadService instance, or null.
     */
    protected final HnadService getHnadService() {
    	return mHnadService;
    }
    
    /**
     * This handles the connecting and disconnecting of the service from the UI.
     */
    private final ServiceConnection mConnection = new ServiceConnection() {
		/**
		 * When the service is disconnected, the reference we keep is set to null.
		 * We will also unregister our listener.
		 */
		@Override
		public void onServiceDisconnected(ComponentName className) {
			if (D) Log.i(TAG, "Service disconnected.");
			
			mHnadService = null;
			
			// set disconnected in title
			mTitle.setText(R.string.title_not_connected);
			
			BaseActivity.this.onServiceDisconnected();
			
			// *** weird workaround ***
	    	// reset UI/service binding
			// for some reason if this isn't done after the service is disconnected
			// we won't get a notification when the service connects after the first time
			// even though the documentation for ServiceConnection states that we should
	        boolean bindSuccessful = bindService(new Intent(BaseActivity.this, HnadService.class), mConnection, 0);
	        if (D) Log.d(TAG, "bindSuccessful=" + bindSuccessful);
		}
		
		/**
		 * When the service is connected, the reference to it is set to the service
		 * instance. We will also register our listener with the service.
		 */
		@Override
		public void onServiceConnected(ComponentName className, IBinder service) {
        	if (D) Log.i(TAG, "Service connected.");
			
        	mHnadService = ((HnadService.LocalBinder)service).getService();
			
			// register UI's listener for "callbacks"
			mHnadService.addListener(mListener);
        	
			// update app to service's current state
			setTitleBarForServiceState(mHnadService.getState());
			BaseActivity.this.onServiceConnected(mHnadService);
		}
	};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // Set up the window layout
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.blank); // set blank layout
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.custom_title);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        // Set up the custom title bar
        mTitle = (TextView) findViewById(R.id.title_left_text);
        mTitle.setText(R.string.app_name);
        mTitle = (TextView) findViewById(R.id.title_right_text);
        mTitle.setText(R.string.title_not_connected);
        mProgressBar = (ProgressBar) findViewById(R.id.title_progress_bar);
        
    	// set up UI/service binding
        boolean bindSuccessful = bindService(new Intent(BaseActivity.this, HnadService.class), mConnection, 0);
        if (D) Log.d(TAG, "bindSuccessful=" + bindSuccessful);
    }
    
    /**
     * Use this to set the left-hand title in the custom title bar. (Unless you want to keep the default 
     * title).
     * 
     * @param stringResId Resource id for the string to set in the title bar.
     */
    protected final void setLeftTitle(int stringResId) {
    	TextView leftTitle = (TextView) findViewById(R.id.title_left_text);
    	leftTitle.setText(stringResId);
    }
    
    /**
     * Starts the HnadService subclass. Call this in subclass to start the service.
     * 
     * @param bluetoothAddress Address of the Bluetooth 802.15.4 adapter.
     */
    protected final void startHnadService(String bluetoothAddress) {
    	Intent serviceIntent = new Intent(this, HnadService.class);
    	serviceIntent.putExtra(HnadService.EXTRA_BT_ADDRESS, bluetoothAddress);
    	startService(serviceIntent);
    }
    
    /**
     * Stops the HnadService subclass. Call this in subclass to start the service.
     */
    protected final void stopHnadService() {
    	Intent serviceIntent = new Intent(this, HnadService.class);
    	stopService(serviceIntent);
    }
    
    @Override
    public void onDestroy() {
        // Stop the Bluetooth services
        if(D) Log.e(TAG, "--- ON DESTROY ---");
        
        // unregister the listener
        if (mHnadService != null)
        	mHnadService.removeListener(mListener);
        
        // remove UI/service binding
        unbindService(mConnection);
        
        super.onDestroy();
    }

	/**
	 * Listener to handle service notifications when we are observing.
	 */
	private final HnadService.EventListener mListener = new HnadService.EventListener() {
		@Override
		public void onConnectionStateChanged(final HnadService service, final int connectionState) {
			BaseActivity.this.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					setTitleBarForServiceState(connectionState);
					BaseActivity.this.onConnectionStateChanged(service, connectionState);
				}
			});
		}
		
		@Override
		public void onDataUpdated(final HnadService hnadService, final String deviceUid) {
			BaseActivity.this.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					BaseActivity.this.onDataUpdated(hnadService, deviceUid);
				}
			});
		}
	};
	
	/**
	 * Handles changing the app title bar based on the service's current state.
	 * @param serviceState
	 */
	private void setTitleBarForServiceState(int connectionState) {
		switch (connectionState) {
		case HnadService.STATE_DONE:
			// same as STATE_NONE so fall through
		case HnadService.STATE_NOT_STARTED:
			mTitle.setText(R.string.title_not_connected);
			mProgressBar.setVisibility(View.GONE);
			break;
		case HnadService.STATE_CONNECTING:
			mTitle.setText(R.string.title_connecting);
			mProgressBar.setVisibility(View.VISIBLE);
			break;
		case HnadService.STATE_CONNECTED:
			mTitle.setText(R.string.title_connected);
			mProgressBar.setVisibility(View.GONE);
			break;
		}
	}
	
	/* --- Methods to override for extra functionality in subclasses. --- */
	
	/**
	 * This method does nothing by default. Override to perform actions based on the state of the
	 * HnadService. This runs on the main thread, so it is safe to modify UI from here.
	 * 
	 * @param service
	 * @param connectionState
	 */
	protected void onConnectionStateChanged(HnadService service, int connectionState) {}
	
	/**
	 * This method does nothing by default. Override to perform actions based on the HnadService
	 * receiving new data.
	 * @param hnadService TODO
	 * @param service		HnadService that is making this callback.
	 */
	protected void onDataUpdated(HnadService hnadService, String deviceUid) {}
	
	/**
	 * This method does nothing by default. It is called when the HnadService is
	 * connected to the Activity. This runs on the main thread, so it is safe to modify UI from here.
	 * 
	 * @param service
	 */
	protected void onServiceConnected(HnadService service) {}
	
	/**
	 * This method does nothing by default. It is called when the HnadService is
	 * disconnected from the Activity.
	 */
	protected void onServiceDisconnected() {}
}

