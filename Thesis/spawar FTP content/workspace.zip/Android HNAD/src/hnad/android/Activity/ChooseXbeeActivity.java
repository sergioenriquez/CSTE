/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hnad.android.Activity;

import hnad.android.R;
import hnad.android.ListAdapter.GenericTwoLineItem;
import hnad.android.ListAdapter.TwoLineArrayAdapter;

import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;

/**
 * This Activity appears as a dialog. It lists any paired devices and
 * devices detected in the area after discovery. When a device is chosen
 * by the user, the MAC address of the device is sent back to the parent
 * Activity in the result Intent.
 * 
 * NOTE: This code is largely taken from the Bluetooth Chat example by Google. -Cory Sohrakoff
 */
public class ChooseXbeeActivity extends Activity {
    // Debugging
    private static final String TAG = ChooseXbeeActivity.class.getName();
    private static final boolean D = true;

    // Return Intent extra
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    public static String EXTRA_DEVICE_NAME = "device_name";

    // Member fields
    private BluetoothAdapter mBtAdapter;
    private TwoLineArrayAdapter<GenericTwoLineItem> mPairedDevicesArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup the window
        setContentView(R.layout.device_list);

        // Set result CANCELED incase the user backs out
        setResult(Activity.RESULT_CANCELED);

        // Initialize the button to perform device discovery
        Button scanButton = (Button) findViewById(R.id.button_bt_settings);
        scanButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	// open bluetooth settings
                Intent intent = new Intent();
                intent.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                startActivity(intent);
                finish();
            }
        });

        // Initialize array adapter
        mPairedDevicesArrayAdapter = new TwoLineArrayAdapter<GenericTwoLineItem>(this, null);

        // Find and set up the ListView for paired devices
        ListView pairedListView = (ListView) findViewById(R.id.paired_devices);
        pairedListView.setAdapter(mPairedDevicesArrayAdapter);
        pairedListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View v, int position, long id) {
                // Cancel discovery because it's costly and we're about to connect
                mBtAdapter.cancelDiscovery();

                // Get the device MAC address, which is the last 17 chars in the View
                String name = mPairedDevicesArrayAdapter.getItem(position).line1();
                String address = mPairedDevicesArrayAdapter.getItem(position).line2();

                // Create the result Intent and include the MAC address
                Intent btSettings = new Intent();
                btSettings.putExtra(EXTRA_DEVICE_NAME, name);
                btSettings.putExtra(EXTRA_DEVICE_ADDRESS, address);

                // Set result and finish this Activity
                setResult(Activity.RESULT_OK, btSettings);
                finish();
            }
        });

        // Get local Bluetooth adapter
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        // Get a set of currently paired devices
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();

        // If there are paired devices, add each one to the ArrayAdapter
        if (pairedDevices.size() > 0) {
            findViewById(R.id.no_paired_devices).setVisibility(View.GONE);
            pairedListView.setVisibility(View.VISIBLE);
            for (BluetoothDevice device : pairedDevices) {
                mPairedDevicesArrayAdapter.add(new GenericTwoLineItem(device.getName(), device.getAddress()));
            }
        } else {
            findViewById(R.id.no_paired_devices).setVisibility(View.VISIBLE);
            pairedListView.setVisibility(View.GONE);
        }
    }
}
