package hnad.android.Activity;

import hnad.android.Constants;
import hnad.android.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ConnectionSettingsActivity extends Activity {
	// For debugging
	private static final String TAG = ConnectionSettingsActivity.class.getName();
	private static final boolean D = true;
  
	/*
     * References to views
     */
    
    private TextView mXbeeNameTextView;
    
    /**
     * Request code for choose Xbee acitivity.
     */
    private static final int CHOOSE_XBEE_REQ_CODE = 1;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.connection_settings);
        
        // set up views
        mXbeeNameTextView = (TextView) findViewById(R.id.default_xbee_name);
        Button chooseXbeeButton = (Button) findViewById(R.id.choose);
        
        // set up listeners
        chooseXbeeButton.setOnClickListener(chooseXbeeOnClickListener);
        
        // load settings
        String name = getSharedPreferences(Constants.XBEE_COMM_PREFERENCES, MODE_PRIVATE).getString(Constants.PREF_DEFAULT_XBEE_NAME, null);
        if (name != null)
        	mXbeeNameTextView.setText(name);
    }
    
    /**
     * OnClickListener for the Choose Xbee button.
     */
    private View.OnClickListener chooseXbeeOnClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(ConnectionSettingsActivity.this, ChooseXbeeActivity.class);
			startActivityForResult(intent, CHOOSE_XBEE_REQ_CODE);
		}
	};

	/**
	 * When the Choose Xbee Activity returns, the choice is saved and mXbeeNameTextView is updated.
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == CHOOSE_XBEE_REQ_CODE && resultCode == RESULT_OK) {
			String address = data.getStringExtra(ChooseXbeeActivity.EXTRA_DEVICE_ADDRESS);
			String name = data.getStringExtra(ChooseXbeeActivity.EXTRA_DEVICE_NAME);
			
			// save to prefs
			getSharedPreferences(Constants.XBEE_COMM_PREFERENCES, MODE_PRIVATE).edit()
				.putString(Constants.PREF_DEFAULT_XBEE_ADDR, address)
				.putString(Constants.PREF_DEFAULT_XBEE_NAME, name)
				.commit();
			
			// put name into UI
			mXbeeNameTextView.setText(name);
		} else {
			super.onActivityResult(requestCode, resultCode, data);
		}
	}
    
}
