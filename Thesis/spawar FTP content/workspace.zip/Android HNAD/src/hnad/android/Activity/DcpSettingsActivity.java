package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Dcp.Dcp;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;

public class DcpSettingsActivity extends Activity {
	// For debugging
	private static final String TAG = DcpSettingsActivity.class.getName();
	private static final boolean D = true;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.dcp_settings);
        
        // set up main layout
        CheckBox checkBoxUseEncryption 	= (CheckBox) findViewById(R.id.checkbox_enc_enable);
        
        // set click listeners
        checkBoxUseEncryption.setOnCheckedChangeListener(useEncryptionCheckedListener);
        
        // read current settings
        SharedPreferences prefs = getSharedPreferences(Dcp.PREFERENCES, MODE_PRIVATE);
        checkBoxUseEncryption.setChecked(prefs.getBoolean(Dcp.PREF_USE_ENC, false));
    }
    
    private final CompoundButton.OnCheckedChangeListener useEncryptionCheckedListener = new CompoundButton.OnCheckedChangeListener() {
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			getSharedPreferences(Dcp.PREFERENCES, MODE_PRIVATE).edit()
				.putBoolean(Dcp.PREF_USE_ENC, isChecked)
				.commit();
		}
	};
}
