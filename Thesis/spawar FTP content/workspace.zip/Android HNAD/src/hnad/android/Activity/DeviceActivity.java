package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Dcp.Command;
import hnad.android.Dcp.Device;
import hnad.android.Dcp.Ecoc;
import hnad.android.Service.HnadService;
import hnad.android.Utils.Tuple;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This displays the detailed device info when a device is chosen from the AndroNAD Activity's 
 * ListView. It also updates the devices info if the status changes.
 * 
 * When launching this via Intent, you need to include the device's UID in the Intent as EXTRA_UID.
 * 
 * @author Cory Sohrakoff
 *
 */
public class DeviceActivity extends BaseActivity {
	// For debugging
    private static final String TAG = DeviceActivity.class.getName();
    private static final boolean D = true;
    
    /**
     * Request codes for sub-Activities
     */
    private static final int REQ_CODE_CWT = 0;
    private static final int REQ_CODE_CPI = 1;
    private static final int REQ_CODE_WLN = 2;
    private static final int REQ_CODE_WLA = 3;
    
    private TableLayout mInfoTable;
    
    // The device being viewed
    private Device mDevice;
    
    private String mDeviceUid;
    
    // extra to pass UID to activity via intent when starting
    public static final String EXTRA_UID = "UID";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // Set up activity name in custom title
        setLeftTitle(R.string.device_info);
        
        // set up main layout
        setContentView(R.layout.device_info);
        mInfoTable = (TableLayout) findViewById(R.id.table);
        if (getIntent() != null) {
        	mDeviceUid = getIntent().getStringExtra(EXTRA_UID);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.device_details_menu, menu);
        return true;
    }

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		final MenuItem command = menu.findItem(R.id.send_command);
		
		if (getHnadService() == null || (mDevice != null && mDevice.commandPending()))
			command.setEnabled(false);
		else
			command.setEnabled(true);
		
		final MenuItem log = menu.findItem(R.id.log);
		log.setEnabled(mDeviceUid != null);
		log.setVisible(false);
		
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {	
		switch (item.getItemId()) {
		case R.id.send_command:
			if (getHnadService() != null) {
				createCommandDialog();
			} else {
				Toast.makeText(this, R.string.command_failed_disconnected, Toast.LENGTH_LONG).show();
			}
			return true;
		case R.id.log:
			if (mDeviceUid != null) {
				Intent activity = new Intent(this, LogActivity.class);
				activity.putExtra(LogActivity.EXTRA_UID, mDeviceUid);
				startActivity(activity);
				return true;
			}
		}
        return false;
    }
	
	/**
	 * Create the dialog with a list of commands.
	 * @return
	 */
	private void createCommandDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this)
			.setTitle(R.string.command)
			.setItems(mDevice.getCommandNames(), new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int item) {
					// Commands are issued immediately except for the case where user
					// input is required: ARMT, CWT, CTI, CPI, etc.
					int command = mDevice.getCommands()[item];
					if (D) Log.d(TAG, "Command is " + command);
					
					boolean sendSuccess = true;
					
					switch (command) {
					case Command.UNRESTRICTED_STATUS:
						sendSuccess = mDevice.sendUnrestrictedCmd(Command.unrestrictedStatus());
						break;
					case Command.NOP:
						sendSuccess = mDevice.sendRestrictedCmd(Command.nop());
						break;
					case Command.SMAT:
						sendSuccess = mDevice.sendRestrictedCmd(Command.setMasterAlarm(true));
						break;
					case Command.SMAF:
						sendSuccess = mDevice.sendRestrictedCmd(Command.setMasterAlarm(false));
						break;
					case Command.EL:
						sendSuccess = mDevice.sendRestrictedCmd(Command.eraseLog());
						break;
					case Command.ST:
						sendSuccess = mDevice.sendRestrictedCmd(Command.setTime());
						break;
					case Command.DADC:
						sendSuccess = mDevice.sendRestrictedCmd(Command.dadc());
						break;
					case Command.DAHH:
						sendSuccess = mDevice.sendRestrictedCmd(Command.dahh());
						break;
					case Command.SL:
						sendSuccess = mDevice.sendRestrictedCmd(Command.sendLog());
						break;
					case Command.SLU:
						sendSuccess = mDevice.sendRestrictedCmd(Command.sendLogUnsent());
					case Command.CWT:
						if (mDevice.getDeviceType() == Device.ECOC) {
							sendSuccess = true; // set true for now
							// prompt user for conveyance id
							Intent intent = new Intent(DeviceActivity.this, TripInfoActivity.class);
							intent.putExtra(TripInfoActivity.EXTRA_CMD, command);
							// FIXME one of the few times we need to cast mDevice, try to eliminate in the future
							intent.putExtra(TripInfoActivity.EXTRA_CONVEYANCE, ((Ecoc)mDevice).getConveyanceId());
							startActivityForResult(intent, REQ_CODE_CWT);
						}
						break;
					case Command.CPI:
						if (mDevice.getDeviceType() == Device.ECOC) {
							sendSuccess = true; // set true for now
							// prompt user for conveyance id
							Intent intent = new Intent(DeviceActivity.this, TripInfoActivity.class);
							intent.putExtra(TripInfoActivity.EXTRA_CMD, command);
							// FIXME one of the few times we need to cast mDevice, try to eliminate in the future
							intent.putExtra(TripInfoActivity.EXTRA_CONVEYANCE, ((Ecoc)mDevice).getConveyanceId());
							startActivityForResult(intent, REQ_CODE_CPI);
						}
						break;
					case Command.WLN:
						if (mDevice.getDeviceType() == Device.ECOC) {
							sendSuccess = true; // set true for now
							// prompt user for conveyance id
							Intent intent = new Intent(DeviceActivity.this, WaypointActivity.class);
							intent.putExtra(WaypointActivity.EXTRA_CMD, command);
							startActivityForResult(intent, REQ_CODE_WLN);
						}
						break;
					case Command.WLA:
						if (mDevice.getDeviceType() == Device.ECOC) {
							sendSuccess = true; // set true for now
							// prompt user for conveyance id
							Intent intent = new Intent(DeviceActivity.this, WaypointActivity.class);
							intent.putExtra(WaypointActivity.EXTRA_CMD, command);
							startActivityForResult(intent, REQ_CODE_WLA);
						}
						break;
					default:
						Toast.makeText(DeviceActivity.this, R.string.command_failed_unsupported, Toast.LENGTH_LONG).show();
						// don't set sendSuccess = false because we are showing a more detailed error msg (above)
						break;
					}
					
					// if the command sending failed
					if (!sendSuccess)
						Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
				}
			});

		builder.create().show();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			boolean sendSuccess = false;
			String conveyance;

			float lat;
			float lon;
			int radius;
			
			switch (requestCode) {
			case REQ_CODE_CWT:
				conveyance = data.getStringExtra(TripInfoActivity.EXTRA_CONVEYANCE);
				sendSuccess = mDevice.sendRestrictedCmd(Command.commissionWithTripInfo(conveyance));
				if (!sendSuccess)
					Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
				break;
			case REQ_CODE_CPI:
				conveyance = data.getStringExtra(TripInfoActivity.EXTRA_CONVEYANCE);
				sendSuccess = mDevice.sendRestrictedCmd(Command.changeProvisionInfo(conveyance));
				if (!sendSuccess)
					Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
				break;
			case REQ_CODE_WLN:
				lat = data.getFloatExtra(WaypointActivity.EXTRA_LAT, 0.0f);
				lon = data.getFloatExtra(WaypointActivity.EXTRA_LON, 0.0f);
				radius = data.getIntExtra(WaypointActivity.EXTRA_RADIUS, 0);
				sendSuccess = mDevice.sendRestrictedCmd(Command.newWayPointList(lat, lon, radius));
				if (!sendSuccess)
					Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
				break;
			case REQ_CODE_WLA:
				lat = data.getFloatExtra(WaypointActivity.EXTRA_LAT, 0.0f);
				lon = data.getFloatExtra(WaypointActivity.EXTRA_LON, 0.0f);
				radius = data.getIntExtra(WaypointActivity.EXTRA_RADIUS, 0);
				sendSuccess = mDevice.sendRestrictedCmd(Command.appendWaypointList(lat, lon, radius));
				if (!sendSuccess)
					Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
			
			// if the command sending failed
			if (!sendSuccess)
				Toast.makeText(DeviceActivity.this, R.string.command_failed, Toast.LENGTH_SHORT).show();
		} else {
			if (D) Log.d(TAG, "RESULT_CANCELED");
		}
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * Print the device info to the screen, if available.
	 */
	private void updateDeviceInfo() {
        if (mDevice != null) {
        	// clear table view
        	mInfoTable.removeAllViews();
        	
        	ArrayList<Tuple<String, String>> info = mDevice.getDetails();
        	for (Tuple<String, String> t : info) {
        		TableRow row = (TableRow) getLayoutInflater().inflate(R.layout.table_row, null);
                ((TextView)row.findViewById(R.id.title)).setText(t.getFirst());
                ((TextView)row.findViewById(R.id.description)).setText(t.getSecond());
                
                mInfoTable.addView(row, new TableLayout.LayoutParams(LayoutParams.MATCH_PARENT, 
                		LayoutParams.WRAP_CONTENT));
        	}
        }
	}

	@Override
	protected void onDataUpdated(HnadService hnadService, String deviceUid) {
		super.onDataUpdated(hnadService, deviceUid);
		
		if (deviceUid.equals(mDeviceUid))
			updateDeviceInfo();
	}

	@Override
	protected void onServiceConnected(HnadService service) {
		super.onServiceConnected(service);
		
		mDevice = service.getDevice(mDeviceUid);
		updateDeviceInfo();
	}	
}
