package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Dcp.Device;
import hnad.android.Service.HnadService;
import hnad.android.Utils.Convert;

import java.util.ArrayList;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class LogActivity extends BaseActivity {
	// For debugging
    private static final String TAG = LogActivity.class.getName();
    private static final boolean D = true;
    
    private ListView mLogListView;
    private TextView mEmptyList;
    
    // The device being viewed
    private Device mDevice;
    
    private String mDeviceUid;
    
    // extra to pass UID to activity via intent when starting
    public static final String EXTRA_UID = "UID";
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // Set up activity name in custom title
        setLeftTitle(R.string.device_log);
        
        if (getIntent() != null) {
        	mDeviceUid = getIntent().getStringExtra(EXTRA_UID);
        }
        
        // set up main layout
        setContentView(R.layout.log);
        mEmptyList = (TextView) findViewById(R.id.list_view_empty);
        mLogListView = (ListView) findViewById(R.id.log_list_view);
        ListAdapter logAdapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.row_text_view);
        mLogListView.setAdapter(logAdapter);
        mLogListView.setClickable(false); // make it non-interactive
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.log_menu, menu);
        return true;
    }
    
    

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		final MenuItem clear = menu.findItem(R.id.clear);
		clear.setEnabled(mDevice != null);
		
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {		
        switch (item.getItemId()) {
        case R.id.clear:
        	// clear log
        	if (mDevice != null)
        		mDevice.clearLog();
        }
        return false;
    }
	
	private void updateLogInfo() {
        if (mDevice != null) {
        	ArrayList<byte[]> logs = mDevice.getLogRecords();
        	
    		if (logs.size() == 0) {
    			mLogListView.setVisibility(View.GONE);
    			mEmptyList.setVisibility(View.VISIBLE);
    		} else {   			
    			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
    			for (byte[] log : logs) {
    				adapter.add(Convert.bytesToHexString(log, log.length));
    			}
    			mLogListView.setAdapter(adapter);
    			mEmptyList.setVisibility(View.GONE);
    			mLogListView.setVisibility(View.VISIBLE);
    		}
        }
	}

	@Override
	protected void onDataUpdated(HnadService hnadService, String deviceUid) {
		super.onDataUpdated(hnadService, deviceUid);
		
		if (deviceUid.equals(mDeviceUid))
			updateLogInfo();
	}

	@Override
	protected void onServiceConnected(HnadService service) {
		super.onServiceConnected(service);
		
		mDevice = service.getDevice(mDeviceUid);
		updateLogInfo();
	}
}
