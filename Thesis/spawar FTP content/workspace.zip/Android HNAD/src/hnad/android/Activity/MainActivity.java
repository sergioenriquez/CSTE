package hnad.android.Activity;

import hnad.android.Constants;
import hnad.android.R;
import hnad.android.Dcp.Device;
import hnad.android.ListAdapter.TwoLineArrayAdapter;
import hnad.android.Nad.Xbee.XbeeFrameParser;
import hnad.android.Service.HnadService;

import java.util.HashMap;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This activity handles the UI for the app. It also starts the {@link HnadService}, if not
 * already running.
 * 
 * FIXME start and stop connection needs to not freeze UI
 * 
 * @author Cory Sohrakoff
 *
 */
public class MainActivity extends BaseActivity {
	// For debugging
    private static final String TAG = MainActivity.class.getName();
    private static final boolean D = true;
    
    // Intent request codes
    private static final int REQUEST_CHOOSE_XBEE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    
    private TextView mDisconnected;
    private ListView mDeviceList;
    private TextView mEmptyList;
    
    private HashMap<String, Device> mDevices;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // Set up activity name in custom title
        setLeftTitle(R.string.app_name);
        
        // Set up main views
        setContentView(R.layout.main);
        
	    if (BluetoothAdapter.getDefaultAdapter() == null) {
	    	Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
	        finish();
	    }
	    
	    mDevices = new HashMap<String, Device>();
	    mDisconnected = (TextView) findViewById(R.id.message_disconnected);
	    mDeviceList = (ListView) findViewById(R.id.list_view);
	    mEmptyList = (TextView) findViewById(R.id.list_view_empty);
	    
	    mDeviceList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				Device d = (Device) parent.getItemAtPosition(position); // cast item to device
				
				// fire off intent to view device details
				Intent intent = new Intent(MainActivity.this, DeviceActivity.class);
				intent.putExtra(DeviceActivity.EXTRA_UID, d.getUid());
				startActivity(intent);
			}
		});
    }

    @Override
	protected void onStart() {
		super.onStart();
		
	    if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
	    	Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
	        startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
	    }
	}

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
	public boolean onPrepareOptionsMenu(Menu menu) {    	
		final MenuItem disconnectItem = menu.findItem(R.id.disconnect);
		disconnectItem.setVisible(getHnadService() != null);
		
		final MenuItem settingsItem = menu.findItem(R.id.settings);
		settingsItem.setVisible(getHnadService() == null);
		
		final MenuItem connectCommandItem = menu.findItem(R.id.connect);
		connectCommandItem.setVisible(getHnadService() == null);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.connect:
        	// check if default xbee is set up
        	String btAddr = getSharedPreferences(Constants.XBEE_COMM_PREFERENCES, MODE_PRIVATE).getString(Constants.PREF_DEFAULT_XBEE_ADDR, null);
        	if (btAddr != null) {
        		startHnadService(btAddr);
        	} else {
	        	// Launch the activity to choose xbee if there is no default
	            Intent serverIntent = new Intent(this, ChooseXbeeActivity.class);
	            startActivityForResult(serverIntent, REQUEST_CHOOSE_XBEE);
        	}
        	return true;
        case R.id.disconnect:
        	// Stop service to disconnect
        	stopHnadService();
        	return true;
        case R.id.settings:
			Intent activity = new Intent(this, SettingsActivity.class);
			startActivity(activity);
			return true;
        }
        return false;
    }
	
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CHOOSE_XBEE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                // Get the device MAC address
                String address = data.getExtras()
                                     .getString(ChooseXbeeActivity.EXTRA_DEVICE_ADDRESS);
                // Start service to connect to the device
                startHnadService(address);
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled
            	break;
            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

	@Override
	protected void onDataUpdated(HnadService hnadService, String deviceUid) {
		if (!mDevices.containsKey(deviceUid)) {
			Device d = hnadService.getDevice(deviceUid);
			mDevices.put(deviceUid, d);
		}
		reloadListView();
	}
	
	private void reloadListView() {
		if (mDevices.size() == 0) {
			mDeviceList.setVisibility(View.GONE);
			mEmptyList.setVisibility(View.VISIBLE);
		} else {
			TwoLineArrayAdapter<Device> adapter = new TwoLineArrayAdapter<Device>(this, null);
			for (Device d : mDevices.values()) {
				adapter.add(d);
			}
			mDeviceList.setAdapter(adapter);
			
			mEmptyList.setVisibility(View.GONE);
			mDeviceList.setVisibility(View.VISIBLE);
		}
	}
	
	/* Display different UI depending on if connected or disconnected */

	private void setUiForServiceState(HnadService service, int connectionState) {
		switch (connectionState) {
		case HnadService.STATE_DONE:
			// same as STATE_NONE so fall through
		case HnadService.STATE_NOT_STARTED:
			mDeviceList.setVisibility(View.GONE);
			mEmptyList.setVisibility(View.GONE);
			mDisconnected.setVisibility(View.VISIBLE);
			break;
		case HnadService.STATE_CONNECTING:
			mDisconnected.setVisibility(View.GONE);
			mDeviceList.setVisibility(View.GONE);
			mEmptyList.setVisibility(View.GONE);
			break;
		case HnadService.STATE_CONNECTED:
			mDisconnected.setVisibility(View.GONE);
			for (Device d : service.getAllDevices()) {
				mDevices.put(d.getUid(), d);
			}
			reloadListView();
			break;
		}
		
		Log.e(TAG, "state: " + connectionState);
	}
	
	@Override
	protected void onServiceConnected(HnadService service) {
		super.onServiceConnected(service);
		setUiForServiceState(service, service.getState());
	}

	@Override
	protected void onServiceDisconnected() {
		super.onServiceDisconnected();
		setUiForServiceState(null, HnadService.STATE_DONE);
		mDevices.clear();
	}

	@Override
	protected void onConnectionStateChanged(HnadService service,
			int connectionState) {
		super.onConnectionStateChanged(service, connectionState);
		setUiForServiceState(service, connectionState);
	}
	
	
}