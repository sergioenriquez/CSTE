package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Nad.Nad;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;

public class NadSettingsActivity extends Activity {
	// For debugging
	private static final String TAG = NadSettingsActivity.class.getName();
	private static final boolean D = true;
    
    /*
     * References to views
     */
	
    private LinearLayout mBurstSettingsLayout;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.nad_settings);
        
        // set up views        
        Spinner nadaIntervalSpinner = (Spinner) findViewById(R.id.interval_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, 
        		Nad.NADA_TIME_DELAY_STRING);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nadaIntervalSpinner.setAdapter(adapter);

        CheckBox enableBurstCheckbox = (CheckBox) findViewById(R.id.enable_burst);
        
        mBurstSettingsLayout = (LinearLayout) findViewById(R.id.burst_settings);
        
        Spinner nadaBurstSendSpinner = (Spinner) findViewById(R.id.burst_send_spinner);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, 
        		Nad.NADA_TIME_DELAY_STRING);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nadaBurstSendSpinner.setAdapter(adapter);
        
        Spinner nadaBurstQuietSpinner = (Spinner) findViewById(R.id.burst_quiet_spinner);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, 
        		Nad.NADA_TIME_DELAY_STRING);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nadaBurstQuietSpinner.setAdapter(adapter);
        
        // set up listeners
        nadaIntervalSpinner.setOnItemSelectedListener(intervalSelectedListener);
        enableBurstCheckbox.setOnCheckedChangeListener(enableBurstCheckedListener);
        nadaBurstSendSpinner.setOnItemSelectedListener(sendTimeSelectedListener);
        nadaBurstQuietSpinner.setOnItemSelectedListener(quietTimeSelectedListener);   

        // load saved settings
        SharedPreferences prefs = getSharedPreferences(Nad.PREFERENCES, MODE_PRIVATE);
        enableBurstCheckbox.setChecked(prefs.getBoolean(Nad.PREF_BURST_MODE_ENABLED, false));
        nadaBurstQuietSpinner.setSelection(prefs.getInt(Nad.PREF_NADA_BURST_QUIET_TIME, 0));
        nadaBurstSendSpinner.setSelection(prefs.getInt(Nad.PREF_NADA_BURST_DURATION, 0));
        nadaIntervalSpinner.setSelection(prefs.getInt(Nad.PREF_NADA_INTERVAL, 0));
    }
	
	/**
	 * Called when the Enable Burst Mode button is checked/unchecked.
	 */
    private final CompoundButton.OnCheckedChangeListener enableBurstCheckedListener = new CompoundButton.OnCheckedChangeListener() {
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			getSharedPreferences(Nad.PREFERENCES, MODE_PRIVATE).edit()
				.putBoolean(Nad.PREF_BURST_MODE_ENABLED, isChecked)
				.commit();
			// hide show burst mode settings based on the check
			mBurstSettingsLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
		}
	};
	
	private final OnItemSelectedListener intervalSelectedListener = new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {
			getSharedPreferences(Nad.PREFERENCES, MODE_PRIVATE).edit()
				.putInt(Nad.PREF_NADA_INTERVAL, pos)
				.commit();
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// do nothing
		}
	};
	
	private final OnItemSelectedListener sendTimeSelectedListener = new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {
			getSharedPreferences(Nad.PREFERENCES, MODE_PRIVATE).edit()
				.putInt(Nad.PREF_NADA_BURST_DURATION, pos)
				.commit();
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// do nothing
		}
	};
	
	private final OnItemSelectedListener quietTimeSelectedListener = new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {
			getSharedPreferences(Nad.PREFERENCES, MODE_PRIVATE).edit()
				.putInt(Nad.PREF_NADA_BURST_QUIET_TIME, pos)
				.commit();
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// do nothing
		}
	};
 
}
