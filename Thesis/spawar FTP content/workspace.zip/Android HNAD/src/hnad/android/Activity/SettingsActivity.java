package hnad.android.Activity;

import hnad.android.R;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.widget.TabHost;


public class SettingsActivity extends TabActivity {
	// For debugging
	private static final String TAG = SettingsActivity.class.getName();
	private static final boolean D = true;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.settings);
        
        // Set up activity name in title
        setTitle(R.string.settings);
        
        Resources res = getResources();
        TabHost tabHost = getTabHost();
        TabHost.TabSpec spec;
        Intent intent;
        
        // TODO better icons
        
        // set up tabs
        intent = new Intent().setClass(this, NadSettingsActivity.class);
        spec = tabHost.newTabSpec("Nad").setIndicator(res.getString(R.string.nad_settings), 
        		res.getDrawable(R.drawable.nad)).setContent(intent);
        tabHost.addTab(spec);
        
        intent = new Intent().setClass(this, DcpSettingsActivity.class);
        spec = tabHost.newTabSpec("Dcp").setIndicator(res.getString(R.string.dcp_settings), 
        		res.getDrawable(R.drawable.dcp)).setContent(intent);
        tabHost.addTab(spec);
        
        intent = new Intent().setClass(this, ConnectionSettingsActivity.class);
        spec = tabHost.newTabSpec("Connection").setIndicator(res.getString(R.string.connection_settings), 
        		res.getDrawable(R.drawable.antenna)).setContent(intent);
        tabHost.addTab(spec);
        
        // default selection to first tab
        tabHost.setCurrentTab(0);
    }
}
