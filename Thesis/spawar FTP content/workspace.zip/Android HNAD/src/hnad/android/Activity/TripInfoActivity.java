package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Dcp.Command;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

/**
 * Activity to gather information needed to send ARMT, CTI, CWT, or CPI commands.
 * Pass in current device info and command type as extras. New device info will be returned
 * as extras.
 * 
 * @author Cory Sohrakoff
 *
 */
public class TripInfoActivity extends Activity {
	// For debugging
	private static final String TAG = TripInfoActivity.class.getName();
	private static final boolean D = true;
	
	public static final String EXTRA_CMD = "CMD";
    public static final String EXTRA_CONVEYANCE = "CONVEYANCE";
    public static final String EXTRA_MANIFEST = "MANIFEST";
    public static final String EXTRA_SEAL = "SEAL";
    public static final String EXTRA_SENSORS = "SENSORS";
    
    // what the command is
    private int mCommand;
    
    private EditText mSeal;
    private EditText mConveyance;
    private EditText mManifest;
    private Button mDoneButton;
    
    // List of checkboxes to turn on/off sensors
    private CheckBox mSensors;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.trip_info);
        mSeal = (EditText) findViewById(R.id.et_seal);
        mConveyance = (EditText) findViewById(R.id.et_conveyance);
        mManifest = (EditText) findViewById(R.id.et_manifest);
        mDoneButton = (Button) findViewById(R.id.done_button);
        mDoneButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent data = new Intent();
				switch (mCommand) {
				
				// these two return the same data
				case Command.CWT:
				case Command.CPI:
					data.putExtra(EXTRA_CONVEYANCE, mConveyance.getText().toString().trim());
					break;
				default:
					break;
				}
				
				// return data with result OK
				setResult(RESULT_OK, data);
				finish();
			}
		});
        
        // set result canceled unless explicitly set OK when user presses the 
        // done button
        setResult(RESULT_CANCELED);
        
        
        // populate layout with info
        if (getIntent() != null) {
        	Bundle data = getIntent().getExtras();
        	mCommand = data.getInt(EXTRA_CMD, -1);
        	
            String conveyance;
            String manifest;
            String seal;
        	
        	switch (mCommand) {
        	case Command.CWT:
        		setTitle(R.string.cwt);
        		conveyance = data.getString(EXTRA_CONVEYANCE);
        		if (conveyance != null)
        			mConveyance.setText(conveyance);
        		break;
        	case Command.CPI:
        		setTitle(R.string.cpi);
        		conveyance = data.getString(EXTRA_CONVEYANCE);
        		if (conveyance != null)
        			mConveyance.setText(conveyance);
        		break;
			default:
				// failed
				finish();
				break;
			}
        } else {
        	// failed
			finish();
        }
    }	
}
