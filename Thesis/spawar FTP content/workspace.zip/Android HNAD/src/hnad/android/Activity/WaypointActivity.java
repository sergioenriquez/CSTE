package hnad.android.Activity;

import hnad.android.R;
import hnad.android.Dcp.Command;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Activity to gather information needed to send WLN or WLA commands to ECOC.
 * 
 * TODO Later on we may want to allow the user to choose a point and radius from a map.
 * 
 * 			// TODO validate these inputs
			float lat;
			float lon;
			int radius;
 * 
 * @author Cory Sohrakoff
 *
 */
public class WaypointActivity extends Activity {
	// For debugging
	private static final String TAG = WaypointActivity.class.getName();
	private static final boolean D = true;
	
	public static final String EXTRA_CMD = "CMD";
    public static final String EXTRA_LAT = "LAT";
    public static final String EXTRA_LON = "LON";
    public static final String EXTRA_RADIUS = "RADIUS";
    
    // what the command is
    private int mCommand;
    
    private EditText mLat;
    private EditText mLon;
    private EditText mRadius;
    private Button mDoneButton;
    
    // List of checkboxes to turn on/off sensors
    private CheckBox mSensors;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // set up main layout
        setContentView(R.layout.waypoint);
        
        mLat = (EditText) findViewById(R.id.et_lat);
        mLon = (EditText) findViewById(R.id.et_lon);
        mRadius = (EditText) findViewById(R.id.et_radius);

        mDoneButton = (Button) findViewById(R.id.done_button);
        mDoneButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent data = new Intent();
				boolean latValid = false;
				boolean lonValid = false;
				boolean radiusValid = false;
				
				// the behavior for each command is the same so just no need for a switch(mCommand)
				
				// TODO validate lat, lon, and radius
				String latStr = mLat.getText().toString();
				String lonStr = mLon.getText().toString();
				String radiusStr = mRadius.getText().toString();
				
				latValid = true;//latStr.matches("-?[0-9]{4}.[0-9]{3}");
				lonValid = true;//lonStr.matches("-?[0-9]{5}.[0-9]{3}");
				radiusValid = true;//( radiusStr.length() == 4);
				
				if (latValid && lonValid && radiusValid) {
					float lat = Float.parseFloat(latStr);
					float lon = Float.parseFloat(lonStr);
					int radius = Integer.parseInt(radiusStr);
					
					// return data with result OK
					data.putExtra(EXTRA_LAT, lat);
					data.putExtra(EXTRA_LON, lon);
					data.putExtra(EXTRA_RADIUS, radius);
					setResult(RESULT_OK, data);
					finish();
				} else {
					String msg = "";
					
					if (!latValid)
						msg += "latitude ";
					
					if (!lonValid)
						msg += "longitude ";
					
					if (!radiusValid)
						msg += "radius";
					
					// format for the case that lat/lon/radius may show
					msg = msg.trim().replace(' ', '/');
					
					msg += " format invalid.";					
					Toast.makeText(WaypointActivity.this, msg, Toast.LENGTH_LONG).show();
				}
					
			}
		});
        
        // set result canceled unless explicitly set OK when user presses the 
        // done button
        setResult(RESULT_CANCELED);
        
        
        // populate layout with info
        if (getIntent() != null) {
        	Bundle data = getIntent().getExtras();
        	mCommand = data.getInt(EXTRA_CMD, -1);
        	
            String conveyance;
            String manifest;
            String seal;
        	
        	switch (mCommand) {
        	case Command.WLN:
        		setTitle(R.string.wln);
        		break;
        	case Command.WLA:
        		setTitle(R.string.wla);
        		break;
			default:
				// failed
				finish();
				break;
			}
        } else {
        	// failed
			finish();
        }
    }	
}
