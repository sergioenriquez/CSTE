package hnad.android;

import hnad.android.Dcp.Device;

/**
 * This class contains constants and configuration values that don't necessarily
 * fit in any specific class.
 * 
 * @author cory
 *
 */
public class Constants {
	
	/*
	 * Timeout duration for ICD messages/ACKs
	 */
	public static final int TIMEOUT_DURATION				= 6 * 1000; // ms
	
	/*
	 * Maximum number of retries to send message after timeout
	 */
	public static final int MAX_RETRIES						= 5;
	
	/**
	 * Conveyance ID size
	 */
    public static final int CONVEYANCE_ID_SIZE				= 16;
	
	// UID size
	public static final int UID_SIZE						=  8; // in bytes
	
	// device types for the NAD and DCP portion of the HNAD
	public static final byte NAD_DEVICE_TYPE					= Device.FNAD_NON_SECURE; // FIXME FNAD for testing
	public static final byte DCP_DEVICE_TYPE					= Device.DCP; // FIXME DCP for testing
	
	public static final byte[] HNAD_UID = { 0x01, 0x23, 0x45, 0x67, (byte) 0x89, 
											(byte) 0xab, (byte) 0xcd, (byte) 0xef };
	
    /**
     * Preferences file for Xbee Communication.
     */
    public static final String XBEE_COMM_PREFERENCES = "XBEE_COMM_PREFERENCES";
    
    /**
     * Xbee Preferences
     */
    public static final String PREF_DEFAULT_XBEE_ADDR = "DEFAULT_XBEE_ADDR";
    public static final String PREF_DEFAULT_XBEE_NAME = "DEFAULT_XBEE_NAME";
}
