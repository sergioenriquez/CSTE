package hnad.android.Dcp;

import hnad.android.Constants;
import hnad.android.Utils.Convert;

import java.nio.ByteBuffer;

/**
 * This is a helper class that assembles (but does not encrypt) a
 * command as described in fig. 9-12 in the ICD.
 * 
 * @author cory
 *
 */
public final class Command {
	
	/* Restricted command op codes */
	private static final byte OPCODE_NOP		= 0x00;
	private static final byte OPCODE_ACK		= 0x01;
	private static final byte OPCODE_SIS		= 0x02;
	private static final byte OPCODE_ST			= 0x03;
	
	// security device
	private static final byte OPCODE_ARMT		= 0x04;
	// ECoC
	private static final byte OPCODE_CWT		= 0x04;
	
	// security device
	private static final byte OPCODE_CTI		= 0x05;
	// ECoC
	private static final byte OPCODE_CPI		= 0x05;
	
	// ECoc
	private static final byte OPCODE_WLN		= 0x06;
	private static final byte OPCODE_WLA		= 0x07; // waypoint list append
	
	private static final byte OPCODE_DADC		= (byte) 0x80;
	private static final byte OPCODE_DAHH		= (byte) 0x81;
	private static final byte OPCODE_SMAT		= (byte) 0xA1;
	private static final byte OPCODE_SMAF		= (byte) 0xA2;
	private static final byte OPCODE_SLU		= (byte) 0xA3;
	private static final byte OPCODE_SL			= (byte) 0xA4;
	private static final byte OPCODE_EL			= (byte) 0xA5;
	private static final byte OPCODE_NES		= (byte) 0xA6;
	private static final byte OPCODE_NDS		= (byte) 0xA7;
	private static final byte OPCODE_CS			= (byte) 0xA8;
	private static final byte OPCODE_RSC		= (byte) 0xA9; // read sensor config
	private static final byte OPCODE_SP			= (byte) 0xAA; // sensor pairing
	private static final byte OPCODE_SDQ		= (byte) 0xAB; // sensor DB query
	
	/* Unrestricted commands */
	private static final byte OPCODE_UNRESTRICTED_STATUS	= 0x00;
	private static final byte OPCODE_PAIR					= 0x01;
	private static final byte OPCODE_PAIRING_REQ			= 0x02;
	
	/*
	 * Command id's (used to tell UI which commands a device supports).
	 * Different from opcodes because there is op-code overlap.
	 */
	public static final int NOP			= 0;
	public static final int ACK			= 1;
	public static final int SIS			= 2;
	public static final int ST			= 3;
	
	// security device
	public static final int ARMT		= 4;
	// ECoC
	public static final int CWT			= 5;
	
	// security device
	public static final int CTI			= 6;
	// ECoC
	public static final int CPI			= 7;
	
	// ECoc
	public static final int WLN			= 8;
	public static final int WLA			= 9; // waypoint list append
	
	public static final int DADC		= 10;
	public static final int DAHH		= 11;
	public static final int SMAT		= 12;
	public static final int SMAF		= 13;
	public static final int SLU			= 14;
	public static final int SL			= 15;
	public static final int EL			= 16;
	public static final int NES			= 17;
	public static final int NDS			= 18;
	public static final int CS			= 19;
	public static final int RSC			= 20; // read sensor config
	public static final int SP			= 21; // sensor pairing
	public static final int SDQ			= 22; // sensor DB query
	
	public static final int UNRESTRICTED_STATUS	= 23;
	public static final int PAIR				= 24;
	public static final int PAIRING_REQ			= 25;
	
	/**
	 * Get the name of the command id. Device type is required because the command
	 * may be different depending on device, while the command itself remains the same.
	 * 
	 * @param command
	 * @param deviceType 
	 * @return
	 */
	public static String getCommandName(int command, int deviceType) {
		switch (command) {
		case NOP:
			return "Get Restricted Status";
		case ACK:
			return "Acknowledgement";
		case SIS:
			return "Set In-trip State";
		case ST:
			return "Set Time";
		case ARMT:
			return "ARM w/ Trip Info";
		case CWT:
			return "Commission w/ Trip Info";
		case CTI:
			return "Change Trip Info";
		case CPI: 
			return "Change Provision Info";
		case WLN:
			return "New Waypoint List";
		case WLA:
			return "Append Waypoint List";
		case DADC:
			if (deviceType == Device.ECOC)
				return "Decommission";
			else
				return "Disarm";
		case DAHH:
			if (deviceType == Device.ECOC)
				return "Decommission";
			else
				return "Disarm";
		case SMAT:
			return "Master Alarm True";
		case SMAF:
			return "Master Alarm False";
		case SLU:
			return "Get Unsent Event Records";
		case SL:
			return "Get All Event Records";
		case EL:
			return "Erase Event Records";
		case NES:
			return "Enable Sensor(s)";
		case NDS:
			return "Disable Sensor(s)";
		case CS:
			return "Configure Sensor(s)";
		case RSC:
			return "Get Sensor Config";
		case SP:
			return "Sensor Pairing";
		case SDQ:
			return "Query Sensor Database";
		case UNRESTRICTED_STATUS:
			return "Get Unrestricted Status";
		case PAIR:
			return "Pair";
		case PAIRING_REQ:
			return "Pairing Request";
		default:
			return "Unknown command";
		}
	}
	
	/**
	 * Create an ACK for the specified ascension number.
	 * 
	 * @param ascensionNumber
	 * @return
	 */
	public static byte[] ack(long ascensionNumber) {
		final byte[] cmd = { OPCODE_ACK, (byte) ascensionNumber };
		return cmd;
	}

	/**
	 * Create the send unrestricted status command.
	 * 
	 * @return
	 */
	public static byte[] unrestrictedStatus() {
		final byte[] cmd = { OPCODE_UNRESTRICTED_STATUS }; // the command is only an opcode.
		return cmd;
	}
	
	public static byte[] nop() {
		final byte[] cmd = { OPCODE_NOP }; // the command is only an opcode.
		return cmd;
	}
	
	/**
	 * Create the set master alarm true/false command.
	 * @param setting true/false for the master alarm
	 * @return
	 */
	public static byte[] setMasterAlarm(boolean setting) {
		final byte[] cmd = { (byte) (setting ? OPCODE_SMAT : OPCODE_SMAF) }; // the command is only an opcode
		return cmd;
	}
	
	/**
	 * Create the erase log command.
	 * 
	 * @return
	 */
	public static byte[] eraseLog() {
		final byte[] cmd = { (byte) OPCODE_EL }; // the command is only an opcode.
		return cmd;
	}
	
	/**
	 * Create a command to set the device's time to the current time (UTC) on this system.
	 * @return
	 */
	public static byte[] setTime() {
		byte[] utc = Convert.nowToIcdTime();
		
		ByteBuffer buf = ByteBuffer.allocate(1 + utc.length); // opcode + UTC bytes
		buf.put((byte) OPCODE_ST);
		buf.put(utc);
		
		buf.flip();
		final byte[] cmd = new byte[buf.remaining()];
		buf.get(cmd, 0, cmd.length);
		return cmd;
	}
	
	/**
	 * Create a disarm/decommission command.
	 * 
	 * @return
	 */
	public static byte[] dadc() {
		final byte[] cmd = { (byte) OPCODE_DADC }; // the command is only an opcode.
		return cmd;
	}
	
	/**
	 * Create a disarm/decommission command.
	 * 
	 * @return
	 */
	public static byte[] dahh() {
		final byte[] cmd = { (byte) OPCODE_DAHH }; // the command is only an opcode.
		return cmd;
	}
	
	/**
	 * Create the commission with trip information command.
	 * @param conveyanceId limited to 15 characters
	 * 
	 * @return
	 */
	public static byte[] commissionWithTripInfo(String conveyanceId) {
		ByteBuffer buf = ByteBuffer.allocate(1 + Constants.CONVEYANCE_ID_SIZE);
		buf.put((byte) OPCODE_CWT);
		buf.put((byte) 0x00); // ISO6346 format
		
		int len = conveyanceId.length();
		if (len > Constants.CONVEYANCE_ID_SIZE - 1) // trim string if necessary to fit
			buf.put(conveyanceId.substring(0, Constants.CONVEYANCE_ID_SIZE).getBytes()); // trim string to [0,CONVEYANCE_ID_SIZE)
		else
			buf.put(conveyanceId.getBytes());
		
		// zero-pad if needed
		for (; len < Constants.CONVEYANCE_ID_SIZE - 1; len++)
			buf.put((byte) 0x00);
		
		buf.flip();
		final byte[] cmd = new byte[buf.remaining()];
		buf.get(cmd, 0, cmd.length);
		return cmd;
	}
	
	/**
	 * Create the change provision info command.
	 * 
	 * @param conveyanceId Limited to 15 characters
	 * @return
	 */
	public static byte[] changeProvisionInfo(String conveyanceId) {
		ByteBuffer buf = ByteBuffer.allocate(1 + Constants.CONVEYANCE_ID_SIZE);
		buf.put((byte) OPCODE_CPI);
		buf.put((byte) 0x00); // ISO6346 format
		
		int len = conveyanceId.length();
		if (len > Constants.CONVEYANCE_ID_SIZE - 1) // trim string if necessary to fit
			buf.put(conveyanceId.substring(0, Constants.CONVEYANCE_ID_SIZE).getBytes()); // trim string to [0,CONVEYANCE_ID_SIZE)
		else
			buf.put(conveyanceId.getBytes());
		
		// zero-pad if needed
		for (; len < Constants.CONVEYANCE_ID_SIZE - 1; len++)
			buf.put((byte) 0x00);
		
		buf.flip();
		final byte[] cmd = new byte[buf.remaining()];
		buf.get(cmd, 0, cmd.length);
		return cmd;
	}
	
	/**
	 * Created a new waypoint list command. This function assumes the arguments are 
	 * already zero padded.
	 * 
	 * @param lat
	 * @param lon
	 * @param radius
	 * @return
	 */
	public static byte[] newWayPointList(float lat, float lon, int radius) {
		byte[] location = Convert.commandLocationToBytes(lat, lon, radius);
		
		ByteBuffer buf = ByteBuffer.allocate(1 + location.length);
		buf.put((byte) OPCODE_WLN);
		buf.put(location);
		
		buf.flip();
		final byte[] cmd = new byte[buf.remaining()];
		buf.get(cmd, 0, cmd.length);
		return cmd;
	}
	
	/**
	 * Created an append waypoint list command. This function assumes the arguments are 
	 * already zero padded.
	 * 
	 * @param lat
	 * @param lon
	 * @param radius
	 * @return
	 */
	public static byte[] appendWaypointList(float lat, float lon, int radius) {
		byte[] location = Convert.commandLocationToBytes(lat, lon, radius);
		
		ByteBuffer buf = ByteBuffer.allocate(1 + location.length);
		buf.put((byte) OPCODE_WLA);
		buf.put(location);

		buf.flip();
		final byte[] cmd = new byte[buf.remaining()];
		buf.get(cmd, 0, cmd.length);
		return cmd;
	}
	
	public static byte[] sendLog() {
		final byte[] cmd = { (byte) OPCODE_SL }; // the command is only an opcode.
		return cmd;
	}
	
	public static byte[] sendLogUnsent() {
		final byte[] cmd = { (byte) OPCODE_SLU }; // the command is only an opcode.
		return cmd;
	}
}
