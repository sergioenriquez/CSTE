package hnad.android.Dcp;

import hnad.android.Utils.Convert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.util.Log;

/**
 * This class implements the DCP (Data Center) portion of the HNAD.
 * 
 * @author cory
 *
 */
public class Dcp {
	// For debugging
    private static final String TAG = Dcp.class.getName();
    private static final boolean D = true;
    
    private DcpListener mListener;
    
    //private MessageReceiver mMessageReceiver;
    
    /**
     * For encrypting messages
     */
    private final boolean mEncryptionEnabled;

    protected boolean encryptionEnabled() {
    	return mEncryptionEnabled;
    }
    
    /**
     * Must be created on the main thread since it uses a handler for timers
     * 
     * @param hnadService
     * @param settings map containing encryption settings
     */
	public Dcp(DcpListener listener, Map<String, ?> settings) {
		mListener = listener;
		mDevices = new HashMap<String, Device>();
		
		// encryption enabled and key is set
		if (settings.containsKey(PREF_USE_ENC)) {
			mEncryptionEnabled = (Boolean) settings.get(PREF_USE_ENC);
		} else {
			mEncryptionEnabled = false;
		}
	}
	
	public void start() {
		/*
		if (mMessageReceiver == null) {
			mMessageReceiver = new MessageReceiver();
			mMessageReceiver.start();
		} */
	}
	
	public void stop() {
		/*
		if (mMessageReceiver != null) {
			mMessageReceiver.stopRunning();
			mMessageReceiver = null;
		} */
	}
	
	public void processInputMessage(byte[] message) {
		/*
		if (mMessageReceiver != null) {
			if (D) Log.d(TAG, "Received message from NAD");
			mMessageReceiver.enqueue(message);
		} else {
			if (D) Log.w(TAG, "Receive queue not running message. Ignored.");
		} */
		
		try {
			Message msg = new Message();
			msg.set(message);
			Device device = getDevice(msg.getDeviceUid()); // look up device
			
			boolean successful = true;
			
			if (device == null) {	
				device = addDevice(msg.getDeviceUid(), msg.header.deviceType);
				if (D) Log.v(TAG, "New device..." + device.getUid());
			}
			successful = device.parseIcdMessage(msg);
		
			if (successful) {
				mListener.onDeviceUpdated(device.getUid());
				if (D) Log.v(TAG, device.getUid() + " updated.");
			} else {
				if (D) Log.w(TAG, "Unable to parse ICD message. discarding...");
			} 
		} catch (IllegalArgumentException e) {
			Log.w(TAG, "Received invalid ICD message! discarding...", e); 
		}
	}
	
	protected boolean sendToNad(String uid, byte[] message) {
		if (D) Log.d(TAG, "Sending to " + uid + ": " + 
				Convert.bytesToHexString(message, message.length));
		return mListener.onSendMessage(uid, message);
	}
	
	protected void commandTimeout(String deviceUid) {
		mListener.onCommandTimeout(deviceUid);
	}
	
	protected void logTimeout(String deviceUid) {
		mListener.onLogTimeout(deviceUid);
	}
	
	/**
	 * Handles ICD messages received in order.
	 * 
	 * @author Cory Sohrakoff
	 *
	 */ /*
	private class MessageReceiver extends hnad.android.Utils.TaskQueue<byte[]> {
		@Override
		protected void onDequeue(byte[] object) {
			try {
				Message message = new Message();
				message.set(object);
				Device device = getDevice(message.getDeviceUid()); // look up device
				
				boolean successful = true; /*
				// if not found add the device to the table
				if (device == null) {
					device = addDevice(message.getDeviceUid(), message.header.deviceType);
					// FIXME hack in order to rekey/reset ascensions if we've never seen the device before
					device.sendRekeyMessage();
					if (D) Log.v(TAG, "New device...message ignored...rekey message sent.");
				} else {
					successful = device.parseIcdMessage(message);
				} */ /*
			
				if (device == null) {	
					device = addDevice(message.getDeviceUid(), message.header.deviceType);
					if (D) Log.v(TAG, "New device..." + device.getUid());
				}
				successful = device.parseIcdMessage(message);
			
				if (successful) {
					mListener.onDeviceUpdated(device.getUid());
					if (D) Log.v(TAG, device.getUid() + " updated.");
				} else {
					if (D) Log.w(TAG, "Unable to parse ICD message. discarding...");
				} 
			} catch (IllegalArgumentException e) {
				Log.w(TAG, "Received invalid ICD message! discarding...", e); 
			}
		}	
	} */
	
	/**
	 * Connected devices.
	 * 
	 * TODO still need some timeout mechanism to clear old entries. or possibly just 
	 * move the entries an inactive section to differentiate them for the user. the user can
	 * then clear inactive entries themselves if they want.
	 */
	private HashMap<String, Device> mDevices;
	
	public Device getDevice(String uid) {
		synchronized (mDevices) {
			if (mDevices != null && uid != null)
				return mDevices.get(uid);
			else
				return null;	
		}
	}
	
	public ArrayList<Device> getDevices() {
		synchronized (mDevices) {
			return new ArrayList<Device>(mDevices.values());
		}
	}
	
	
	/**
	 * Adds a device to database.
	 * @param uid
	 * @param deviceType
	 * @return Newly created device.
	 */
	private Device addDevice(String uid, int deviceType) {
		Device device = null;
		synchronized (mDevices) {
			if (mDevices != null) {
				switch (deviceType) {
				case Device.ACSD:
				case Device.CSD:
					if (D) Log.v(TAG, "Creating new SecurityDevice...");
					// security device
					//device = new SecurityDevice(uid, deviceType, this);
					//mDevices.put(uid, device);
					break;
				case Device.ECOC:
					if (D) Log.v(TAG, "Creating new Ecoc...");
					device = new Ecoc(uid, this);
					mDevices.put(uid, device);
					break;
				default:
					String error = "Cannot create device entry for unknown device type: " + deviceType
					+ ". (UID: " + uid + ")";
					Log.e(TAG, error);
					break;
				}
			}
		}
		return device;
	}	

	/* ******* Constants ******* */
	
    /**
     * The preferences "file" edited by the Settings Activity.
     */
    public static final String PREFERENCES = "DCP_PREFERENCES";
    
    /*
     * Preference keys.
     */
    
    public static final String PREF_USE_ENC = "USE_ENC";
}
