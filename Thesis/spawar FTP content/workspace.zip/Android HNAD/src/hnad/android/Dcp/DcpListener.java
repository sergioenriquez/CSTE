package hnad.android.Dcp;

/**
 * Interface to receive updates/bytes to send from the Dcp.
 * 
 * @author cory
 *
 */
public interface DcpListener {
	
	/**
	 * Send a DCP message to the device with the specified UID.
	 * 
	 * @param uid
	 * @param message
	 * 
	 * @return whether or not the send was successful
	 */
	public boolean onSendMessage(String deviceUid, byte[] message);
	
	/**
	 * Called when a command from the DCP to a device fails due to all
	 * retry attempts being exhausted.
	 * 
	 * @param deviceUid
	 */
	public void onCommandTimeout(String deviceUid);
	
	/**
	 * Called when the DCP fails to receive a log message within the specified timeout.
	 * 
	 * @param deviceUid
	 */
	public void onLogTimeout(String deviceUid);
	
	/**
	 * Called when the state information of a device is updated.
	 * 
	 * @param deviceUid
	 */
	public void onDeviceUpdated(String deviceUid);
	
	/**
	 * Called when a device has been inactive for too long and is removed 
	 * from the list of devices kept within the DCP.
	 * 
	 * @param deviceUid
	 */
	public void onDeviceExpired(String deviceUid);
}
