package hnad.android.Dcp;

import hnad.android.Constants;
import hnad.android.ListAdapter.TwoLineArrayAdapterItem;
import hnad.android.Utils.Convert;
import hnad.android.Utils.Crypto;
import hnad.android.Utils.Tuple;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Log;

/**
 * This is the base class of all ICD devices. It handles
 * the message parsing based on the specific the device type and performs a callback to
 * notify the {@link Dcp} when the device state information has changed.
 * 
 * It provides method stubs in order to parse a selection of security messages. This class
 * is primarily designed to be used as a base class for on-conveyance devices such as
 * the ACSD, CSD, and ECOC. Callbacks are performed to the Dcp to send messages/commands.
 * 
 * FIXME need to save device data offline (ascension #s). double check command op codes.
 * 
 * @author cory
 *
 */
public abstract class Device implements TwoLineArrayAdapterItem {
	// For debugging
    private static final String TAG = Device.class.getName();
    private static final boolean D = true;
    
    /*
     * Device type constants.
     */
    public static final byte ACSD				= (byte) 0x80;
    public static final byte CSD				= (byte) 0x81;
    public static final byte ECOC				= (byte) 0x82;
    public static final byte AOS				= (byte) 0x83;
    public static final byte ECM				= (byte) 0x84;
    public static final byte FNAD_NON_SECURE	= (byte) 0x85;
    public static final byte HNAD_SECURE		= (byte) 0x86;
    public static final byte FNAD_SECURE		= (byte) 0x87;
    public static final byte DCP				= (byte) 0x88;
    public static final byte KMF				= (byte) 0x89;
    public static final byte HNAD_NON_SECURE	= (byte) 0x90;
    public static final byte FNAD_NON_ROOT		= (byte) 0x91;
    
    /**
     * Get the device type as a String.
     * 
     * @return
     */
    public String getDeviceTypeString() {
    	switch (mDeviceType) {
    	case CSD:
    		return "CSD Type 0";
    	case ACSD:
    		return "ACSD Type 0";
    	case ECOC:
    		return "ECoC Type 0";
    	default:
    			// just print hex value of other device types
    			return String.format("0x%02X", mDeviceType);
    	}
    }
    
    /**
     * Reference to Dcp in order to send out commands.
     */
    protected final Dcp mDcp;
    
    /**
     * The UID of this device as a hex-string (without the 0x prefix).
     */
    private final String mUid; 
    
    /**
     * The device type.
     */
    private final byte mDeviceType;
    
    protected boolean mCmdPending;
    protected byte[] mLastCmd;
    protected byte[] mLastAck;
    
    private byte[] mLtk = null;
    
    protected synchronized byte[] getLtk() {
    	return mLtk;
    }
    
    public synchronized boolean commandPending() {
    	return mCmdPending;
    }
    
    /**
     * Last status
     */
    protected Calendar mLastStatusTime;
    
    /*
     * Ascension numbering
     */
    private int mReceiveAscensionNum;
    private int mSendAscensionNum;
    
    protected long getSendAscension() {
    	return (long)mSendAscensionNum & 0xFFFFFFFFL;
    }
    
    protected long getReceiveAscension() {
    	return (long)mReceiveAscensionNum & 0xFFFFFFFFL;
    }
    
    protected void setSendAscension(byte[] ascension) {
    	mSendAscensionNum = Convert.bytesToInt(ascension);
    }
    
    protected void setReceiveAscension(byte[] ascension) {
    	mReceiveAscensionNum = Convert.bytesToInt(ascension);
    }
    
    /*
     * Command retry timer
     */
    private Timer mRetryTimer;
    
    /**
     * Runnable that will fire if the Device is inactive for a
     * specified amount of time.
     * 
     * FIXME the DCP should do this not the device
     */
    private Runnable mInactivityTimer;
    
    protected boolean mWaitingForFirstLog = true;
    
    /**
     * Timeout timer when receiving log messages
     */
    private Timer mLogTimeoutTimer;
    
    private ArrayList<byte[]> mLogRecords = new ArrayList<byte[]>();
    
    public void clearLog() {
    	synchronized (mLogRecords) {
    		mLogRecords.clear();
		}
    }
    
    protected void appendLog(byte[] record) {
    	synchronized (mLogRecords) {
    		mLogRecords.add(record);
		}
    }
    
    /**
     * Returns a deep copy of the log records.
     * 
     * FIXME not very optimized
     * 
     * @return
     */
    public ArrayList<byte[]> getLogRecords() {
    	ArrayList<byte[]> copy = new ArrayList<byte[]>();
    	synchronized (mLogRecords) {
			for (byte[] record : mLogRecords)
				copy.add(record.clone());
		}
    	return copy;
    }
    
    /*
     * General status info. Has nothing to do with ICD. It's more of a queue for the UI
     * to let it know if something is wrong.
     */
    protected int mStatus;
    
    /*
     * Status constants
     */
    public static final int STATUS_UNKNOWN	= 0; // status has not been received yet.
    public static final int STATUS_OK		= 1; // status is ok
    public static final int STATUS_ALARM	= 2; // status for security breach
    
    /**
     * The time the last status message was received. An implment
     */
    private long mLastActive;
    
    
    
    public synchronized long getTimeLastActive() {
		return mLastActive;
	}

	private synchronized void setTimeLastActive() {
		mLastActive = System.currentTimeMillis();
	}

	/**
     * Get the general status of this device.
     * 
     * @return A status constant defined in this class.
     */
    public synchronized int getStatus() {
    	return mStatus;
    }
    
    /**
     * Get the UID of this device as a hex-string (without the 0x prefix).
     * 
     * @return
     */
    public final String getUid() {
		return mUid;
	}

    /**
     * Get the type of this device. Type constants are defined in this class. Subclasses should set device type based on the
     * type associated with them.
     * 
     * @return
     */
	public byte getDeviceType() {
		return mDeviceType;
	}


	/**
     * Create a Device. Called by subclasses. Subclasses should set device type based on the
     * type associated with them.
     * 
     * @param uid
     * @param deviceType
     * @param listener
     */
    public Device(String uid, byte deviceType, Dcp dcp) {
    	mUid = uid;
    	mDeviceType = deviceType;
    	mDcp = dcp;
    	
    	mSendAscensionNum = 0;
    	mReceiveAscensionNum = 0;
    }
	
	/**
	 * Parses the ICD message.
	 * 
	 * TODO Should validate based on message size as well.
	 * 
	 * @param message Message object.
	 * @return True if message updated the Device info. False if not.
	 */
	protected final boolean parseIcdMessage(Message message) {
		boolean ret = false;
		switch (message.header.messageType) {
		case Message.UNRESTRICTED_STATUS:
			if (D) Log.d(TAG, "parsing USM");
			ret = parseUnrestrictedStatus(message);
			break;
		case Message.RESTRICTED_STATUS:
			if (D) Log.d(TAG, "parsing RSM");
			ret = parseRestrictedStatus(message);
			break;
		case Message.EVENT_LOG_RECORD:
			if (D) Log.d(TAG, "parsing log");
			ret = parseEventLogRecord(message);
		default:
			if (D) Log.w(TAG, "Unable to parse unknown message type: " + message.header.messageType);
			break;
		}
		
		// if parsing the message was successful, set now as the time last active
		if (ret) 
			setTimeLastActive();
		
		return ret;
	}
	
	/**
	 * Parses a restricted status message. Should return true if message changes device info.
	 * 
	 * @param message
	 * @return
	 */
	protected abstract boolean parseRestrictedStatus(Message message);
	
	/**
	 * Parses an unrestricted status message. Should return true if message changes device info.
	 * 
	 * @param message
	 * @return
	 */
	protected abstract boolean parseUnrestrictedStatus(Message message);
	
	/**
	 * Parses an event log CSDrecord. Should return true if message changes device info.
	 * 
	 * @param message
	 * @return
	 */
	protected abstract boolean parseEventLogRecord(Message message);
	
	/**
	 * Send a restricted command, the first byte is the op-code.
	 * 
	 */
	public boolean sendRestrictedCmd(byte[] command) {		
		boolean isAck = (command[0] == Command.ACK); // if cmd opcode is ACK
		
		// synchronize to update fields
		synchronized (this) {
			if (isAck || !mCmdPending) {
				int ascension = mSendAscensionNum + 1;
				
				Message message = new Message();
				message.header = new Header();
				message.header.messageType = Message.DEVICE_RESTRICTED_CMD;
				message.header.setAscensionNum(ascension);
				
				// copy command into message
				byte[] payload = new byte[command.length + Crypto.MIC_SIZE]; // command + MIC
				System.arraycopy(command, 0, payload, 0, command.length);
				
				byte[] encrypted;
				if (mDcp.encryptionEnabled()) {
					// encrypt
					try {
						encrypted = Crypto.encrypt(mLtk, Crypto.MIC_SIZE * 8, message.getNonce(), command);
					} catch (Exception e) {
						Log.e(TAG, "Encryption error for restricted command.", e);
						return false; // command failed since encryption failed
					}
				} else {
					// if no encryption, just keep command how it is
					encrypted = command;
				}
				
				// copy encrypted data into payload
				System.arraycopy(encrypted, 0, payload, 0, encrypted.length);
				
				message.payload = payload;
				message.header.length = (byte) payload.length;
				byte[] msg;
				
				try {
					msg = message.get();
				} catch (Exception e) {
					Log.e(TAG, getUid() + ": error getting command bytes.", e);
					return false;
				}
				
				boolean success = mDcp.sendToNad(getUid(), msg);
				if (success) {
					mSendAscensionNum = ascension;
					if (isAck) {
						// will not set command pending or timer if an ACK
						if (D) Log.v(TAG, getUid() + ": sent ACK...");
						mLastAck = msg;
					} else {
						mCmdPending = true;
						mLastCmd = msg;
						startRetryTimer();	
					}
				}
				return success;
			} else {
				if (D) Log.w(TAG, "Command failed: command already pending.");
				return false;
			}
		}
	}
	
	/**
	 * Send an unrestricted command, the first byte is the op-code.
	 * @param command
	 */
	public boolean sendUnrestrictedCmd(byte[] command) {		
		// synchronize to update fields
		synchronized (this) {
			if (!mCmdPending) {
				
				Message message = new Message();
				message.header = new Header();
				message.header.messageType = Message.DEVICE_UNRESTRICTED_CMD;
				message.header.setAscensionNum(0);
				
				// copy command into message
				byte[] payload = new byte[command.length + 1]; // command + checksum
				System.arraycopy(command, 0, payload, 0, command.length);
				
				message.payload = payload;
				message.header.length = (byte) payload.length;
				
				byte[] msg;
				
				try {
					msg = message.get();
				} catch (Exception e) {
					Log.e(TAG, getUid() + ": error getting command bytes.", e);
					return false;
				}
				
				// calculate checksum
				int checksum = 0;
				for (int i = 0; i < msg.length - 1; i++)
					checksum = (checksum + msg[i]) & 0xFF;
				msg[msg.length - 1] = (byte) checksum;
				
				boolean success = mDcp.sendToNad(getUid(), msg);
				if (success) {
					mCmdPending = true;
					mLastCmd = msg;
					startRetryTimer();
				}
				
				return success;
			} else {
				if (D) Log.w(TAG, "Command failed: command already pending.");
				return false;
			}
		}
	}
	
	/**
	 * Send a rekey message. Sent in response to an unsolicited unrestricted status message.
	 * 
	 */
	protected void sendRekeyMessage() {	
		int payloadSize = Crypto.LTK_SIZE + Crypto.REKEY_MIC_SIZE;
		
		Message message = new Message();
		message.header = new Header();
		message.header.messageType = Message.ENCRYPTION_REKEY;
		message.header.length = (byte)payloadSize;
		message.header.setAscensionNum(1);
		
		// derive new key and encrypt
		byte[] nonce = message.getNonce();
		byte[] ltk = new byte[Crypto.LTK_SIZE];
		new Random().nextBytes(ltk);
		
		byte[] tck = null;
		byte[] payload = new byte[payloadSize];
		try {
			tck = Crypto.deriveTck(Crypto.REKEY_KEY, message.header.get());
			payload = Crypto.encrypt(tck, Crypto.REKEY_MIC_SIZE * 8, nonce, ltk);
		} catch (Exception e) {
			Log.e(TAG, getUid() + ": rekey encrpytion failed.");
			return;
		}
		
		message.payload = payload;
		byte[] msg;
		
		try {
			msg = message.get();
		} catch (Exception e) {
			Log.e(TAG, getUid() + ": rekey encrpytion failed.");
			return;	
		}
		
		synchronized (this) {
			// acsension numbers are reset after a TCK is derived
			mLtk = ltk;
			mSendAscensionNum = 0;
			mReceiveAscensionNum = 0;
		}
		
		boolean success = mDcp.sendToNad(getUid(), msg);
		if (!success) {
			if (D) Log.w(TAG, getUid() + ": failed to send rekey message.");
		} else {
			if (D) Log.d(TAG, getUid() + ": sent rekey message.");
		}
	}
	
	protected void resendLastCmd() {
		synchronized (this) {
			mDcp.sendToNad(getUid(), mLastCmd);
		}
	}
	
	protected void resendLastAck() {
		synchronized (this) {
			mDcp.sendToNad(getUid(), mLastAck);
		}
	}
	
	/**
	 * Starts a retry timeout timer for a command.
	 */
	protected void startRetryTimer() {
		// make sure no timer is running
		cancelRetryTimer();
		
		// create the retry timer
		TimerTask t = new TimerTask() {
			
			private int retry = 0;
			
			@Override
			public void run() {
				retry++;
				if (retry > Constants.MAX_RETRIES) {
					if (D) Log.d(TAG, getUid() + ": retries exceeded.");

					// remove command pending and notify command failed
					synchronized (Device.this) {
						mCmdPending = false;
					}
					
					mDcp.commandTimeout(getUid());

					cancel();
				} else {
					if (D) Log.d(TAG, getUid() + ": timeout...resend attempt #" + retry);
					resendLastCmd();
				}
			}
		};
		
		mRetryTimer = new Timer();
		mRetryTimer.schedule(t, Constants.TIMEOUT_DURATION, Constants.TIMEOUT_DURATION);
	}
	
	
	/**
	 * Cancels a timeout timer for a command.
	 */
	protected void cancelRetryTimer() {
		if (mRetryTimer != null) {
			mRetryTimer.cancel();
			mRetryTimer = null;
		}
	}	
	
	protected void startLogTimeoutTimer() {
		// make sure no timer is running
		cancelLogTimeoutTimer();
		
		// create the retry timer
		TimerTask t = new TimerTask() {
			
			@Override
			public void run() {
				// remove command pending and notify command failed
				synchronized (Device.this) {
					mCmdPending = false;
					mWaitingForFirstLog = true;
				}
					
				mDcp.logTimeout(getUid());
			}
		};
		
		mLogTimeoutTimer = new Timer();
		mLogTimeoutTimer.schedule(t, Constants.TIMEOUT_DURATION);
	}
	
	protected void cancelLogTimeoutTimer() {
		if (mLogTimeoutTimer != null) {
			mLogTimeoutTimer.cancel();
			mLogTimeoutTimer = null;
		}
	}
	
	@Override
	public String line1() {
		return "UID: " + getUid();
	}

	@Override
	public String line2() {
		return "Type: " + getDeviceTypeString();
	}

	/**
	 * Returns a summary of the device information in human readable format.
	 * 
	 * This may need to be synchronized depending on what data is accessed. By default this
	 * just returns the UID and device type.
	 * 
	 * @return List containing Device.Info objects to display to the user.
	 */
	public ArrayList<Tuple<String, String>> getDetails() {
		ArrayList<Tuple<String, String>> info = new ArrayList<Tuple<String,String>>();
		
		info.add(new Tuple<String, String>("UID", getUid()));
		info.add(new Tuple<String, String>("Type", getDeviceTypeString()));
		
		return info;
	}
	
	/**
	 * Returns an array of restricted commands that this device supports. (Besides
	 * ACK of course.)
	 *  
	 * @return
	 */
	public abstract int[] getCommands();
	
	/**
	 * Get the names associated with the restricted commands as an array indexed in the
	 * same order as the commands.
	 * 
	 * @return
	 */
	public abstract String[] getCommandNames();
}
