package hnad.android.Dcp;

import hnad.android.Constants;
import hnad.android.Utils.Convert;
import hnad.android.Utils.Crypto;
import hnad.android.Utils.Struct;
import hnad.android.Utils.StructField;
import hnad.android.Utils.Tuple;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;

import android.util.Log;

public final class Ecoc extends Device {
	// For debugging
    private static final String TAG = Ecoc.class.getName();
    private static final boolean D = true;
    
    /*
     * Log event types
     */
    private static final byte END_OF_RECORDS				= (byte) 0xFF;
    /*
     * Enryption error bits
     */
    private static final byte NO_LTK						= (byte) 0x80;
    private static final byte USM_UNSOLICITED				= 0x01;
    
    /*
     * Restricted error section bits
     */
    private static final byte UNSOLICITED_BIT				= 0x02;
    private static final byte TIME_INVALID					= 0x04;
    private static final byte MALFUNCTION_BIT				= (byte) 0x80;
    private static final byte INSUFFICIENT_POWER			= 0x40;
    private static final byte COMMISSION_FAILED				= 0x20;
    
    /*
     * Master alarm bits
     */
    private static final byte LOCK_STATUS_BIT				= (byte) 0x80;
    private static final byte TAMPER_BIT					= 0x40;
    private static final byte ROUTE_DEVIATION_BIT			= 0x20;
    private static final byte SCHEDULE_DEVIATION_BIT		= 0x10;
    
    /*
     * Restricted error bits
     */
    private static final byte SENSOR_MALFUNCTION			= (byte) 0x80;
    private static final byte DECRYPT_ERROR					= 0x40;
    private static final byte INVALID_CMD					= 0x20;
    private static final byte LOG_OVERFLOW					= 0x10;
    private static final byte ACK_FAILURE					= 0x08;
    private static final byte CONFIG_FAILED					= 0x04;
    private static final byte SENSOR_ENABLE_FAILED			= 0x02;
    
    
    /*
     * Sensor error bits
     */
    private static final byte LOCK_SENSOR_ERROR				= 0x01;
    private static final byte GPS_SENSOR_ERROR				= 0x02;
    
    
    private byte mRestrictedErrorSection;
    private byte mDeviceOpMode;
    private byte mRestrictedStatusBits;
    private byte mRestrictedErrorBits;
    private byte mSensorErrorBits;
    private byte[] mConveyanceId;
    private byte[] mGpsLocation;
    private byte mMasterAlarm;
    private byte[] mReserved;
    
    private byte mDeviceSetion;
    private byte mEncryptionErrorBits;
    private byte[] mRekeyCounter;
    private byte[] mProblemUid;
    
    
    /*
     * Op mode bits
     */
    private byte OP_MODE_COMMISSIONED		= 0x01;
    
    /*
     * Restricted status bits
     */
    private byte ALARM_ON					= 0x01;

	public Ecoc(String uid, Dcp dcp) {
		super(uid, Device.ECOC, dcp);
	}

	@Override
	protected boolean parseRestrictedStatus(Message message) {
		boolean retVal = false;
		
		// decrypt payload if neccessary FIXME only do this if ascension number is good
		byte[] payload;		
		if (mDcp.encryptionEnabled()) {
			try {
				payload = Crypto.decrypt(getLtk(), Crypto.MIC_SIZE * 8, message.getNonce(), message.payload);
			} catch (Exception e) {
				// decryption failed so abort parsing message
				Log.e(TAG, getUid() + ": failed to decrypt RSM.");
				return false;
			}
		} else {
			payload = message.payload;
		}
		
		RestrictedStatus rs = new RestrictedStatus();
		
		try {
			rs.set(payload);
		} catch (Exception e) {
			Log.e(TAG, getUid() + ": error parsing RSM", e);
			return false;
		}
		
		boolean isUnsolicited = (rs.restrictedErrorSection & UNSOLICITED_BIT) != 0;
		
		if (D) Log.d(TAG, getUid() + ": received " + (isUnsolicited ? "un" : "") + "soliticed RSM with ascension " + message.header.getAscensionNum());
		
		Calendar utcTime = null;
		if ((rs.restrictedErrorSection & TIME_INVALID) == 0) // if time valid set it
			utcTime = Convert.icdTimeToCalendar(rs.utcTime);
		
		// synchronize to update fields since there could be async access of the data fields
		// by the UI
		synchronized (this) {
			if (message.header.getAscensionNum() > getReceiveAscension()) {
				retVal = true;
	            
	            // update fields
				setReceiveAscension(message.header.ascensionNum);
	            mDeviceOpMode = rs.deviceOperatingMode;
	            mRestrictedErrorSection = rs.restrictedErrorSection;
	            mRestrictedStatusBits = rs.restrictedErrorBits;
	            mRestrictedStatusBits = rs.restrictedStatusBits;
	            mSensorErrorBits = rs.sensorErrorBits;
	            mConveyanceId = rs.conveyanceId;
	            mLastStatusTime = utcTime;
	            mGpsLocation = rs.gpsLocation;
	            mMasterAlarm = rs.masterAlarm;
	            mReserved = rs.reserved;
	            
	            if (isUnsolicited) {
	            	if (commandPending()) {
	            		// FIXME should this happen?
	            		mCmdPending = false;
	            		cancelRetryTimer();
	            		if (D) Log.d(TAG, "Last command to " + getUid() + " has been preempted by an unsolicited status message");
	            	}
	            	
	            	// send ACK
	            	sendRestrictedCmd(Command.ack(getReceiveAscension()));
	            	if (D) Log.v(TAG, "Sent ACK to " + getUid() + " with ascension " + getSendAscension());
	            } else if (commandPending() && (byte)(getSendAscension() & 0xFF) == rs.ackAscensionNum) {
					mCmdPending = false;
					cancelRetryTimer();
					if (D) Log.v(TAG, "Message from " + getUid() + " is a valid response to the previous command.");
				}
			} else if (message.header.getAscensionNum() == getReceiveAscension() && isUnsolicited) {
				if (D) Log.w(TAG, "Duplicate message. Resending ACK to " + getUid() + "...");
				resendLastAck();
			} else {
				if (D) Log.w(TAG, "Expecting ascension " + (getReceiveAscension() + 1) + " from " + getUid() + ", received " + message.header.getAscensionNum() + " instead.");
			}
		}
		
		return retVal;
	}

	@Override
	protected boolean parseUnrestrictedStatus(Message message) {
		boolean retVal = false;
		
		UnrestrictedStatus us = new UnrestrictedStatus();
		
		try {
			us.set(message.payload);
		} catch (Exception e) {
			Log.e(TAG, getUid() + ": error parsing USM.", e);
			return false;
		}
		
		// validate checksum
		byte sum = 0;
		// FIXME better way of doing this
		byte[] msg = message.get();
		for (int i = 0; i < msg.length - 1; i++)
			sum += msg[i];
		
		// print checksum for debug
		if (D) Log.d(TAG, getUid() + ": checksum " + sum + " expected, got " + us.checksum);
		// FIXME for debugging the checksum
		final boolean requireValidChecksum = false;
		
		boolean isUnsolicited = (us.deviceSection & USM_UNSOLICITED) == 0;
		
		if (!requireValidChecksum || sum == us.checksum) {
			retVal = true;
			
			if (D) Log.d(TAG, getUid() + ": received " + (isUnsolicited ? "un" : "") + "soliticed USM with ascension " + us.ascensionNumber);
			
			synchronized (this) {				
				mDeviceSetion = us.deviceSection;
				mEncryptionErrorBits = us.encryptionErrorBits;
				mRekeyCounter = us.rekeyCounter;
				mProblemUid = us.problemUid;
				
				if (commandPending()) {
					if (isUnsolicited) {
		            	if (commandPending()) {
		            		// FIXME should this happen?
		            		if (D) Log.d(TAG, "Last command to " + getUid() + " has been preempted by an unsolicited unrestricted status message");
		            	}
					}
            		mCmdPending = false;
            		cancelRetryTimer();
				}
			}
			
			if ((us.encryptionErrorBits & NO_LTK) != 0) {
				if (D) Log.w(TAG, getUid() + ": no LTK... sending rekey message");
				sendRekeyMessage();
			}
		
		} else {
			if (D) Log.w(TAG, "USM from " + getUid() + " failed checksum.");
		}
		
		return retVal;
	}

	@Override
	protected boolean parseEventLogRecord(Message message) {
		boolean retVal = false;
		
		// decrypt payload if neccessary FIXME only do this if ascension number is good
		byte[] payload;		
		if (mDcp.encryptionEnabled()) {
			try {
				payload = Crypto.decrypt(getLtk(), Crypto.MIC_SIZE * 8, message.getNonce(), message.payload);
			} catch (Exception e) {
				// decryption failed so abort parsing message
				Log.e(TAG, getUid() + ": failed to decrypt Log.");
				return false;
			}
		} else {
			payload = message.payload;
		}
		
		LogRecord lr = new LogRecord();
		
		try {
			lr.set(payload);
		} catch (Exception e) {
			Log.e(TAG, "Error parsing log record.", e);
			return false;
		}
		
		if (D) Log.d(TAG, getUid() + ": received log message with ascension " + message.header.getAscensionNum());
		
		// get data
		Calendar utcTime = Convert.icdTimeToCalendar(lr.eventTime);
		
		// synchronize to update fields since there could be async access of the data fields
		// by the UI
		synchronized (this) {
			if (message.header.getAscensionNum() > getReceiveAscension()) {				
				if (mCmdPending) {
					retVal = true;
					cancelLogTimeoutTimer();					
					
		            // update fields
		            setReceiveAscension(message.header.ascensionNum);
					
					// FIXME just add the whole payload to the log for now
					appendLog(payload);
					
					// if first log 
					if (mWaitingForFirstLog) {
						mWaitingForFirstLog = false;
						if (D) Log.d(TAG, getUid() + ": received first log.");
					}
					
	            	// send ACK
	            	sendRestrictedCmd(Command.ack(getReceiveAscension()));
	            	if (D) Log.v(TAG, "Sent ACK to " + getUid() + " with ascension " + getSendAscension());
					
					// if the last log message
					if ((lr.eventType & END_OF_RECORDS) != 0) {
						if (D) Log.d(TAG, getUid() + ": received last log.");
						mCmdPending = false;
						mWaitingForFirstLog = true;
					} else {
						startLogTimeoutTimer();
					}
				} else {
					if (D) Log.w(TAG, getUid() + ": was not expecting an event log");
				}
			} else if (message.header.getAscensionNum() == getReceiveAscension()) {
				if (D) Log.w(TAG, getUid() + ": duplicate message. Resending ACK to " + getUid() + "...");
				resendLastAck();
			} else {
				if (D) Log.w(TAG, getUid() + ": expecting ascension " + (getReceiveAscension() + 1) + " from " + getUid() + ", received " + message.header.getAscensionNum() + " instead.");
			}
		}
		
		return retVal;
	}

	@Override
	public ArrayList<Tuple<String, String>> getDetails() {
		ArrayList<Tuple<String, String>> info = super.getDetails();

		synchronized (this) {
			if (mLastAck != null) { // if there hasn't been an ACK this means there was no restricted status yet, so don't print this info
				try {
					info.add(new Tuple<String, String>("Conveyance", new String(mConveyanceId, 1, Constants.CONVEYANCE_ID_SIZE - 1, "US-ASCII").trim()));
				} catch (UnsupportedEncodingException e) {
					Log.e(TAG, getUid() + ": error reading conveyance id", e);
				}
				
				info.add(new Tuple<String, String>("Mode", (mDeviceOpMode & OP_MODE_COMMISSIONED) != 0 ? "commissioned" : "decommissioned"));
				info.add(new Tuple<String, String>("Alarm", (mRestrictedStatusBits & ALARM_ON) != 0 ? "ON" : "OFF"));
				info.add(new Tuple<String, String>("Locked", (mMasterAlarm & LOCK_STATUS_BIT) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Tampered", (mMasterAlarm & TAMPER_BIT) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Route Deviation", (mMasterAlarm & ROUTE_DEVIATION_BIT) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Sched Deviation", (mMasterAlarm & SCHEDULE_DEVIATION_BIT) != 0 ? "YES" : "NO"));
				
				info.add(new Tuple<String, String>("Malfunction", (mRestrictedErrorSection & MALFUNCTION_BIT) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Trip Power", (mRestrictedErrorSection & INSUFFICIENT_POWER) != 0 ? "Insufficient" : "OK"));
				info.add(new Tuple<String, String>("Commission Failed", (mRestrictedErrorSection & COMMISSION_FAILED) != 0 ? "YES" : "NO"));
				
				info.add(new Tuple<String, String>("Sensor Malfunction", (mRestrictedErrorBits & SENSOR_MALFUNCTION) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Decrypt Error", (mRestrictedErrorBits & DECRYPT_ERROR) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Invalid Cmd", (mRestrictedErrorBits & INVALID_CMD) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Log", (mRestrictedErrorBits & LOG_OVERFLOW) != 0 ? "Overflow" : "OK"));
				info.add(new Tuple<String, String>("ACK Failure", (mRestrictedErrorBits & ACK_FAILURE) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Config Failed", (mRestrictedErrorBits & CONFIG_FAILED) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("Sensor Enable Failed", (mRestrictedErrorBits & SENSOR_ENABLE_FAILED) != 0 ? "YES" : "NO"));			    
				
				info.add(new Tuple<String, String>("Lock Error", (mSensorErrorBits & LOCK_SENSOR_ERROR) != 0 ? "YES" : "NO"));
				info.add(new Tuple<String, String>("GPS Error", (mSensorErrorBits & GPS_SENSOR_ERROR) != 0 ? "YES" : "NO"));
				
				
				info.add(new Tuple<String, String>("Status UTC", (mLastStatusTime == null ? "invalid" : 
					String.format("%1$tT %1$tF", mLastStatusTime))));
				
				try {
					Tuple<Float, Float> coord = Convert.logLocationToCoordinate(mGpsLocation);
					if (coord != null) {
						info.add(new Tuple<String, String>("Location", String.format("%.5f , %.5f", coord.getFirst(), coord.getSecond())));
					} else {
						info.add(new Tuple<String, String>("Location", String.format("void")));
					}
				} catch (Exception e) {
					Log.e(TAG, getUid() + ": error reading gps location", e);
				}
			}
		}
		
		return info;
		/*
		 * UID
		 * Device type
		 * 
		 * op mode
		 * conveyance id
		 * master alarm on/off
		 * location
		 * status time (if valid)
		 * master alarm status
		 */
	}
	
	public synchronized String getConveyanceId() {
		try {
			return new String(mConveyanceId, 1, Constants.CONVEYANCE_ID_SIZE - 1, "US-ASCII").trim();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return ""; // if error, return empty string
		}
	}

	@Override
	public int[] getCommands() {
		return CMDS;
	}
	
	@Override
	public String[] getCommandNames() {
		return CMD_NAMES;
	}

	/**
	 * Supported restricted commands
	 */
	private static final int[] CMDS 	= {	Command.UNRESTRICTED_STATUS,
											Command.NOP,
											Command.CWT,
											Command.CPI,
											Command.DADC,
											Command.SMAT,
											Command.SMAF,
											Command.ST, /*
											Command.WLN,
											Command.WLA,
											Command.SL,
											Command.SLU,
											Command.EL */};
	
	private static final String[] CMD_NAMES;
	
	/*
	 * Initialize the names statically since they are constants.
	 */
	static {
		CMD_NAMES = new String[CMDS.length];
		for (int i = 0; i < CMD_NAMES.length; i++) {
			CMD_NAMES[i] = Command.getCommandName(CMDS[i], Device.ECOC);
		}
	}
	
	/**
	 * Enables easy parsing of the payload field of a Restricted Status Message.
	 */
	private class RestrictedStatus extends Struct {

		// restricted error section is 1 byte
		
		@StructField(pos=0)
		public byte restrictedErrorSection;
		
		// restricted data section fields
		
		@StructField(pos=1)
		public byte ackAscensionNum;
		
		@StructField(pos=2)
		public byte deviceOperatingMode;
		
		@StructField(pos=3)
		public byte restrictedStatusBits;
		
		@StructField(pos=4)
		public byte restrictedErrorBits;
		
		@StructField(pos=5)
		public byte sensorErrorBits;
		
		@StructField(pos=6, len=16)
		public byte[] conveyanceId;
		
		@StructField(pos=7, len=8)
		public byte[] utcTime;
		
		@StructField(pos=8, len=20)
		public byte[] gpsLocation;
		
		@StructField(pos=9)
		public byte masterAlarm;
		
		@StructField(pos=10, len=16)
		public byte[] reserved;
		
	}
	
	/**
	 * Enables easy parsing of the payload field of a Unrestricted Status Message.
	 */
	private class UnrestrictedStatus extends Struct {
		
		@StructField(pos=0)
	    public byte deviceSection;
		
		@StructField(pos=1)
	    public byte encryptionErrorBits;
		
		@StructField(pos=2, len=4)
		public byte[] rekeyCounter;
	    
		@StructField(pos=3, len=8)
		public byte[] problemUid;
		
		@StructField(pos=4)
	    public byte ascensionNumber;
		
		@StructField(pos=5)
	    public byte checksum;
		
	}
	
	/**
	 * Enables easy parsing of the payload field of a Log Message.
	 */
	private class LogRecord extends Struct {
	    
		@StructField(pos=0)
	    public byte logReqAckNum;
	    
		@StructField(pos=1, len=2)
	    public byte[] eventRecordNum;
	    
		@StructField(pos=2)
	    public byte eventType;
	    
		@StructField(pos=3, len=8)
	    public byte[] eventTime;

		@StructField(pos=4)
	    public byte reserved;
	    
		@StructField(pos=5)
	    public byte deviceOperatingMode;
	    
		@StructField(pos=6)
	    public byte restrictedStatusBits;

		@StructField(pos=7)
	    public byte restrictedErrorBits;
	    
		@StructField(pos=8, len=16)
	    public byte[] conveyanceId;
	    
		@StructField(pos=9, len=20)
		public byte[] gpsLocation;
		
		@StructField(pos=10)
		public byte masterAlarm;
		
	}
}
