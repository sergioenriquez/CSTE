package hnad.android.Dcp;

import hnad.android.Constants;
import hnad.android.Utils.Convert;
import hnad.android.Utils.Struct;
import hnad.android.Utils.StructField;

public class Header extends Struct {
	
	@StructField(pos=0)
	public byte deviceType = Constants.DCP_DEVICE_TYPE;
	
	@StructField(pos=1)
	public byte messageType;
	
	@StructField(pos=2)
	public byte length;
	
	@StructField(pos=3, len=8)
	public byte[] uid = Constants.HNAD_UID;
	
	@StructField(pos=4)
	public byte icdRevNum = ICD_REV_NUM;
	
	@StructField(pos=5, len=4)
	public byte[] ascensionNum;
	
	/**
	 * ICD revision number used by this application.
	 */
	public static final byte ICD_REV_NUM	= 0x02;
	
	/**
	 * Returns the message ascension number from the header as a long value.
	 * 
	 * @return
	 */
	public long getAscensionNum() {
		int temp = Convert.bytesToInt(ascensionNum);
		return (long)temp & 0xFFFFFFFFL;
	}
	
	/**
	 * Sets the message ascension bytes from an int value.
	 * 
	 * @param ascension
	 */
	public void setAscensionNum(int ascension) {
		ascensionNum = Convert.intToBytes(ascension);
	}
	
}
