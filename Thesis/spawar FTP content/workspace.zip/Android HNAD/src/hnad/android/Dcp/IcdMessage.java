package hnad.android.Dcp;

import hnad.android.Constants;
import hnad.android.Utils.Convert;

import java.nio.ByteBuffer;

/**
 * This class helps to parse an ICD message by splitting the message into payload and header.
 * The Universal Message Header is then parsed and is accessible through this class.
 * 
 * @author cory
 *
 */
public class IcdMessage {
	// For debugging
    private static final String TAG = IcdMessage.class.getName();
    private static final boolean D = true;
	
	/*
	 * Constants for message types.
	 */
	public static final int UNRESTRICTED_STATUS			= 0x00;
	public static final int RESTRICTED_STATUS			= 0x80;
	public static final int EVENT_LOG_RECORD			= 0x81;
	public static final int SENSOR_DISCOVERY_BROADCAST	= 0xA0;
	public static final int SENSOR_DB_REPORT			= 0xA1;
	public static final int SENSOR_STATUS				= 0xA2;
	public static final int AOS_DEVICE_SENSOR_CONFIG	= 0xA3;
	public static final int DEVICE_NAD_SENSOR_CONFIG	= 0xA4;
	public static final int DEVICE_UNRESTRICTED_CMD		= 0xC0;
	public static final int DEVICE_RESTRICTED_CMD		= 0xC1;
	public static final int SENSOR_RESTRICTED_CMD		= 0xC2;
	public static final int ENCRYPTION_REKEY			= 0xE0;
	public static final int NADA						= 0xFF;

	/**
	 * The message bytes
	 */
	private byte[] mMessage;
	
	/*
	 * Constants for data offsets in message
	 */
	private static final int DEVICE_TYPE_OFFSET		= 0;
	private static final int MESSAGE_TYPE_OFFSET	= 1;
	private static final int MESSAGE_LENGTH_OFFSET	= 2;
	private static final int DEVICE_UID_OFFSET		= 3;
	private static final int ICD_REV_NUM_OFFSET		= 11;
	private static final int ASCENSION_NUM_OFFSET	= 12;
	
	public static final int HEADER_SIZE			= 16; // bytes
	
	public static final int ICD_REV_NUM			= 0x02;
	
	/**
	 * Parse the bytes into an ICD message.
	 * 
	 * @throws IllegalArgumentException if the message is too short or of inconsistent length.
	 * @param message
	 */
	private IcdMessage(byte [] message) {
		// message must be at least as big as a header
		if (message.length < HEADER_SIZE) {
			throw new IllegalArgumentException("message cannot be shorter than header size");
		}
		
		//
		int length = message[MESSAGE_LENGTH_OFFSET] & 0xFF;
		
		// check that the reported payload length and actual length are the same
		if (length != message.length - HEADER_SIZE) {
			throw new IllegalArgumentException("message has invalid length. Expected " +
					(length + HEADER_SIZE) + " bytes, but got " + message.length + " bytes.");
		}
		
		// save message bytes
		mMessage = message;		
	}
	
	/**
	 * Create a new ICD message with the specified payload.
	 * 
	 * @param msgType
	 * @param ascensionNum
	 * @param msg
	 */
	private IcdMessage(int msgType, long ascensionNum, byte[] msg) {
		ByteBuffer buffer = ByteBuffer.allocate(127); // maximum packet size for 802.15.4
		
		Header header = new Header();
		header.messageType = (byte) msgType;
		header.deviceType = (byte) Constants.DCP_DEVICE_TYPE;
		header.deviceUid = Constants.HNAD_UID;
		header.messageAscensionNumber = ascensionNum;
		header.messageLength = (byte) (msg.length);
		header.icdRevNumber = ICD_REV_NUM;
		
		buffer.put(header.getBytes());
		buffer.put(msg);
		
		buffer.flip();
		mMessage = new byte[buffer.remaining()];
		buffer.get(mMessage, 0, mMessage.length);
	}
	
	/**
	 * Create a new ICD message with an empty payload of specified length.
	 */
	private IcdMessage(int msgType, long ascensionNum, int payloadSize) {
		this(msgType, ascensionNum, new byte[payloadSize]);
	}
	
	/**
	 * Returns the device type field from the message header.
	 * @return
	 */
	public int getDeviceType() {
		return mMessage[DEVICE_TYPE_OFFSET] & 0xFF;
	}
	
	/**
	 * Returns the message type field from the message header.
	 * @return
	 */
	public int getMessageType() {
		return mMessage[MESSAGE_TYPE_OFFSET] & 0xFF;
	}
	
	/**
	 * Returns the ICD revision number from the message header.
	 * @return
	 */
	public int getIcdRevNum() {
		return mMessage[ICD_REV_NUM_OFFSET] & 0xFF;
	}
	
	/**
	 * Returns the device UID from the message header as a hex-string (without the 0x prefix).
	 * 
	 * @return
	 */
	public String getDeviceUid() {
		byte[] temp = new byte[Constants.UID_SIZE];
		System.arraycopy(mMessage, DEVICE_UID_OFFSET, temp, 0, temp.length);
		return Convert.bytesToHexString(temp, temp.length);
	}
	
	/**
	 * Returns the message ascension number from the header. It is a 4-byte value which is converted
	 * to an int.
	 * 
	 * @return
	 */
	public long getAscensionNum() {
		// FIXME
		byte[] temp = new byte[4];
		System.arraycopy(mMessage, ASCENSION_NUM_OFFSET, temp, 0, temp.length);
		return Convert.bytesToInt(temp);
	}
	
	/**
	 * Returns a copy of the raw message.
	 * 
	 * @return
	 */
	public byte[] getBytes() {
		return mMessage.clone();
	}
	
	/**
	 * Gets the message minus the header.
	 * 
	 * @return
	 */
	public byte[] getPayload() {
		byte[] payload = new byte[mMessage.length - HEADER_SIZE];
		System.arraycopy(mMessage, HEADER_SIZE, payload, 0, payload.length);
		return payload;
	}
	
	/**
	 * Gets the message header.
	 * 
	 * @return
	 */
	public byte[] getHeader() {
		byte[] header = new byte[HEADER_SIZE];
		System.arraycopy(mMessage, 0, header, 0, header.length);
		return header;
	}
	
	/**
	 * Gets the nonce for this message (for encryption/decryption)
	 * 
	 * @return
	 */
	public byte[] getNonce() {
		byte[] nonce = new byte[HEADER_SIZE - Constants.UID_SIZE]; // nonce is header minus UID
		// copy parts of header
		System.arraycopy(mMessage, 0, nonce, 0, 3);
		System.arraycopy(mMessage, ICD_REV_NUM, nonce, 3, nonce.length - 3);
		return nonce;
	}
	
	/**
	 * Wrapper class to pass header data around easily. Also provides convenience of
	 * writing a message header to a byte array.
	 * 
	 * @author Cory Sohrakoff
	 *
	 */
	private class Header {
		public byte deviceType;
		public byte messageType;
		public byte messageLength;
		public byte[] deviceUid;
		public byte icdRevNumber;
		public long messageAscensionNumber; // ascension is 4 bytes
		
		@Override
		public String toString() {
			return  "DeviceType=0x" + String.format("%02X", deviceType) + 
					",MessageType=0x" + String.format("%02X", messageType) + 
					",MessageLength=" + messageLength + 
					",DeviceUID=" + Convert.bytesToHexString(deviceUid, deviceUid.length) + 
					",ICDRevNumber=" + icdRevNumber + 
					",MessageAscensionNumber=" + messageAscensionNumber;
		}
		
		/**
		 * Dump the header to its byte representation.
		 * 
		 * @param bytes
		 * @param offset
		 */
		public byte[] getBytes() {
			byte[] bytes = new byte[HEADER_SIZE];
			bytes[DEVICE_TYPE_OFFSET] = deviceType;
			bytes[MESSAGE_TYPE_OFFSET] = messageType;
			bytes[MESSAGE_LENGTH_OFFSET] = messageLength;
			System.arraycopy(deviceUid, 0, bytes, DEVICE_UID_OFFSET, deviceUid.length);
			bytes[ICD_REV_NUM_OFFSET] = icdRevNumber;
			// TODO fix long
			byte[] ascension = Convert.intToBytes((int)messageAscensionNumber);
			System.arraycopy(ascension, 0, bytes, ASCENSION_NUM_OFFSET, ascension.length);
			return bytes;
		}
	}
}
