package hnad.android.Dcp;

import hnad.android.Utils.Convert;
import hnad.android.Utils.Struct;
import hnad.android.Utils.StructField;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class Message extends Struct {

	@StructField(pos=0)
	public Header header;
	
	@StructField(pos=1)
	public byte[] payload;
	
	/**
	 * Returns the device UID from the message header as a hex-string (without the 0x prefix).
	 * 
	 * @return UID string or null if UID not set.
	 */
	public String getDeviceUid() {
		if (header != null && header.uid != null) {
			return Convert.bytesToHexString(header.uid, header.uid.length);
		}
		
		return null;
	}
	
	/**
	 * Gets the nonce for this message (for encryption/decryption)
	 * 
	 * @return
	 */
	public byte[] getNonce() {
		ByteArrayOutputStream nonce = new ByteArrayOutputStream();
		
		// nonce is header minus UID
		nonce.write(header.deviceType);
		nonce.write(header.messageType);
		nonce.write(header.length);
		nonce.write(header.icdRevNum);
		try {
			nonce.write(header.ascensionNum);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return nonce.toByteArray();
	}

	
	/*
	 * Constants for message types.
	 */
	public static final byte UNRESTRICTED_STATUS		= (byte) 0x00;
	public static final byte RESTRICTED_STATUS			= (byte) 0x80;
	public static final byte EVENT_LOG_RECORD			= (byte) 0x81;
	public static final byte SENSOR_DISCOVERY_BROADCAST	= (byte) 0xA0;
	public static final byte SENSOR_DB_REPORT			= (byte) 0xA1;
	public static final byte SENSOR_STATUS				= (byte) 0xA2;
	public static final byte AOS_DEVICE_SENSOR_CONFIG	= (byte) 0xA3;
	public static final byte DEVICE_NAD_SENSOR_CONFIG	= (byte) 0xA4;
	public static final byte DEVICE_UNRESTRICTED_CMD	= (byte) 0xC0;
	public static final byte DEVICE_RESTRICTED_CMD		= (byte) 0xC1;
	public static final byte SENSOR_RESTRICTED_CMD		= (byte) 0xC2;
	public static final byte ENCRYPTION_REKEY			= (byte) 0xE0;
	public static final byte NADA						= (byte) 0xFF;
}
