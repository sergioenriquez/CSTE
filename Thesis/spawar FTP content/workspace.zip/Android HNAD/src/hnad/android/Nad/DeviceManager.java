package hnad.android.Nad;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.LinkedBlockingQueue;

import android.util.Log;

/**
 * This class handles sending messages and putting them into message
 * waiting if necessary. Optionally, this notifies of a send failure
 * via a callback.
 * 
 * @author cory
 *
 */
public class DeviceManager {
	// For debugging
    private static final String TAG = DeviceManager.class.getName();
    private static final boolean D = true;
	
    private static final long MAC_TIMEOUT	= 2100; // ms
    private static final long MW_TIMEOUT	= 60000; // ms
    private static final long FRAME_TIMEOUT	= 3000; // ms
	
	/**
	 * Lock to synchronize access
	 */
	private Object mLock = new Object();

	/**
	 * List of available frame IDs
	 */
	private LinkedBlockingQueue<Byte> mAvailableIds = new LinkedBlockingQueue<Byte>();
	
	/**
	 * Table of devices awaiting TX status. Hashed by frame ID.
	 */
	private HashMap<Byte, Device> mFrames = new HashMap<Byte, Device>();
	
    /**
     * Table of devices. Hashed by UID.
     */
	private HashMap<String, Device> mDeviceTable = new HashMap<String, Device>();
	
	/**
	 * List head for NADA message waiting.
	 */
	private Device mListHead;
	
	/**
	 * Window head for NADA message waiting.
	 */
	private Device mWindowHead;
	
	/**
	 * Timer to run timeout tasks
	 */
	private Timer mTimer = new Timer();
	
	private Callback mCallback;
	
	public DeviceManager(DeviceManager.Callback callback) {
		mCallback = callback;
		
		// populate the queue with frame IDs
		for (int i = 1; i < 256; i++)
			mAvailableIds.add((byte)i);
	}
	
	/**
	 * Stops the timer for the DeviceManager. This should be done in order to
	 * gracefully close the application.
	 */
	public void stopTimer() {
		synchronized (mLock) {
			mTimer.cancel();	
		}
	}
	
	/**
	 * Add the UID to MAC address mapping.
	 * 
	 * @param uid
	 * @param mac
	 */
	public void putMac(String uid, byte[] mac) {
		synchronized (mLock) {
			Device d;
			// a re-insert just updates the mac and resets the timer
			if (mDeviceTable.containsKey(uid)) {
				d = mDeviceTable.get(uid);
			} else {
				d = new Device(uid);
				mDeviceTable.put(uid, d);
			}
			
			synchronized (d) {
				d.mMac = mac;
				d.setMacTimeout();
			}
		}
	}
	
	/**
	 * Get the MAC address for the device.
	 * 
	 * @param uid
	 * @return
	 */
	private byte[] getMac(String uid) {
		byte[] mac = null;
		synchronized (mLock) {
			Device d = mDeviceTable.get(uid);
			if (d != null)
				synchronized (d) {
					mac = d.mMac;
				}
		}
		return mac;
	}
	
	/**
	 * Will send the message directly or using message waiting. Both will if be
	 * used if the message fails to send initially. 
	 * 
	 * @param uid
	 * @param msg
	 */
	public void sendMsg(String uid, byte[] msg) {
		
	}
	
	/**
	 * Removes the entry from all of the different tables kept.
	 * 
	 * @param e
	 */
	public void remove(Device e) {
		synchronized (mLock) {
			mDeviceTable.remove(e.mUid);
		}
	}
	
	private class Device {
		byte			mId;
		boolean			mIsMessageWaiting;
		String			mUid;
		byte[]			mMsg;
		byte[]			mMac;
		Device			mListNext;
		Device			mListPrev;
		
		/**
		 * DeviceTimer extends timer task to include canceled flag.
		 */
		private abstract class DeviceTimer extends TimerTask {
			boolean canceled = false;
		}
		
		DeviceTimer		mMsgWaitingTimeout;
		DeviceTimer		mMacTimeout;
		DeviceTimer		mFrameTimeout;
		
		Device(String uid) {
			mUid = uid;
		}
		
		/**
		 * Should this entry be removed from the device manager.
		 * 
		 * @return
		 */
		boolean shouldRemove() {
			return (mMac == null) && (mMsg == null) && !mIsMessageWaiting;
		}
		
		synchronized void setMsgWaitingTimeout() {
			if (mMsgWaitingTimeout == null) {
				mMsgWaitingTimeout = new DeviceTimer() {
					@Override
					public void run() {
						if (D) Log.w(TAG, mUid + ": message waiting timed out");
						synchronized (Device.this) {
							// TODO remove from MW list
							
							// remove from device table
							if (shouldRemove())
								remove(Device.this);
						}
						
						if (mCallback != null)
							mCallback.sendFailure(mUid);	
					}
				};
				mTimer.schedule(mMsgWaitingTimeout, MW_TIMEOUT);
			}
		}
		
		synchronized void cancelMacTimeout() {
			if (mMacTimeout != null) {
				mMacTimeout.canceled = true;
				mMacTimeout.cancel();
				mMacTimeout = null;
			}
		}
		
		synchronized void setMacTimeout() {
			cancelMacTimeout();
			mMacTimeout = new DeviceTimer() {
				@Override
				public void run() {
					synchronized (Device.this) {
						if (canceled)
							return;
						if (D) Log.w(TAG, mUid + ": device mac timed out");
						mMac = null;
						// remove from device table
						if (shouldRemove())
							remove(Device.this);
					}
				}
				
			};
			mTimer.schedule(mMacTimeout, MAC_TIMEOUT);
		}
		
		synchronized void cancelFrameTimeout() {
			if (mFrameTimeout != null) {
				mFrameTimeout.canceled = true;
				mFrameTimeout.cancel();
				mFrameTimeout = null;
			}
		}
		
		synchronized void setFrameTimeout() {
			cancelFrameTimeout();
			mFrameTimeout = new DeviceTimer() {
				@Override
				public void run() {
					synchronized (Device.this) {
						if (canceled)
							return;
						if (D) Log.w(TAG, mUid + ": frame timed out");
						// TODO use mw
					}
				}
				
			};
			mTimer.schedule(mMacTimeout, FRAME_TIMEOUT);
		}
	}
	
	public interface Callback {
		
		/**
		 * Notifies that a message failed to send to the specified UID
		 * 
		 * @param uid
		 */
		public void sendFailure(String uid);
		
	}
}
