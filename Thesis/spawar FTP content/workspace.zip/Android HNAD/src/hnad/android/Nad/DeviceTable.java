package hnad.android.Nad;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Log;


/**
 * This class implements a UID-to-MAC address lookup table. It also keeps state information
 * about each device, such as message waiting information.
 * 
 * This class is thread-safe.
 * 
 * @author cory
 *
 */
class DeviceTable {
	// For debugging
    private static final String TAG = DeviceTable.class.getName();
    private static final boolean D = true;
    
    
    private static final long TIMEOUT = 2100; // ms
	
    /**
     * Hash table.
     */
	private HashMap<String, Entry> mTable = new HashMap<String, Entry>();
	
	/**
	 * Table lock
	 */
	private Object mTableLock = new Object();
	
	/**
	 * Timer to run timeout tasks
	 */
	private Timer mTimer = new Timer();
	
	private Callback mCallback;
	
	public DeviceTable(DeviceTable.Callback callback) {
		mCallback = callback;
	}
	
	/**
	 * Stops the timer for the table. This should be done in order to
	 * gracefully close the application.
	 */
	public void stopTimer() {
		synchronized (mTableLock) {
			mTimer.cancel();	
		}
	}

	public void put(String uid, byte[] mac) {
		synchronized (mTableLock) {
			// a re-insert just updates the mac and resets the timer
			if (mTable.containsKey(uid)) {
				mTable.get(uid).mMac = mac;
			} else {
				Entry entry = new Entry(uid, mac);
				mTable.put(uid, entry);
			}
			if (D) Log.v(TAG, "After put: " + mTable.keySet().toString());	
		}		
	}
	
	public byte[] get(String uid) {
		synchronized (mTableLock) {
			Entry entry = mTable.get(uid);
			if (entry != null)
				return entry.mMac;
			else
				return null;	
		}
	}
	
	public byte[] remove(String uid) {
		synchronized (mTableLock) {
			// remove from table
			Entry entry = mTable.remove(uid);
			if (D) Log.v(TAG, "After remove: " + mTable.keySet().toString());
			if (entry != null)
				return entry.mMac;
			else
				return null;			
		}
	}
	
	private class Entry {
		String mUid;
		byte[] mMac;
		TimeoutTimer mTimeoutTimer;
		
		private class TimeoutTimer extends TimerTask {
			boolean killed = false;
			
			@Override
			public void run() {
				synchronized (mTableLock) {
					if (killed)
						return;
					if (D) Log.w(TAG, mUid + ": device mac timed out");
					remove(mUid);
					if (mCallback != null)
						mCallback.timeout(mUid);
				}
			}
			
		}
		
		public Entry(String uid, byte[] mac) {
			mUid = uid;
			mMac = mac;
			resetTimer();
		}
		
		/**
		 * Cancels/kills previous timer and starts a new one.
		 */
		public void resetTimer() {
			if (mTimeoutTimer != null) {
				mTimeoutTimer.killed = true;
				mTimeoutTimer.cancel();
			}
			
			mTimeoutTimer = new TimeoutTimer();
			mTimer.schedule(mTimeoutTimer, TIMEOUT); // start timer
		}
	}
	
	public interface Callback {
		
		/**
		 * Notifies that an entry timed out for the specified UID
		 */
		public void timeout(String uid);
	}
}
