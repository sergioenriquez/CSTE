package hnad.android.Nad;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Log;

/**
 * This is a very simple message waiting table where the entries will timeout
 * after a certain amount of time.
 * 
 * This class contains a hash map and doubly-linked list. The hash map provides
 * fast lookups while the linked list provides sequential iteration.
 * 
 * This class is thread-safe.
 * 
 * @author cory
 *
 */
public class MessageWaitingTable {
	// For debugging
    private static final String TAG = MessageWaitingTable.class.getName();
    private static final boolean D = true;
    
    private static final long TIMEOUT = 60000; // ms
	
    /**
     * Hash table.
     */
	private HashMap<String, ListNode> mTable = new HashMap<String, ListNode>();
	
	/**
	 * List head.
	 */
	private ListNode mHead;
	
	/**
	 * Window head for NADAs
	 */
	private ListNode mWindowHead;
	
	/**
	 * Timer to run timeout tasks
	 */
	private Timer mTimer = new Timer();
	
	private Callback mCallback;
	
	public MessageWaitingTable(MessageWaitingTable.Callback callback) {
		mCallback = callback;
	}
	
	/**
	 * Stops the timer for the table. This should be done in order to
	 * gracefully close the application.
	 */
	public synchronized void stopTimer() {
		mTimer.cancel();
	}

	public synchronized void put(String uid, byte[] message) {
		// a re-insert just updates the message but nothing else
		if (mTable.containsKey(uid)) {
			mTable.get(uid).mMessage = message;
		} else {
			ListNode node = new ListNode(uid, message);
			node.mNext = mHead;
			if (mHead != null)
				mHead.mPrev = node;
			mHead = node;
			mTable.put(uid, node);
		}
		if (D) Log.v(TAG, "After put: " + mTable.keySet().toString());		
	}
	
	public synchronized byte[] get(String uid) {
		ListNode node = mTable.get(uid);
		if (node != null)
			return node.mMessage;
		else
			return null;
	}
	
	public synchronized byte[] remove(String uid) {
		// remove from table
		ListNode node = mTable.remove(uid);
		if (D) Log.v(TAG, "After remove: " + mTable.keySet().toString());	
		
		if (node != null) {
			// remove from list
			if (node.mPrev != null)
				node.mPrev.mNext = node.mNext;
			if (node.mNext != null)
				node.mNext.mPrev = node.mPrev;
			
			if (mHead == node)
				mHead = node.mNext;
			if (mWindowHead == node)
				mWindowHead = node.mNext;
			
			return node.mMessage;
		} else {
			return null;
		}
	}
	
	/**
	 * Returns up to the next numUids from the list for use
	 * with message waiting.
	 * 
	 * @param numUids
	 * @return
	 */
	public synchronized ArrayList<String> getNextUids(int numUids) {
		ArrayList<String> list = new ArrayList<String>(numUids);
		
		// if at the end of the list, start over
		if (mWindowHead == null)
			mWindowHead = mHead;
		
		int count = 0;
		while (mWindowHead != null && count++ < numUids) {
			list.add(mWindowHead.mUid);
			mWindowHead = mWindowHead.mNext;
		}
		
		return list;
	}
	
	/**
	 * Returns whether getNextUids() has reached the end of the list.
	 * Can use after calling getNextUids() in order to set list continues
	 * flag in a NADA.
	 * 
	 * @return
	 */
	public synchronized boolean listContinues() {
		return mWindowHead != null;
	}
	
	private class ListNode {
		String mUid;
		byte[] mMessage;
		ListNode mNext;
		ListNode mPrev;
		TimerTask mTimeoutTimer = new TimerTask() {
			@Override
			public void run() {
				if (D) Log.i(TAG, mUid + ": message waiting timed out");
				remove(mUid);
				if (mCallback != null)
					mCallback.timeout(mUid);
			}
		};
		
		public ListNode(String uid, byte[] message) {
			mUid = uid;
			mMessage = message;
			mTimer.schedule(mTimeoutTimer, TIMEOUT); // start timer
		}
	}
	
	public interface Callback {
		
		/**
		 * Notifies that an entry timed out for the specified UID
		 */
		public void timeout(String uid);
	}
}
