package hnad.android.Nad;

import hnad.android.Constants;
import hnad.android.Dcp.Message;
import hnad.android.Nad.Xbee.ReceivePacket;
import hnad.android.Nad.Xbee.TransmitRequest;
import hnad.android.Nad.Xbee.XbeeApiFrame;
import hnad.android.Nad.Xbee.XbeeFrameParser;
import hnad.android.Utils.Convert;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.util.Log;


/**
 * This class implements the functionality required for a NAD device in the security
 * network.
 * 
 * This class needs to be able to communicate with the Data Center portion of this program.
 * This could be done using sockets to and from localhost, since it would probably require
 * little or no modification to the Data Center code when porting it to Android.
 * 
 * Alternatively, we could set up some sort of callback mechanism or use broadcast
 * intents.
 * 
 * @author cory
 *
 */
public class Nad {
	// For debugging
    private static final String TAG = Nad.class.getName();
    private static final boolean D = true; 
    
    private final ScheduledExecutorService mNadaScheduler = Executors.newScheduledThreadPool(1);
	
	/**
	 * Thread that sends NADA messages at the specified interval.
	 */
	//private NadaTimer mNadaTimer;
	
	/**
	 * Xbee Frame Parser
	 */
	private XbeeFrameParser mFrameParser = new XbeeFrameParser(new XbeeFrameParser.Callback() {
		@Override
		public void onTransmitStatusReceived(byte frameId, boolean successful) {
			handleTransmitStatus(frameId, successful);
		}
		
		@Override
		public void onPacketReceived(ReceivePacket packet) {
			handleReceivedPacket(packet);
		}
	});
	
	private MessageSender mMessageSender;
	
	/**
	 * Lock to send messages so that we wait for transmit OK message
	 */
	private Object mMessageLock = new Object();
	
	/**
	 * Variables to tell if we got a TX status and if the TX was successful. Used by MessageSender
	 */
	private boolean mGotTransmitStatus = false;
	private boolean mTransmitSuccessul = true;
	private byte mSentFrameId = 0;

	/**
	 * Map containing the UID to MAC address conversions. This should not be accessed
	 * directly. Use this class's synchronized methods instead.
	 */
	private DeviceTable mDeviceTable = new DeviceTable(new DeviceTable.Callback() {
		@Override
		public void timeout(String uid) {
			if (D) Log.i(TAG, uid + ": timed out of device table");
		}
	});
	
	private MessageWaitingTable mMessageWaitingTable = new MessageWaitingTable(
			new MessageWaitingTable.Callback() {
		@Override
		public void timeout(String uid) {
			if (D) Log.i(TAG, uid + ": timed out of MW table");
		}
	});
	
	/**
	 * Reference to parent service.
	 */
	private NadListener mListener;
	
	/*
	 * Nada message timing
	 */
	private final int mNadaInterval; // ms
	private final int mNadaIntervalCoding;
	private final int mNadaQuietTime; // ms
	private final int mNadaQuietCoding;
	private final int mNadaDuration; // ms
	private final boolean mBurstModeEnabled;
	private final int mBurstCount;
	
	/**
	 * Must be created on main thread since it uses a Handler for timers.
	 * Time coding is based on the coding defined in the ICD.
	 * 
	 * @param listener
	 * @param settings map containing NADA timing settings.
	 */
	public Nad(NadListener listener, Map<String, ?> settings) {
		mListener = listener;
		
		// Load settings or use defaults if necessary
		
		if (settings.containsKey(PREF_NADA_INTERVAL))
			mNadaIntervalCoding = (Integer) settings.get(PREF_NADA_INTERVAL);
		else
			mNadaIntervalCoding = 0;
		
		mNadaInterval = NADA_TIME_DELAY_MS[mNadaIntervalCoding];
		
		if (settings.containsKey(PREF_BURST_MODE_ENABLED))
			mBurstModeEnabled = (Boolean) settings.get(PREF_BURST_MODE_ENABLED);
		else
			mBurstModeEnabled = false;
		
		if (settings.containsKey(PREF_NADA_BURST_DURATION))
			mNadaDuration = NADA_TIME_DELAY_MS[(Integer) settings.get(PREF_NADA_BURST_DURATION)];
		else
			mNadaDuration = NADA_TIME_DELAY_MS[0];
		
		if (settings.containsKey(PREF_NADA_BURST_QUIET_TIME))
			mNadaQuietCoding = (Integer) settings.get(PREF_NADA_BURST_QUIET_TIME);
		else
			mNadaQuietCoding = 0;
		
		mNadaQuietTime = NADA_TIME_DELAY_MS[mNadaQuietCoding];
		
		if (mBurstModeEnabled) {
			mBurstCount = mNadaDuration / mNadaInterval;
		} else {
			mBurstCount = 0;
		}
		
		if (D) Log.d(TAG, "burstModeEnabled=" + mBurstModeEnabled + ", burstCount=" 
				+ mBurstCount + ", nadaInterval=" + mNadaInterval
				+ ", nadaDuration=" + mNadaDuration + ", nadaQuietTime=" + mNadaQuietTime);
	}
	
	/**
	 * Start the NAD, i.e. create and start the send/receive threads.
	 */
	public void start() {
		/*
		if (mNadaTimer == null) {
			mNadaTimer = new NadaTimer();
			mNadaTimer.start();
		} */
		
		Runnable nadaSender = new Runnable() {
			
			private int remainingInBurst = mBurstCount;
			
			@Override
			public void run() {
				if (mBurstModeEnabled) {
					remainingInBurst--; // decrement burst count
					//if (D) Log.d(TAG, "nada # " + (mBurstCount - remainingInBurst));
					boolean lastInBurst = (remainingInBurst == 0);
					sendNada(lastInBurst);
					if (lastInBurst) {
						// reset remaining count
						remainingInBurst = mBurstCount;
						if (D) Log.d(TAG, "NADA quiet time...");
						try {
							mNadaScheduler.schedule(this, mNadaQuietTime, TimeUnit.MILLISECONDS);
						} catch (Exception e) {
							Log.e(TAG, "Error scheduling NADA");
						}
					} else {
						try {
							mNadaScheduler.schedule(this, mNadaInterval, TimeUnit.MILLISECONDS);
						} catch (Exception e) {
							Log.e(TAG, "Error scheduling NADA");
						}
					}
				} else { // send single fixed recurring nada, scheduled as recurring no need to 
						 // reschedule
					sendNada(false);	
				}
			}
		};
		
		try {
			if (mBurstModeEnabled) {
				mNadaScheduler.schedule(nadaSender, 0, TimeUnit.MILLISECONDS);
			} else {
				mNadaScheduler.scheduleAtFixedRate(nadaSender, 0, mNadaInterval, TimeUnit.MILLISECONDS);
			}
		} catch (Exception e) {
			Log.e(TAG, "Error scheduling NADAs");
		}
		
		if (mMessageSender == null) {
			mMessageSender = new MessageSender();
			mMessageSender.start();
		}
	}
	
	/**
	 * Stop the NAD, i.e. stop the send/receive threads.
	 */
	public void stop() {
		if (mMessageSender != null) { 
			mMessageSender.stopRunning();
			mMessageSender = null;
		}
		
		try {
			mNadaScheduler.shutdown();
		} catch (Exception e) {
			Log.e(TAG, "Unable to shut down NADA scheduler");
		}
		
		// stop the timeout timer used by the MW table
		mMessageWaitingTable.stopTimer();
		
		// stop the timeout timer used by the device table
		mDeviceTable.stopTimer();
	}
	
	/**
	 * Send a security message to a security
	 *  device with the specified UID.
	 *  
	 * @param uid UID as a hex String. null UID means broadcast (i.e. NADA)
	 * @param message
	 */
	public void sendMessage(String uid, byte[] message) {
		if (uid == null) {
			//if (D) Log.d(TAG, "Sending broadcast message.");
			// turn bytes and MAC into API frame. If there is an error, abort the send.
			try {
				XbeeApiFrame frame = TransmitRequest.createTransmitRequest(null, message, 0);
				byte[] data = frame.getBytes();
				mListener.onSendData(data, data.length);
			} catch (IllegalArgumentException e) {
				Log.e(TAG, "Error creating transmit request. Message dropped.", e);
				return;
			}	
		} else {
			byte[] macAddress = getMacAddress(uid);
			if (macAddress == null) {
				if (D) Log.d(TAG, "Using message waiting to send message to " + uid);
				// add to message waiting
				mMessageWaitingTable.put(uid, message);
			} else {
				sendMessage(uid, macAddress, message);
			}
		}
	}
	
	/**
	 * Sends message.
	 * 
	 * @param uid
	 * @param macAddress
	 * @param message
	 */
	private void sendMessage(String uid, byte[] macAddress, byte[] message) {
		if (mMessageSender != null) {
			mMessageSender.enqueue(uid, macAddress, message);	
		} else {
			if (D) Log.e(TAG, "MessageSender not running message not sent.");
		}
	}
	
	/**
	 * Get the MAC address for the security device based on its UID.
	 * 
	 * @param uid
	 */
	private byte[] getMacAddress(String uid) {
		byte[] mac = mDeviceTable.get(uid);		
		return mac;
	}
	
	/**
	 * Sets the MAC address for the specified UID in the device table.
	 * 
	 * @param uid 			Mac address in bytes
	 * @param macAddress
	 */
	private void setMacAddress(byte[] uid, byte[] macAddress) {
		String uidHex = Convert.bytesToHexString(uid, uid.length);
		setMacAddress(uidHex, macAddress);
	}
	
	/**
	 * Sets the MAC address for the specified UID in the device table.
	 * 
	 * @param uid 			Mac address in hex (without the 0x prefix)
	 * @param macAddress
	 */ 
	private void setMacAddress(String uid, byte[] macAddress) {
		mDeviceTable.put(uid, macAddress);
		if (D) Log.i(TAG, "MAC address " + Convert.bytesToHexString(macAddress, macAddress.length) 
				+  " for UID " + uid + " added to table.");	
	}
	
	/**
	 * Build the NADA message and send it to the broadcast address.
	 * 
	 * @return
	 */
	private void sendNada(boolean lastInBurst) {
		// allocate buffer with only as many bytes as can be sent at once
		ByteBuffer nada = ByteBuffer.allocate(256);
		nada.put((byte) Constants.NAD_DEVICE_TYPE);
		nada.put((byte) Message.NADA);
		
		// get info for message waiting
		ArrayList<String> uids = mMessageWaitingTable.getNextUids(8);
		byte continuesBit = (byte) (mMessageWaitingTable.listContinues() ? 0x02 : 0x00);
		
		byte nadaCoding = (byte) (((lastInBurst ? mNadaQuietCoding : mNadaIntervalCoding) << 4) | 0x01 | continuesBit);
		nada.put(nadaCoding);
		
		// get date per format in ICD table 9-1
		nada.put(Convert.nowToIcdTime());
		
		// Level 1 facility, UID are zero-filled for HNAD.
		int skipTo = nada.position() + 1 + Constants.UID_SIZE;
		nada.position(skipTo);
		
		// Level 2 facility HNAD, UID
		nada.put((byte) Constants.NAD_DEVICE_TYPE);
		nada.put(Constants.HNAD_UID);
		
		nada.put((byte) uids.size()); // num message waiting entries 
		for (int i = 0; i < uids.size(); i++) {
			//if (D) Log.d(TAG, "NADA MW UID: " + uids[i]);
			byte[] bytes = Convert.hexStringToBytes(uids.get(i));
			nada.put(bytes);
		}
		
		// copy buffer to an array
		nada.flip(); // trims buffer limit to current size and sets position to 0 in order to read back
		int nadaLen = nada.remaining();
		byte[] nadaMessage = new byte[nadaLen + 1]; // pad one byte for checksum
		nada.get(nadaMessage, 0, nadaLen);
		
		int sum = 0;
		for (int i = 0; i < nadaMessage.length - 1; i++)
			sum = (sum + nadaMessage[i]) & 0xFF;
		nadaMessage[nadaMessage.length - 1] = (byte) sum;
		
		//Log.d(TAG, "nada: " + Convert.bytesToHexString(nadaMessage, nadaMessage.length));
		
		sendMessage(null, nadaMessage);
	}
	
	/**
	 * Process input from the Xbee module.
	 * 
	 * @param input
	 * @param len
	 */
	public void processInput(byte[] input, int len) {
		// parser will provide callback if we get frame(s)
		mFrameParser.parse(input, len);
	}
	
	private void handleTransmitStatus(byte frameId, boolean successul) {
		if (D) Log.d(TAG, "frame " + frameId + (successul ? " sent" : " failed"));
		synchronized (mMessageLock) {
			if (!mGotTransmitStatus && frameId == mSentFrameId) {
				mTransmitSuccessul = successul;
				mGotTransmitStatus = true;
				mMessageLock.notify();
			} else {
				if (D) Log.d(TAG, "Frame status (" + frameId + ") didn't match current frame (" + mSentFrameId + ")");
			}
		}
	}
	
	/**
	 * Parse the received packet.
	 * 
	 * @param packet
	 */
	private void handleReceivedPacket(ReceivePacket packet) {
		byte[] data = packet.getData();
		
		// null msg received
		if (data.length == NullMessage.LENGTH) {
			if (D) Log.d(TAG, "Received null message");
			NullMessage nullMessage = new NullMessage();
			nullMessage.set(data);
			if (nullMessage.isValid()) {
				String uid = Convert.bytesToHexString(nullMessage.uid, nullMessage.uid.length);
				setMacAddress(uid, packet.getSourceAddress()); // set up UID-MAC mapping for later
				byte[] msg = mMessageWaitingTable.get(uid);
				if (msg == null) {
					if (D) Log.w(TAG, "no message waiting for " + uid );
				} else {
					if (D) Log.w(TAG, "responding to null message from " + uid);
					sendMessage(uid, msg);
				}
			} else {
				if (D) Log.w(TAG, "null message checksum failure: " + Convert.bytesToHexString(data, data.length));
			} 
		} else {
			// save the UID, MAC
			byte[] uid = new byte[Constants.UID_SIZE];
			// TODO use IcdMessage as the as the way to grab needed info, add null msg to icd message?
			System.arraycopy(data, 3, uid, 0, Constants.UID_SIZE); // FIXME hardcode
			setMacAddress(uid, packet.getSourceAddress());
			// clear MW if any
			mMessageWaitingTable.remove(new String(uid, uid.length));
			// FIXME should reuse 
							
			// print out message hex for debug
			if (D) Log.d(TAG, "NAD received (" + (packet.isBroadcast() ? "broadcast" : "unicast")
				+ "): " + Convert.bytesToHexString(data, data.length));
			// pass message to DCP, ignoring broadcast messages
			if (!packet.isBroadcast()) {
				mListener.onMessageReceived(data);
			} else {
				if (D) Log.w(TAG, "Ignoring received broadcast packet.");
			}
		}
	}
	
	/*
	private class NadaTimer extends Thread {
		
		private volatile boolean running;
		
		private final int burstCount;
		
		public NadaTimer() {
			running = true;
			if (mBurstModeEnabled) {
				burstCount = mNadaDuration / mNadaInterval;
				if (D) Log.d(TAG, "burstCount=" + burstCount);
			} else {
				burstCount = 0; // doesn't matter since it won't be used
			}
		}

		@Override
		public void run() {
			while (running) {
				if (mBurstModeEnabled) {
					int count = burstCount;
					do {
						if (D) Log.d(TAG, "burst count=" + count);
						count--; // decrement burst count
						boolean lastInBurst = (count == 0);
						sendNada(lastInBurst);
						try {
							if (lastInBurst) {
								if (D) Log.d(TAG, "NADA quiet time...");
								sleep(mNadaQuietTime);	
							} else {
								sleep(mNadaInterval);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} while (count > 0);
				} else { // send single fixed recurring nada
					sendNada(false);	
					try {
						sleep(mNadaInterval);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		public void stopRunning() {
			running = false;
		}
	} */
	
	private class MessageSender extends hnad.android.Utils.TaskQueue<MessageSender.Entry> {
		
		private static final long SEND_TIMEOUT_MS = 100;
		
		public void enqueue(String uid, byte[] macAddress, byte[] message) {
			Entry e = new Entry(uid, macAddress, message);
			super.enqueue(e);
		}
		
		private class Entry {
			public String uid;
			public byte[] mac;
			public byte[] message;
			
			public Entry(String uid, byte[] mac, byte[] message) {
				super();
				this.uid = uid;
				this.mac = mac;
				this.message = message;
			}
		}
		
		@Override
		protected void onDequeue(Entry entry) {	
			if (D) Log.d(TAG, "Sending unicast message to " + entry.uid);
			
			synchronized (mMessageLock) {
				// cycle thru frame id's so that we don't accidentally get a stale tx status.
				// Don't want 0 through because that indicates no TX status
				do {
					mSentFrameId++;
				} while (mSentFrameId == 0);
				// turn bytes and MAC into API frame. If there is an error, abort the send.
				XbeeApiFrame frame = null;
				try {
					frame = TransmitRequest.createTransmitRequest(entry.mac, entry.message, mSentFrameId);
				} catch (IllegalArgumentException e) {
					Log.e(TAG, "Error creating transmit request. Message dropped.", e);
					return;
				}
				mGotTransmitStatus = false;
				byte data[] = frame.getBytes();
				mListener.onSendData(data, data.length);
				long start = System.nanoTime();
				long diff;
				boolean useMW = true;
				boolean timeout = true;
				while ((diff = System.nanoTime() - start) < SEND_TIMEOUT_MS * 1000000) {
					try {
						mMessageLock.wait(SEND_TIMEOUT_MS - diff / 1000000); // wait for a response
						if (mGotTransmitStatus) {
							useMW = !mTransmitSuccessul; // if not successful use MW
							mTransmitSuccessul = !mTransmitSuccessul; // lower flag
							timeout = false;
							break;
						}
					} catch (InterruptedException e) {
						; // if interrupted, we may continue waiting depending on if enough time has elapsed
					}
				}
				
				if (timeout)
					Log.d(TAG, "Timed out for frame " + mSentFrameId);
				
				if (useMW) {
					if (D) Log.d(TAG, "Using message waiting to send message (frame " + mSentFrameId + ") to " + entry.uid);
					// add to message waiting
					mMessageWaitingTable.put(entry.uid, entry.message);
				} else {
					if (D) Log.d(TAG, "Transmission successful (frame " + mSentFrameId + ") to " + entry.uid);
					mMessageWaitingTable.remove(entry.uid);
				}
			}
		}
	}
	
	/* ******* Constants ******* */
	
	/**
	 * Nada message byte offsets.
	 */
	
	public static final int NADA_DEVICE_TYPE_OFFSET				= 0;
	public static final int NADA_MESSAGE_TYPE_OFFSET			= 1;
	public static final int NADA_CODING_OFFSET					= 2;
	public static final int NADA_DATE_TIME_UTC_OFFSET			= 3;
	public static final int NADA_LEVEL_1_FACILITY_TYPE_OFFSET	= 11;
	public static final int NADA_LEVEL_1_FACILITY_UID_OFFSET	= 12;
	public static final int NADA_LEVEL_2_FACILITY_TYPE_OFFSET	= 20;
	public static final int NADA_LEVEL_2_FACILITY_UID_OFFSET	= 21;
	public static final int NADA_MESSAGE_WAITING_COUNT_OFFSET	= 29;
	public static final int NADA_MESSAGE_WAITING_UIDS_OFFSET	= 30;
	//						NADA_CHECKSUM_OFFSET				= ?; // checksum is the final byte
	
	/**
	 * Nada time delay constants in milliseconds. The indices correspond
	 * the the coding value in the Nada message.
	 */
	public static final int[] NADA_TIME_DELAY_MS = {
		20,		// 0 = 20 ms
		40,		// 1 = 40 ms
		80,		// 2 = 80 ms
		100,	// 3 = 100 ms
		200,	// 4 = 200 ms
		400,	// 5 = 400 ms
		800,	// 6 = 800 ms
		1000,	// 7 = 1000 ms
	};
	
	/**
	 * Nada time delay constants in a String format.
	 */
	public static final String[] NADA_TIME_DELAY_STRING = {
		"0.02s",	// 0 = 20 ms
		"0.04s",	// 1 = 40 ms
		"0.08s",	// 2 = 80 ms
		"0.10s",	// 3 = 100 ms
		"0.20s",	// 4 = 200 ms
		"0.40s",	// 5 = 400 ms
		"0.80s",	// 6 = 800 ms
		"1.00s",	// 7 = 1000 ms
	};
	
    /**
     * The preferences Nad "file".
     */
    public static final String PREFERENCES = "NAD_PREFERENCES"; 
    
    /**
     * Nad preferences.
     */
    
    // boolean indicating if NADA burst mode is enabled.
    public static final String PREF_BURST_MODE_ENABLED = "BURST_MODE_ENABLED";
    
    // indices into NADA_TIME_DELAY array indicating the time (in ms) for each.
    public static final String PREF_NADA_INTERVAL = "NADA_INTERVAL";
    public static final String PREF_NADA_BURST_DURATION = "NADA_BURST_DURATION";
    public static final String PREF_NADA_BURST_QUIET_TIME = "NADA_BURST_QUIET_TIME";
}
