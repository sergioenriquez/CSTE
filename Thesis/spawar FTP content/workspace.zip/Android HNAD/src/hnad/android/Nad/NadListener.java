package hnad.android.Nad;


/**
 * Interface to receive updates/bytes to send from the Nad.
 * 
 * @author cory
 *
 */
public interface NadListener {
	
	/**
	 * Called when an ICD message has been received.
	 * 
	 * @param message The message bytes received by the NAD.
	 */
	public void onMessageReceived(byte[] message);
	
	/**
	 * Called to send some data out to the security network. (Just send
	 * the raw byes; the Nad class has already taken care of the Xbee protocol.
	 * 
	 * @param data
	 * @param len
	 */	
	public void onSendData(byte[] data, int len);
}
