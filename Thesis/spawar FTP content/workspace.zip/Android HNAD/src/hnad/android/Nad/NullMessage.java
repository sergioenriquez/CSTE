package hnad.android.Nad;

import hnad.android.Utils.Struct;
import hnad.android.Utils.StructField;

public class NullMessage extends Struct {

	/**
	 * NULL message length.
	 */
	public static final int LENGTH = 10;
	
	@StructField(pos=0)
	public byte deviceType;
	
	@StructField(pos=1, len=8)
	public byte[] uid;
	
	@StructField(pos=2)
	public byte checksum;
	
	/**
	 * Validates checksum.
	 * 
	 * @return
	 */
	public boolean isValid() {
		byte sum = deviceType;
		for (int i = 0; i < uid.length; i++)
			sum = (byte) (sum + uid[i]);
		
		return checksum == sum;
	}
}
