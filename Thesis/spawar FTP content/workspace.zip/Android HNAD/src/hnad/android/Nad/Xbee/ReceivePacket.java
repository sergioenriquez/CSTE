package hnad.android.Nad.Xbee;


/**
 * This class reads a received packet wrapped within an {@link XbeeApiFrame}.
 * 
 * @author cory
 *
 */
public final class ReceivePacket {
	
	/**
	 * Minimum size.
	 */
	private static final int MINIMUM_SIZE			= 3; // data could be zero length

	/*
	 * Message data offsets.
	 */
	private static final int SOURCE_ADDRESS_OFFSET	= 0;
	//private static final int RSSI_OFFSET			= 8;
	private static final int OPTIONS_OFFSET			= 9;
	private static final int DATA_OFFSET			= 10;
	
	private byte[] mSourceAddress;
	private byte[] mData;
	private int mOptions;
	
	private static final int BROADCAST_OPTIONS_MASK = 0x06; //0b00000110
	
	/**
	 * @throws IllegalArgumentException if frame is too short
	 * @param frame
	 */
	protected ReceivePacket(XbeeApiFrame frame) {
		byte[] data = frame.getMsgData();
		if (data.length < MINIMUM_SIZE)
			throw new IllegalArgumentException("frame is not a transmit receive: too short");
		
		mSourceAddress = new byte[8];
		System.arraycopy(data, SOURCE_ADDRESS_OFFSET, mSourceAddress, 0, 8);
		
		int dataLen = data.length - DATA_OFFSET;
		mData = new byte[dataLen];
		System.arraycopy(data, DATA_OFFSET, mData, 0, dataLen);
		
		mOptions = 0xFF & data[OPTIONS_OFFSET];
	}
	
	/**
	 * Get the source address of the device sending this data.
	 * @return
	 */
	public byte[] getSourceAddress() {
		return mSourceAddress;
	}
	
	/**
	 * Get the data sent to us.
	 * @return
	 */
	public byte[] getData() {
		return mData;
	}
	
	/**
	 * Whether this packet is a broadcast packet or not.
	 * 
	 * @return
	 */
	public boolean isBroadcast() {
		return (mOptions & BROADCAST_OPTIONS_MASK) != 0;
	}
}
