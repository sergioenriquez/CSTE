package hnad.android.Nad.Xbee;


import java.nio.ByteBuffer;


/**
 * This class creates a transmit request, which should be wrapped with an {@link XbeeApiFrame}
 * before sending.
 * 
 * @author cory
 *
 */
public class TransmitRequest {

	/**
	 * Maximum transmit size.
	 */
	public static final int MAX_TRANSMIT_SIZE = 100;
	
	/**
	 * Minimum transmit size.
	 */
	public static final int MIN_TRANSMIT_SIZE = 0;
	
	/*
	 * Constants for transmit requests.
	 */
	private static final int TX_STATUS				= 0x01; // request Xbee send a TX status message back
	private static final int NO_TX_STATUS			= 0x00;
	private static final int DEFAULT_OPTIONS 		= 0x00;
	private static final int BROADCAST_OPTIONS 		= 0x01; // disable ACK
	
	/**
	 * The IEEE 802.15.4 broadcast address.
	 */
	public static final byte[] BROADCAST_ADDRESS = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
													(byte) 0xFF, (byte) 0xFF};
	
	/**
	 * Do nothing constructor.
	 */
	private TransmitRequest() {}

	/**
	 * @param destinationAddress The destination address or null for broadcast.
	 * @param data The data to transmit.
	 * @param frameId id number for the frame. If you don't need a transmit status response, set this to 0.
	 * 
	 * @return Byte array containing frame data to place in {@link XbeeApiFrame}.
	 * 
	 * @throws IllegalArgumentException If the transmitted data is too large or too small.
	 */
	public static XbeeApiFrame createTransmitRequest(byte[] destinationAddress, byte[] data, int frameId) 
			throws IllegalArgumentException {		
		if (data.length < MIN_TRANSMIT_SIZE || data.length > MAX_TRANSMIT_SIZE)
			throw new IllegalArgumentException("Invalid data length of " + 
					data.length + " bytes.");
		
		ByteBuffer buffer = ByteBuffer.allocate(200);
		buffer.put((byte) frameId);
		
		if (destinationAddress == null) { // if broadcast
			buffer.put(BROADCAST_ADDRESS);
			buffer.put((byte) BROADCAST_OPTIONS);
		} else {
			buffer.put(destinationAddress);
			buffer.put((byte) DEFAULT_OPTIONS);
		}

		buffer.put(data);
		
		buffer.flip();
		int bufferLength = buffer.remaining();
		byte[] transmitRequestData = new byte[bufferLength];
		buffer.get(transmitRequestData);
		
		return new XbeeApiFrame(XbeeApiFrame.MSG_TRANSMIT_REQUEST, transmitRequestData);
	}
}
