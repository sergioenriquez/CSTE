package hnad.android.Nad.Xbee;


/**
 * This class reads a transmit status wrapped within an {@link XbeeApiFrame}, allowing easy access to 
 * the status data.
 * 
 * @author cory
 *
 */
class TransmitStatus {
	
	/**
	 * The transmit status.
	 */
	private int mStatus;
	private int mFrameId;
	
	/*
	 * Status constants.
	 */
	public static final int STATUS_OK 		= 0;
	public static final int STATUS_NO_ACK 	= 1;
	public static final int STATUS_CCA_FAIL = 2;
	public static final int STATUS_PURGED 	= 3;
	
	/*
	 * Offsets for message data.
	 */
	private static final int FRAME_ID_OFFSET	= 0; // not needed for our purposes
	private static final int STATUS_OFFSET	 	= 1;
	
	/**
	 * Transmit status data size.
	 */
	private static final int FRAME_DATA_SIZE	= 2;
	
	/**
	 * @throws IllegalArgumentException if frame is not the correct size
	 * @param frame
	 */
	public TransmitStatus(XbeeApiFrame frame) {
		byte[] data = frame.getMsgData();
		
		if (data.length != FRAME_DATA_SIZE)
			throw new IllegalArgumentException("frame is not a transmit status: wrong size");
		
		mStatus = 0xFF & data[STATUS_OFFSET];
		mFrameId = 0xFF & data[FRAME_ID_OFFSET];
	}
	
	/**
	 * Get the transmit status.
	 * 
	 * @return STATUS_OK, STATUS_NAK, STATUS_CCA_FAIL, or STATUS_PURGE
	 */
	public int getStatus() {
		return mStatus;
	}
	
	/**
	 * Get the transmit status as a String.
	 * 
	 * @return
	 */
	public String getStatusString() {
		switch (mStatus) {
		case STATUS_OK:
			return "OK";
		case STATUS_NO_ACK:
			return "No ACK";
		case STATUS_CCA_FAIL:
			return "CCA Failure";
		case STATUS_PURGED:
			return "Purged";
		}
		return "Uknown status"; // never should reach this
	}
	
	/**
	 * The the ID of the frame for which this status was issued.
	 * 
	 * @return
	 */
	public int getFrameId() {
		return mFrameId;
	}
}
