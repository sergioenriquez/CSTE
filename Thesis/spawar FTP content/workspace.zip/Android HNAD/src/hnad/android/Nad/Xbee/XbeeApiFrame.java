package hnad.android.Nad.Xbee;

import hnad.android.Utils.Convert;


/**
 * This class abstracts the various parts of the Xbee Api Frame for easy access.
 * 
 * @author cory
 *
 */
public class XbeeApiFrame {
	
	/**
	 * Frame buffer size, no frame is larger than this
	 */
	public static final int BUFFER_SIZE		= 256; // bytes
	
	public static final int MSG_TRANSMIT_REQUEST 	= 0x00;
	public static final int MSG_TRANSMIT_STATUS		= 0x89;
	public static final int MSG_TRANSMIT_RECEIVE 	= 0x80;
	
	public static final int TRANSMIT_STATUS_LENGTH		= 3;
	public static final int TRANSMIT_RECEIVE_MAX_LENGTH	= 111;
	public static final int TRANSMIT_REQUEST_MAX_LENGTH	= 111;
	
	public static final int MAC_ADDRESS_LENGTH		= 8; // bytes
	
	// BYTE OFFSETS IN FRAME
	private static final int START_BYTE			= 0;
	private static final int LENGTH_MSB			= 1;
	private static final int LENGTH_LSB			= 2;
	private static final int MSG_ID				= 3;
	private static final int DATA_START			= 4; // data is variable length
	// CHECKSUM comes after data
	
	// maximum data size to be transmitted/received with xbee api
	public static final int MAX_DATA_SIZE			= 111;
	public static final int FRAME_OVERHEAD_SIZE		= 4;
	
	// See members below. This would be a frame with no data attached to it.
	private static final int MINIMUM_FRAME_LENGTH = 5;
	
	protected static final int FRAME_DELIMITER = 0x7E;
	
	private int		mStart; // should always be FRAME_DELIMITER
	private byte[] 	mLength; // length is a 2 byte value
	
	/**
	 * Raw data is held as regular bytes.
	 */
	private byte[] 	mMsgData;
	
	private int 	mMsgId;
	
	private int 	mChecksum;
	
	/**
	 * Create a new Xbee API frame.
	 * 
	 * @param msgId			The message type.
	 * @param msgData		The data for this message type.
	 * 
	 * TODO Should do some parameter validation.
	 */
	public XbeeApiFrame(int msgId, byte[] msgData) {
		// default value
		mStart = FRAME_DELIMITER;
		
		mMsgId = msgId;
		
		// copy frame data
		mMsgData = new byte[msgData.length];
		System.arraycopy(msgData, 0, mMsgData, 0, mMsgData.length);
		
		setLength(mMsgData.length + 1); // +1 since msg id is included in length calculation
		
		mChecksum = calculateChecksum();
	}
	
	/**
	 * Convert an Xbee API frame in raw bytes to an XbeeApiFrame object.
	 * 
	 * @param frame	The frame as raw bytes.
	 * @param length The length of the bytes.
	 * 
	 * @throws IllegalArgumentException if frame is too short.
	 */
	public XbeeApiFrame(byte[] frame, int length) {
		if (length < MINIMUM_FRAME_LENGTH)
			throw new IllegalArgumentException("frame is too short");
		
		mStart = 0xFF & frame[START_BYTE];
		setLength(frame[LENGTH_MSB], frame[LENGTH_LSB]);
		mMsgId = 0xFF & frame[MSG_ID];
		
		int dataLen = getLength() - 1; // -1 since we already have msg id
		mMsgData = new byte[dataLen]; 
		System.arraycopy(frame, DATA_START, mMsgData, 0, dataLen);
		mChecksum = 0xFF & frame[DATA_START + dataLen];
	}

	protected int getLength() {
		return Convert.bytesToInt(mLength);
	}

	private void setLength(byte msb, byte lsb) {
		if (mLength == null)
			mLength = new byte[2];
		
		mLength[0] = msb;
		mLength[1] = lsb;
	}
	
	private void setLength(int length) {
		byte[] len = Convert.intToBytes(length);
		setLength(len[2], len[3]);
	}

	protected byte[] getMsgData() {
		return mMsgData;
	}

	public int getMsgId() {
		return mMsgId;
	}

	/**
	 * Get the bytes of this frame.
	 * @return
	 */
	public byte[] getBytes() {
		int dataLen = 0;
		if (mMsgData != null)
			dataLen = mMsgData.length;
		
		byte[] bytes = new byte[MINIMUM_FRAME_LENGTH + dataLen];
		
		bytes[START_BYTE] 			= (byte) mStart;
		bytes[LENGTH_MSB]			= (byte) mLength[0];
		bytes[LENGTH_LSB] 			= (byte) mLength[1];
		bytes[MSG_ID]	  			= (byte) mMsgId;
		bytes[DATA_START + dataLen] = (byte) mChecksum;
		
		if (dataLen > 0)
			System.arraycopy(mMsgData, 0, bytes, DATA_START, dataLen);
		
		return bytes;
	}

	private boolean isStartValid() {
		return (mStart == FRAME_DELIMITER);
	}
	
	private boolean isLengthValid() {
		int actualLen = 1 + mMsgData.length; // length is msg id (1 byte) + data length in bytes.
		return (actualLen == getLength());
	}
	
	private boolean isChecksumValid() {
		int sum = 0;
		
		sum += 0xFF & mChecksum;
		sum += 0xFF & mMsgId;
		
		if (mMsgData != null)
			for (int i = 0; i < mMsgData.length; i++)
				sum += (0xFF & mMsgData[i]);
		
		return ((0xFF & sum) == 0xFF);
	}
	
	private int calculateChecksum() {
		int sum = 0;
		
		sum += 0xFF & mMsgId;

		if (mMsgData != null)
			for (int i = 0; i < mMsgData.length; i++)
				sum += (0xFF & mMsgData[i]);
		
		return 0xFF - (0xFF & sum);
	}
	
	/**
	 * Verifies that the frames start delimiter, length, and checksum are
	 * correct.
	 * 
	 * @return
	 */
	public boolean isValid() {
		return (isStartValid() && isLengthValid() && isChecksumValid());
	}
}
