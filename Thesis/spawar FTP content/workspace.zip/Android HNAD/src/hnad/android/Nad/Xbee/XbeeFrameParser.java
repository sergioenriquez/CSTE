package hnad.android.Nad.Xbee;

import java.nio.ByteBuffer;

import android.util.Log;

/**
 * This class parses an Xbee API frame into one of several types of
 * payload packets.
 * 
 * @author cory
 *
 */
public class XbeeFrameParser {
	
	public interface Callback {
		
		/**
		 * Called when a packet has been received.
		 * 
		 * @param packet
		 */
		public void onPacketReceived(ReceivePacket packet);
		
		/**
		 * Called when a transmit status has been received by the Xbee.
		 * 
		 * @param frameId
		 * @param successful
		 */
		public void onTransmitStatusReceived(byte frameId, boolean successful);
	}
	
	// For debugging
    private static final String TAG = XbeeFrameParser.class.getName();
    private static final boolean D = true;
    
	/*
	 * Input states. The state indicates what input we are waiting for.
	 */
	private static final int START_STATE		= 0;
	private static final int LEN_MSB_STATE		= 1;
	private static final int LEN_LSB_STATE		= 2;
	private static final int DATA_STATE			= 3;
	private static final int CHECKSUM_STATE		= 4;
	
	/**
	 * Current input state used by parseInputData
	 */
	private int mInputState = START_STATE;
	
	/**
	 * input buffer used by parseInputData
	 */
	private ByteBuffer inputBuffer = ByteBuffer.allocate(XbeeApiFrame.BUFFER_SIZE);
	
	private int mDataBytesRemaining = 0; // the number of data bytes leff to be read
										 // from the current frame being parsed
    
	private Callback mCallback;
	
	/**
	 * Takes Nad as a parameter in order to perform a callback whenever an XbeeApiFrame 
	 * is received.
	 * 
	 * @param nad
	 */
	public XbeeFrameParser(XbeeFrameParser.Callback callback) {
		if (callback == null)
			throw new IllegalArgumentException("callback cannot be null!");
		mCallback = callback;
	}
	
	/**
	 * Give the XbeeComm class data to parse into Xbee API frames. It will perform
	 * callbacks (thru handle frame) to the registered callback handler whenever an RX frame or a TX status
	 * frame is received.
	 * 
	 * @param data
	 * @param len
	 */
	public void parse(byte[] data, int len) {
		// parse based on bytes
		byte b;
		for (int i = 0; i < len; i++) {
			b = data[i];
			switch (mInputState) {
			case START_STATE:
				if (b == XbeeApiFrame.FRAME_DELIMITER) {
					inputBuffer.clear();
					inputBuffer.put(b);
					mInputState = LEN_MSB_STATE;
				}
				break;
			case LEN_MSB_STATE:
				inputBuffer.put(b);
				mDataBytesRemaining = (b << 8) & 0xFF00;
				mInputState = LEN_LSB_STATE;
				break;
			case LEN_LSB_STATE:
				inputBuffer.put(b);
				mDataBytesRemaining |= (0xFF & b);
				// if frame would be larger than the buffer or if there is no data 
				// payload, assume it is invalid and go back to the start state
				if (mDataBytesRemaining + XbeeApiFrame.FRAME_OVERHEAD_SIZE > XbeeApiFrame.BUFFER_SIZE || mDataBytesRemaining < 1) {
					Log.e(TAG, "Error: frame size wrong! (" + (mDataBytesRemaining + XbeeApiFrame.FRAME_OVERHEAD_SIZE) + " bytes)");
					mInputState = START_STATE;
				} else {
					mInputState = DATA_STATE;
				}
				break;
			case DATA_STATE:
				inputBuffer.put(b);
				mDataBytesRemaining--;
				if (mDataBytesRemaining == 0)
						mInputState = CHECKSUM_STATE;
				break;
			case CHECKSUM_STATE:
				mInputState = START_STATE;
				inputBuffer.put(b);
				
				try {
					XbeeApiFrame frame = new XbeeApiFrame(inputBuffer.array(), inputBuffer.position());
					if (D) Log.d(TAG, "Received frame.");
					handleFrame(frame);
				} catch (IllegalArgumentException e) {
					Log.e(TAG, "Bad frame.", e);
				}
				break;
			}
		}
	}
	
	/**
	 * Handle a parsed frame.
	 * 
	 * @param frame
	 */
	private void handleFrame(XbeeApiFrame frame) {
		if (!frame.isValid()) {
			Log.e(TAG, "Frame checksum error! Message type: " + frame.getMsgId());
			return;
		}
		
		try {
			switch (frame.getMsgId()) {
			case XbeeApiFrame.MSG_TRANSMIT_STATUS:
				TransmitStatus status = new TransmitStatus(frame);
				mCallback.onTransmitStatusReceived((byte)status.getFrameId(), status.getStatus() == TransmitStatus.STATUS_OK);
				break;
			case XbeeApiFrame.MSG_TRANSMIT_RECEIVE:
				ReceivePacket receive = new ReceivePacket(frame);
				mCallback.onPacketReceived(receive);
				break;
			default:
				Log.w(TAG, "Received unknown frame type! Ignoring...");
				break;
			}
		} catch (IllegalArgumentException e) {
			Log.e(TAG, "Bad frame!", e);
		}
	}
	
}
