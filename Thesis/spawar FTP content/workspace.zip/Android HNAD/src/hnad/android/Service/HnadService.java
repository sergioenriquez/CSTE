package hnad.android.Service;

import hnad.android.R;
import hnad.android.Activity.MainActivity;
import hnad.android.Dcp.Dcp;
import hnad.android.Dcp.DcpListener;
import hnad.android.Dcp.Device;
import hnad.android.Nad.Nad;
import hnad.android.Nad.NadListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.UUID;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

/**
 * This is the base class for this app's connection service. It contains the Xbee Connection,
 * NAD, and DCP parts of the application.
 * 
 * @author Cory Sohrakoff
 * 
 */
public class HnadService extends Service implements DcpListener, NadListener {
	// For debugging
	private static final String TAG = HnadService.class.getName();
	private static final boolean D = true;
	
	/**
	 * Reference to the Handler that we can use to run things on the main thread, i.e.
	 * Toast messages.
	 */
	private final Handler mRunnableHandler = new Handler();
	
	/**
	 * Post an arbitrary runnable to the main thread.
	 * 
	 * @param runnable
	 */
	public void runOnMainThread(Runnable runnable) {
		mRunnableHandler.post(runnable);
	}
	
	/**
	 * Display a Toast message to the user, it will run on the main thread.
	 * 
	 * @param msg Message to be displayed.
	 */
	public void toastMessage(final String msg) {
		runOnMainThread(new Runnable() {	
			@Override
			public void run() {
				Toast.makeText(HnadService.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	/**
	 * List of listeners that have registered with this Service.
	 */
	private final ArrayList<HnadService.EventListener> mListeners = new ArrayList<HnadService.EventListener>();
	
	/**
	 * Register the {@link HnadService.EventListener} to handle state/data changes within the service.
	 * 
	 * @param listener
	 */
	public void addListener(HnadService.EventListener listener) {
		synchronized (mListeners) {
			if (D) Log.d(TAG, "listener=" + listener);
			if (listener != null)
				mListeners.add(listener);	
		}
	}
	
	/**
	 * Unregister the {@link HnadService.EventListener} to handle state/data changes within the service.
	 * 
	 * @param listener
	 */
	public void removeListener(HnadService.EventListener listener) {
		synchronized (mListeners) {
			if (D) Log.d(TAG, "listener=" + listener);
			if (listener != null)
				mListeners.remove(listener);	
		}
	}
	
	/**
     * Notify the UI that the device has changed.
     */
    public void notifyDataUpdate(String deviceUid) {    	
    	synchronized (mListeners) {
    		if (mListeners.size() > 0) {
    			for (HnadService.EventListener listener : mListeners)
    				listener.onDataUpdated(this, deviceUid);

    		} else {
    			if (D) Log.i(TAG, "No listeners attached.");
    	    	// TODO if alarm make notification
    		}
		}
    }
	
    /**
     * The current state the service is in. It can be NONE (unconnected), CONNECTING, or CONNECTED,
     * depending on what stage of the connection the service is in.
     */
	private int mState;

	private Object mStateLock = new Object(); // object to synchronize state on
	
	// Constants that indicate the current connection state
	public static final int STATE_NOT_STARTED	= 0; // service not started yet
	public static final int STATE_CONNECTING 	= 1; // now initiating an outgoing connection
	public static final int STATE_CONNECTED 	= 2; // now connected to a remote device
	public static final int STATE_DONE			= 3; // the service has finished running
	
	/**
	 * Service requires Bluetooth address to connect to network adapter.
	 */
	public static final String EXTRA_BT_ADDRESS = "BT_ADDRESS";
	
	/**
	 * Set the current state of the connection
	 * @param state  An integer constant defining the current connection state
	 */
	private void setState(int state) {
		synchronized (mStateLock) {
			if (D) Log.d(TAG, "setState() " + mState + " -> " + state);
			mState = state;
			
			synchronized (mListeners) {
				for (HnadService.EventListener listener : mListeners)
					listener.onConnectionStateChanged(this, mState);	
			}	
		}
	}

	/**
	 * Return the current connection state. 
	 */
	public int getState() {
		synchronized (mStateLock) {
			 return mState;	
		}
	}
	
	/**
	 * The thread is used to create a Bluetooth connection before starting the HNAD.
	 */
	private ConnectThread mConnectThread;
	
	/**
	 * The NAD portion of the application.
	 */
	private Nad mNad;
	
	/**
	 * The DCP portion of the application.
	 */
	private Dcp mDcp;
	
	/**
	 * Bluetooth socket
	 */
	private BluetoothSocket mSocket;
	
	/**
	 * Reference to the BT connection Thread.
	 */
	private InputThread mInputThread;
	
	/**
	 * Lock to serialize output to BT
	 */
	private Object mOutputLock = new Object();
	
	/**
	 * Bluetooth output stream.
	 */
	private OutputStream mOutputStream;
	
	/**
	 * Lock lock on objects that need to be initialized and destroyed.
	 * By the service.
	 */
	private Object mInitLock = new Object();
    
    /**
     * Method to do whatever setup you need to do after the connection is started. If you override
     * make sure you call super.connect().
     */
    private void onConnectionReady(BluetoothSocket bluetoothSocket) {
        if (D) Log.d(TAG, "connected");
        setState(STATE_CONNECTED);
        
		String title = getResources().getString(R.string.notification_title);
		Notification notification = new Notification(R.drawable.icon, title, 0);
		
		Intent intent = new Intent(this, MainActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP); // flag stops a new activity from being created
														  // if  it is already running
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
		String text = getResources().getString(R.string.notification_connected);
		notification.setLatestEventInfo(this, title, text, pendingIntent);
		startForeground(hashCode(), notification);
		
		InputStream tmpIn = null;
		OutputStream tmpOut = null;
		try {
			tmpIn = bluetoothSocket.getInputStream();
			tmpOut = bluetoothSocket.getOutputStream();
		} catch (IOException e) {
            // Post a connection failed toast message.        
    		toastMessage(getResources().getString(R.string.toast_connection_failed));
    		if (HnadService.this.getState() != STATE_DONE)
    		stopSelf();
    		return;
		}
		
		synchronized (mInitLock) {
			mSocket = bluetoothSocket;
			
			mNad.start();
			mDcp.start();
			
			mInputThread = new InputThread(tmpIn);
			mInputThread.start();
		}
		
		synchronized (mOutputLock) {
			mOutputStream = tmpOut;
		}
    }
    
    public ArrayList<Device> getAllDevices() {
    	return mDcp.getDevices();
    }
    
    public Device getDevice(String deviceUid) {
    	return mDcp.getDevice(deviceUid);
    }
    
    /**
     * Class for UI to access service. 
     * 
     * @author Cory Sohrakoff
     *
     */
    public class LocalBinder extends Binder {
    	public HnadService getService() {
    		return HnadService.this;
    	}
    }
    
    /**
     * LocalBinder object.
     */
	private final IBinder mBinder = new LocalBinder();
	    
	/**
	 * Don't override this.
	 */
	public IBinder onBind(Intent intent) {
		if(D) Log.i(TAG, "--- onBind() ---");
		return mBinder;
	}


	/**
	 * Don't override this. Implement serviceStarted() instead. This makes sure the
	 * serviceStarted code won't run if the service hasn't been started before.
	 */
	public int onStartCommand(Intent intent, int flags, int startId) {
		String bluetoothAddress = intent.getStringExtra(EXTRA_BT_ADDRESS);
		if (getState() == STATE_NOT_STARTED) {
			if (bluetoothAddress != null) {
				setState(STATE_CONNECTING);
				synchronized (mInitLock) {
					mConnectThread = new ConnectThread(bluetoothAddress);
					mConnectThread.start();	
				}
			} else {
				Log.e(TAG, "No BT address supplied. Stopping service...");
				stopSelf();
			}
		} else {
			if (D) Log.w(TAG, "Service already started.");
	        // Post an already connected toast message.
			toastMessage(getResources().getString(R.string.toast_already_connected));
		}
		// Want service to run until explicitly stopped so we return sticky.
		return START_STICKY;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		if (D) Log.i(TAG, "onCreate()");
		setState(STATE_NOT_STARTED);
		
		synchronized (mInitLock) {
			mNad = new Nad(this, getSharedPreferences(Nad.PREFERENCES, Context.MODE_PRIVATE).getAll());
			mDcp = new Dcp(this, getSharedPreferences(Dcp.PREFERENCES, Context.MODE_PRIVATE).getAll());	
		}
	}

	@Override
	public void onDestroy() {
		if (D) Log.i(TAG, "onDestroy()");
		
        setState(STATE_DONE);
        stopForeground(true);
        
        synchronized (mInitLock) {
        	if (mSocket != null) {
        		try {
					mSocket.close();
				} catch (IOException e) {}
        		mSocket = null;
        	}
        	
            if (mConnectThread != null) {
            	mConnectThread.cancel();
            	mConnectThread = null;
            }
            
            if (mInputThread != null) {
            	mInputThread.cancel();
            	mInputThread = null;
            }
            
            if (mNad != null) {
            	mNad.stop();
            	mNad = null;
            }
            
            if (mDcp != null) {
            	mDcp.stop();
            	mDcp = null;
            }	
		}
        
		super.onDestroy();
	}
	
	/**
	 * Provides a means for Activities to receive data from the {@link HnadService}. They can
	 * register their version of this Listener with the Service in order to receive notifications for
	 * certain events defined here.
	 * 
	 * This callbacks will occur on whatever thread they originate from (i.e. where notify...() was called from). 
	 * This means if you modify the UI in a callback you should wrap that code in a Runnable and
	 * run it on the main thread. 
	 * 
	 * @author Cory Sohrakoff
	 *
	 */
	public static abstract class EventListener {			
		/**
		 * This method should be implemented to allow the UI to reflect the changes in the connection 
		 * state of the HnadService.
		 * 
		 * @param service 			HnadService that is making this callback.
		 * @param connectionState	Integer state defined in {@link HnadService}.
		 */
		public abstract void onConnectionStateChanged(final HnadService service, final int connectionState);
		
		/**
		 * Implement here what the application needs to do when the data in the HnadService has been 
		 * updated. NOTE: This gives you the new data. If you want all of the data, you will need
		 * to fetch the data yourself.
		 * @param hnadService TODO
		 * @param deviceUid 		HnadService that is making this callback.
		 */
		public abstract void onDataUpdated(HnadService hnadService, final String deviceUid);
	}
	
	/**
	 * This thread runs while attempting to make an outgoing connection
	 * with a Bluetooth device. It runs straight through; the connection either
	 * succeeds or fails.
	 */
	private class ConnectThread extends Thread {
		
		/**
		 * Address of the bluetooth device we are connecting to.
		 */
	    private final String mBluetoothAddress;
	    
	    /**
	     * This UUID is important because it is the UUID that is used to connect to generic Bluetooth SPP
	     * devices. 
	     */
	    private final UUID APP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	
	    /**
	     * Bluetooth socket we are opening.
	     */
	    private BluetoothSocket mmSocket;
	    
	    public ConnectThread(String bluetoothAddress) {
	    	mBluetoothAddress = bluetoothAddress;
	    }
	
	    public void run() {
	        Log.i(TAG, "BEGIN mConnectThread");
	
	        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
	        BluetoothDevice device = adapter.getRemoteDevice(mBluetoothAddress);
	        
	        if (D) Log.d(TAG, "Attempting BT connection to " + device.getName() + " (" + device.getAddress() + ")");
	        
	        // Always cancel discovery because it will slow down a connection
	        adapter.cancelDiscovery();
	
	        try {
		        // get a socket for the device
		        mmSocket = device.createRfcommSocketToServiceRecord(APP_UUID);
	        	
		        // connect through the socket
	            // This is a blocking call and will only return on a
	            // successful connection or an exception
	            mmSocket.connect();
	            
		        // Bluetooth connection is ready
		        onConnectionReady(mmSocket);
	        } catch (IOException e) {	            
	            // Post a connection failed toast message.        
	    		toastMessage(getResources().getString(R.string.toast_connection_failed));
	    		if (HnadService.this.getState() != STATE_DONE)
	    			stopSelf();
	        }
	        
	        
	        synchronized (mInitLock) {
		        // this thread no longer needed: set it to null
		        mConnectThread = null;	
			}
	    }
	
	    public void cancel() {
            try { 
            	if (mmSocket != null) 
            		mmSocket.close(); 
            } catch (IOException e) {
            } finally { 
            	mmSocket = null; 
            }
	    }
	}
	
	   /**
     * This thread runs during a connection with a remote device.
     * It handles all incoming and outgoing transmissions.
     */
    private class InputThread extends Thread {
        private final InputStream mmInputStream;

        public InputThread(InputStream input) {
            Log.d(TAG, "create InputThread");
            mmInputStream = input;
        }

        public void run() {
            Log.i(TAG, "BEGIN mInputThread");
            byte[] buffer = new byte[1024];
            int len;

            // Keep listening to the InputStream while connected
            while (true) {
                try {
                    // Read from the InputStream
                    len = mmInputStream.read(buffer);
					
					// forward data so it can be parsed
					if (mNad != null) {
						mNad.processInput(buffer, len);
					} else {
						if (D) Log.w(TAG, "mNad is null. Unable to handle BT input data.");
					}
                } catch (IOException e) {    	            
                    Log.e(TAG, "input disconnected", e);
                    // Post a connection lost toast message.
                    toastMessage( getResources().getString(R.string.toast_connection_terminated));
                    // stop connection due to the error
    	    		if (HnadService.this.getState() != STATE_DONE)
    	    			stopSelf();
                    break;
                }
            }
            
            // thread is no longer needed: set it to null
            mInputThread = null;
            
            if (D) Log.i(TAG, "STOP mInputThread");
        }

        public void cancel() {
            try { 
            	if (mmInputStream != null) 
            		mmInputStream.close(); 
            } catch (IOException e) {}
        }
    }
	
	/* **********Communication coordinator methods ********** */
	
	/*
	 * NadListener methods
	 */
    
	@Override
	public void onSendData(byte[] data, int len) {
		synchronized (mOutputLock) {
			if (mOutputStream != null) {
				// transmit
	            try {
	                mOutputStream.write(data, 0, len);
	            } catch (IOException e) {
	                Log.e(TAG, "Exception during write", e);
	            }
			} else {
				if (D) Log.w(TAG, "mOutputStream is null. Send failed.");
			}	
		}
	}

	@Override
	public void onMessageReceived(byte[] message) {
		if (mDcp != null) {
			mDcp.processInputMessage(message);
		} else {
			if (D) Log.w(TAG, "DCP is null. Unable to handle ICD message.");
		}
	}

	/*
	 * DcpListener methods
	 */
	
	@Override
	public boolean onSendMessage(String deviceUid, byte[] message) {
		if (mNad != null) {
			mNad.sendMessage(deviceUid, message);
			return true;
		} else {
			if (D) Log.w(TAG, "NAD is null. Unable to send ICD message.");
			return false;
		}		
	}

	@Override
	public void onCommandTimeout(String deviceUid) {
		// Notify user of the command timeout using a toast message.
		toastMessage("Command to " + deviceUid + " timed out."); 
	}

	@Override
	public void onDeviceUpdated(String deviceUid) {
		notifyDataUpdate(deviceUid);
	}

	@Override
	public void onDeviceExpired(String deviceUid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLogTimeout(String deviceUid) {
		// give a messsage about the timeout for now
		toastMessage("Log from " + deviceUid + " timed out.");
	}
	
}
