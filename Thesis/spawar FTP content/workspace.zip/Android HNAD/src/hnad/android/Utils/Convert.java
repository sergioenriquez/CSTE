/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hnad.android.Utils;

import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 *
 * @author Anton
 * @author cory
 */
public class Convert {
	
	/*
	 * UTC format found in ICD table 9-1
	 */
	
	// UTC Length per ICD
	private static final int UTC_SIZE						= 8; // bytes
	// UTC offsets
	private static final int UTC_MONTH						= 0; // month is 1-12
	private static final int UTC_DAY_OF_MONTH				= 1; // day is 1-31
	private static final int UTC_YEARS_SINCE_2000			= 2;
	private static final int UTC_DAY_OF_WEEK				= 3; // day is 0-6
	private static final int UTC_HOURS_SINCE_MIDNIGHT		= 4; // day is 0-23
	private static final int UTC_MINUTES_AFTER_HOUR			= 5; // day is 0-59
	private static final int UTC_SECONDS_AFTER_MINUTE		= 6; // day is 0-61
	private static final int UTC_FRACTIONAL_SECONDS			= 7; // 1/100ths sec
	
	/**
	 * Creates an ICD formatted UTC time based on the current time.
	 * 
	 * @return byte array representing ICD time.
	 */
    public static byte[] nowToIcdTime() {
        byte[] time = new byte[UTC_SIZE];
        GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        time[UTC_MONTH]					= (byte) (cal.get(Calendar.MONTH) + 1);
        time[UTC_DAY_OF_MONTH]			= (byte) cal.get(Calendar.DAY_OF_MONTH);
        time[UTC_YEARS_SINCE_2000]		= (byte) (cal.get(Calendar.YEAR) - 2000);
        time[UTC_DAY_OF_WEEK]				= (byte) (cal.get(Calendar.DAY_OF_WEEK) - 1);
        time[UTC_HOURS_SINCE_MIDNIGHT]	= (byte) cal.get(Calendar.HOUR_OF_DAY);
        time[UTC_MINUTES_AFTER_HOUR]		= (byte) cal.get(Calendar.MINUTE);
        time[UTC_SECONDS_AFTER_MINUTE]	= (byte) cal.get(Calendar.SECOND);
        return time;
    }
    
    /**
     * Convert an ICD formatted UTC time into a Calendar object. This is the same as 
     * {@code icdTimeToCalendar(time, 0)}.
     * 
     * @param time							byte array containing the ICD time.
     * @return								Calendar object containing time data
     * @throws IllegalArgumentException		if the length of the byte array does not equal 
     * 										{@code UTC_LENGTH}
     */
    public static Calendar icdTimeToCalendar(byte[] time)
    		throws IllegalArgumentException {
    	return icdTimeToCalendar(time, 0);
    }
    
    /**
     * Convert an ICD formatted UTC time into a Calendar object.
     * 
     * @param time							byte array containing the ICD time.
     * @param offset						offset into byte array where the ICD time is located.
     * @return								Calendar object containing time data
     * @throws IllegalArgumentException		if {@code time.length-offset} does not equal 
     * 										{@code UTC_LENGTH}
     */
    public static Calendar icdTimeToCalendar(byte[] time, int offset)
    		throws IllegalArgumentException {
    	if (time.length - offset < UTC_SIZE)
    		throw new IllegalArgumentException("UTC time format must be " + 
    				UTC_SIZE + " bytes");
    	
        GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        int month	= time[offset + UTC_MONTH] - 1;
        int day		= time[offset + UTC_DAY_OF_MONTH];
        int year	= time[offset + UTC_YEARS_SINCE_2000] + 2000;
        int hour	= time[offset + UTC_HOURS_SINCE_MIDNIGHT];
        int minute	= time[offset + UTC_MINUTES_AFTER_HOUR];
        int second	= time[offset + UTC_SECONDS_AFTER_MINUTE];
        
        cal.set(year, month, day, hour, minute, second);
        return cal;
    }
    
    /*
     * Location format per ICD sec. 9.5.3
     */
	public static final int LOCATION_SIZE					= 20; // bytes
	public static final int LOCATION_LAT_SIZE				= 8; // bytes
	public static final int LOCATION_LON_SIZE				= 9; // bytes
	public static final int LOCATION_RADIUS_SIZE			= 4; // bytes
	
	/**
	 * This method assumes that the parameters have already been validated.
	 * 
	 * @param lat
	 * @param lon
	 * @param radius
	 * @return			The command location as ICD formatted ASCII bytes.	
	 */
	public static byte[] commandLocationToBytes(float lat, float lon, int radius) {
		// determine direction from sign
		char latd = 'N';
		if (lat < 0.0) {
			latd = 'S';
			lat = Math.abs(lat);
		}
		
		char lond = 'E';
		if (lon < 0.0) {
			lond = 'W';
			lon = Math.abs(lon);
		}
		
		String location = String.format("%08.3f%c%09.3f%c%04d", lat, latd, lon, lond, radius);
		return location.getBytes();
	}
    
    /**
     * Converts an ICD formatted location to a tuple (lat, lon) containing float values of the
     * location coordinate in positive/negative degrees.
     * 
     * @param location
     * @return tuple of coordinates if valid, or null if location invalid
     * throws IllegalArgumentException if the location length does not equal {@code LOCATION_SIZE}
     */
    public static Tuple<Float, Float> logLocationToCoordinate(byte[] location) {
    	if (location.length != LOCATION_SIZE)
    		throw new IllegalArgumentException("UTC time format must be " + 
    				LOCATION_SIZE + " bytes");
    	
    	int pos = 0;
    	// if not active, return "void"
    	if (location[pos++] != 'A')
    		return null;
    	
    	float lat = Float.parseFloat(new String(location, pos, LOCATION_LAT_SIZE)) / 100.0f;
    	pos += LOCATION_LAT_SIZE;
    	if (location[pos++] == 'S') // negate for South
    		lat = -lat;

    	float lon = Float.parseFloat(new String(location, pos, LOCATION_LON_SIZE)) / 100.0f;
    	pos += LOCATION_LON_SIZE;
    	if (location[pos++] == 'W') // negate for West
    		lon = -lon;
    	
    	return new Tuple<Float, Float>(lat, lon);
    }
    
    /**
     * Convert 0-4 bytes into an int.
     * 
     * @param bytes							byte array of length <= 4. 
     * 										The byte order should be big-endian (a.k.a. network byte order).
     * @return								int value of byte array.
     * @throws IllegalArgumentException		if the length of the byte array > 4.
     */
	public static int bytesToInt(byte[] bytes) throws IllegalArgumentException {
		if (bytes.length > 4) {
			throw new IllegalArgumentException("int conversion requires <=  4 bytes");
		}
		
		int value = 0;
		for (int i = 0; i < bytes.length; i++) {
			value = (value << 8) | (bytes[i] & 0xFF); // FIXME wrong!
		}
		
		return value;
	}
	
	/**
	 * Convert and int to a byte array of length 4.
	 * 
	 * @param i			int value
	 * @return			byte array representing int value. The byte order is big-endian (a.k.a.
	 * 					network byte order).
	 */
	public static byte[] intToBytes(int i) {
		return ByteBuffer.allocate(4).putInt(i).array();
	}
	
	/**
	 * Method to convert a hex string into a byte array.
	 * 
	 * @param hex							A hex string (without the leading 0x).
	 * 
	 * @throws IllegalArgumentException		If the hex string does not have an even number of characters.
	 * @return								A byte array containing the values indicated by the
	 * 										hex string.
	 */
	public static byte[] hexStringToBytes(String hex) throws IllegalArgumentException {
		int len = hex.length();
		if (len % 2 != 0)
			throw new IllegalArgumentException("hex string must contain an even number of characters");
		
		byte[] bytes = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			bytes[i/2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i+1), 16));
		}
		
		return bytes;
	}
	
	/**
	 * Method to convert a byte array into a hex string.
	 * 
	 * @param bytes		byte array to convert from.
	 * @return			hex string based on values from byte array.
	 */
	public static String bytesToHexString(byte[] bytes, int len) {
		StringBuilder buf = new StringBuilder(len * 2); // need 2 hex characters for each byte
		for (int i = 0; i < len; i++) {
			buf.append(Integer.toHexString((int)((bytes[i] >> 4) & 0xF)));
			buf.append(Integer.toHexString((int)(bytes[i] & 0xF)));
		}
		
		return buf.toString();
	}
	
}
