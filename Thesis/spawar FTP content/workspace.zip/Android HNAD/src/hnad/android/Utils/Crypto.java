package hnad.android.Utils;

import org.bcandroid.crypto.BufferedBlockCipher;
import org.bcandroid.crypto.engines.AESEngine;
import org.bcandroid.crypto.modes.CCMBlockCipher;
import org.bcandroid.crypto.params.CCMParameters;
import org.bcandroid.crypto.params.KeyParameter;

import android.util.Log;

public final class Crypto {
	// For debugging
    private static final String TAG = Crypto.class.getName();
    private static final boolean D = true;
    
	/*
	 * Encryption constants
	 */
	public static final int MIC_SIZE						= 8; // bytes
	public static final int REKEY_MIC_SIZE					= 16; // bytes
	public static final int LTK_SIZE						= 16; // bytes
	
    
    /**
     * Rekey key
     */
    public static final byte[] REKEY_KEY 	= {	0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08, 
    											0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
	
	/**
	 * Does AES-CCM encryption.
	 * 
	 * @throws Exception if the operation fails.
	 * 
	 * @param key			AES-128 key
	 * @param micLength		MIC length in bits
	 * @param nonce			nonce
	 * @param clear			clear bytes
	 * @return				encrypted bytes
	 */
	public static byte[] encrypt(byte[] key, int micLength, byte[] nonce, byte[] clear) 
			throws Exception {		
        CCMBlockCipher cipher = new CCMBlockCipher(new AESEngine());        
		byte[] encrypted = null;
		
		try {
	        cipher.init(true, new CCMParameters(new KeyParameter(key), micLength, nonce, null));
			encrypted = new byte[cipher.getOutputSize(clear.length)];
			int len = cipher.processBytes(clear, 0, clear.length, encrypted, 0);
			cipher.doFinal(encrypted, len);
		} catch (Exception e) {
			Log.e(TAG, "Encryption error", e);
			throw e; // pass up Exception
		}
		
		return encrypted;
	}
	
	/**
	 * Does AES-CCM decryption and MIC verification.
	 * 
	 * @throws Exception if the operation fails.
	 * 
	 * @param key			AES-128 key
	 * @param micLength		MIC length in bits
	 * @param nonce			nonce
	 * @param encrypted		encrypted bytes
	 * @return				clear bytes
	 */
	public static byte[] decrypt(byte[] key, int micLength, byte[] nonce, byte[] encrypted)
		throws Exception {
        CCMBlockCipher cipher = new CCMBlockCipher(new AESEngine());        
		byte[] clear = null;
		
		try {
	        cipher.init(false, new CCMParameters(new KeyParameter(key), micLength, nonce, null));
			clear = new byte[cipher.getOutputSize(encrypted.length)];
			int len = cipher.processBytes(encrypted, 0, encrypted.length, clear, 0);
			cipher.doFinal(clear, len);
		} catch (Exception e) {
			Log.e(TAG, "Encryption error", e);
			throw e; // pass up Exception
		}
		
		return clear;
	}
	
	/**
	 * Dervce TCK for rekey message.
	 * 
	 * @param key
	 * @param p
	 * @return		TCK
	 * @throws Exception if the operation fails
	 */
	public static byte[] deriveTck(byte[] key, byte[] p) 
		throws Exception {
		BufferedBlockCipher cipher = new BufferedBlockCipher(new AESEngine());
		byte[] tck = null;

		try {
			cipher.init(true, new KeyParameter(key));
			tck = new byte[cipher.getOutputSize(p.length)];
			int len = cipher.processBytes(p, 0, p.length, tck, 0);
			cipher.doFinal(tck, len);
		}
		catch (Exception e) {
			Log.e(TAG, "Encryption error", e);
			throw e; // pass up Exception
		}
		
		return tck;
	}
	
}
