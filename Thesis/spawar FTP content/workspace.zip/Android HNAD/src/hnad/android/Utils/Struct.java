package hnad.android.Utils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;


/**
 * You may subclass this with a class that contains members annotated with @StructField. You don't have to initialize
 * Struct or byte[] fields. A new object will be created on {@code set(byte[])}. However unitialized fields will cause an exception on 
 * {@code get()}.
 * 
 * Below "x" is the ordering of the fields.
 * 
 * @StructField(pos=x)
 * public int value;
 * 
 * @StructField(pos=x,len=y) // where y is the array size, but also see below for dynamic size
 * public byte[] array;
 * 
 * @StructField(pos=x) // the array will consume the remaining bytes, meaning it should be declared last
 * public byte[] array;
 * 
 * @StructField(pos=x)
 * public byte b;
 * 
 * @StructField(pos=x) // Struct can contain other Structs
 * public MyStuct innerStruct;
 * 
 * Fields may be given default values:
 * 
 * @StructField(pos=x)
 * public byte value = 1;
 * 
 * @author cory
 *
 */
public abstract class Struct {
	
	/**
	 * This initializes the Struct's fields.
	 * 
	 * @throws IllegalArgumentException if your input is smaller the the size of the Struct, or if you use an unsupported @StructField.
	 * 
	 * @param bytes
	 */
	public void set(byte[] bytes) throws IllegalArgumentException {
		ByteBuffer buffer = ByteBuffer.wrap(bytes);
		set(buffer);
	}
	
	/**
	 * This method operates the same as {@code set(byte[])}. The reason for a separate private set method is to support nested
	 * Structs.
	 */
	private void set(ByteBuffer buffer) throws IllegalArgumentException {
		// get & sort the struct fields
		TreeSet<Field> structFields = new TreeSet<Field>(new StructFieldComparator());
		for (Field f : getClass().getDeclaredFields())
			if (f.isAnnotationPresent(StructField.class))
				structFields.add(f);
		
		Iterator<Field> iter = structFields.iterator();
		while (iter.hasNext()) {
			Field f = iter.next();
			
			@SuppressWarnings("rawtypes")
			Class type = f.getType();
			
			boolean fieldSet = true;
			
			try {
				if (type == int.class) {
					f.setInt(this, buffer.getInt());
				} else if (type == byte.class) {
					f.setByte(this, buffer.get());
				} else if (type == byte[].class) {
					int size = ((StructField)(f.getAnnotations()[0])).len();
					// size is 0, set then the array will consume the remainder of the buffer instead
					if (size == 0)
						size = buffer.remaining();

					byte[] temp = new byte[size];
					buffer.get(temp, 0, temp.length);
					f.set(this, temp);
				} else if (Struct.class.isAssignableFrom(type)) { // if Struct is a super of type
					Struct temp = (Struct) type.newInstance();
					temp.set(buffer);
					f.set(this, temp);
				} else {
					fieldSet =  false;
				}
			} catch (Exception e) {
				throw new IllegalArgumentException("Error parsing bytes into Struct", e);
			}
			
			if (!fieldSet) {
				throw new IllegalArgumentException("@StructField only supports Struct subclasses, int, byte, and byte[]");	
			}
		}
	}
	
	/**
	 * Gets the byte representation of the Struct.
	 * 
	 * @return The Struct as a byte array.
	 * 
	 * @throws IllegalArgumentException If the Struct has one or more {@code null} fields, i.e. unitialized byte[] or Structs 
	 * 									or if you use an unsupported @StructField.
	 */
	public byte[] get() throws IllegalArgumentException {
		// need to use ByteArrayOutputStream with DataOutputStream because
		// ByteBuffer does not resize like ByteArrayOutputStream
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		get(new DataOutputStream(out));
		
		// get array to return
		return out.toByteArray();
	}
	
	/**
	 * This method operates the same as {@code get()}. The reason for a separate private get method is to support nested
	 * Structs.
	 */
	private void get(DataOutputStream out) throws IllegalArgumentException {
		// get & sort the struct fields
		TreeSet<Field> structFields = new TreeSet<Field>(new StructFieldComparator());
		for (Field f : getClass().getDeclaredFields())
			if (f.isAnnotationPresent(StructField.class))
				structFields.add(f);
		
		Iterator<Field> iter = structFields.iterator();
		while (iter.hasNext()) {
			Field f = iter.next();
			
			@SuppressWarnings("rawtypes")
			Class type = f.getType();
			
			boolean fieldGot = true;
			
			try {
				if (type == int.class) {
					out.writeInt(f.getInt(this));
				} else if (type == byte.class) {
					out.writeByte(f.getByte(this));
				} else if (type == byte[].class) {
					out.write((byte[]) f.get(this));
				} else if (Struct.class.isAssignableFrom(type)) { // if Struct is a super of type
					Struct temp = (Struct) f.get(this);
					temp.get(out);
				} else {
					fieldGot =  false;
				}
			} catch (Exception e) {
				throw new IllegalArgumentException("Error writing bytes from Struct", e);
			}
			
			if (!fieldGot) {
				throw new IllegalArgumentException("@StructField only supports Struct subclasses, int, byte, and byte[]");	
			}
		}
	}
	
	private class StructFieldComparator implements Comparator<Field> {

		@Override
		public int compare(Field a, Field b) {
			
			StructField af = a.getAnnotation(StructField.class);
			StructField bf = b.getAnnotation(StructField.class);

			if (af == null || bf == null) {
				throw new IllegalArgumentException("Struct fields must have the @StructField annotation.");
			}
			
			return af.pos() - bf.pos();
		}
		
	}

}
