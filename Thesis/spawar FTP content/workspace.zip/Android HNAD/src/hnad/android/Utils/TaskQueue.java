package hnad.android.Utils;

import java.util.LinkedList;

/**
 * This class is an abstract implementation of a task queue thread. Objects
 * can be queued and will be dequeued one-by-one with some action being performed
 * on each.
 * 
 * @author Cory Sohrakoff
 *
 * @param <T>
 */
public abstract class TaskQueue<T> extends Thread {
	
	private volatile boolean mRunning = true;

	private final LinkedList<T> mQueue = new LinkedList<T>();
	
	private final Object lock = new Object();
	
	public TaskQueue() {
	}
	
	/**
	 * Add a packet to the task queue.
	 * 
	 * @param packet
	 */
	public final void enqueue(T object) {
		synchronized (lock) {
			mQueue.addLast(object);
			lock.notify();
		}
	}
	
	@Override
	public final void run() {
		T object;
		
		outer_loop:
		while (mRunning) {
			synchronized (lock) {
				while (mQueue.isEmpty())
					try {
						lock.wait(); // sleep until there's something in the queue
					} catch (InterruptedException e) {
						// if interrupted, break to outer loop
						break outer_loop;
					}
					
				object = mQueue.removeFirst();	
			}
			
			onDequeue(object);
		}
	}
	
	/**
	 * Implement this method to perform some action when an object is dequeued.
	 * 
	 * @param object
	 */
	protected abstract void onDequeue(T object);
	
	public final void stopRunning() {
		mRunning = false;
		interrupt(); // interrupt thread in case it is sleeping while waiting for new data.
	}
}
