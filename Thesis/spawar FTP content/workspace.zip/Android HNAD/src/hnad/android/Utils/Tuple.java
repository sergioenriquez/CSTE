package hnad.android.Utils;

/**
 * This generic class implements a tuple container to hold two values together.
 * 
 * @author cory
 *
 * @param <F>
 * @param <S>
 */
public class Tuple<F, S> {

	private F mFirst;
	private S mSecond;
	
	public Tuple(F first, S second) {
		mFirst = first;
		mSecond = second;
	}
	
	/**
	 * Get first value in the tuple.
	 * 
	 * @return
	 */
	public F getFirst() {
		return mFirst;
	}
	
	/**
	 * Get second value in the tuple.
	 * 
	 * @return
	 */
	public S getSecond() {
		return mSecond;
	}
}
