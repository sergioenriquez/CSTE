package org.bcandroid.asn1;

public interface ASN1String
{
    public String getString();
}
