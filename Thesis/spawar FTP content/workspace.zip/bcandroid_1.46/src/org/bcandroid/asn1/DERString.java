package org.bcandroid.asn1;

/**
 * basic interface for DER string objects.
 */
public interface DERString
    extends ASN1String
{

}
