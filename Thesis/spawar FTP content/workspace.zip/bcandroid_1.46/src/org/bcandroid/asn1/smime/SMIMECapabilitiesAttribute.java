package org.bcandroid.asn1.smime;

import org.bcandroid.asn1.DERSequence;
import org.bcandroid.asn1.DERSet;
import org.bcandroid.asn1.cms.Attribute;

public class SMIMECapabilitiesAttribute
    extends Attribute
{
    public SMIMECapabilitiesAttribute(
        SMIMECapabilityVector capabilities)
    {
        super(SMIMEAttributes.smimeCapabilities,
                new DERSet(new DERSequence(capabilities.toASN1EncodableVector())));
    }
}
