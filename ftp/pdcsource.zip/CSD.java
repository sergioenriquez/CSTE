/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.Timer;

/**
 *
 * @author Anton
 */
public class CSD {
    // Constructor
    boolean commandPending;
    byte alarmStatus, deviceOperatingMode, deviceType, doorStatus, restrictedErrorBits, restrictedErrorSection,
            restrictedStatusBits, sensorErrorBits, sensorOperatingMode;
    byte[] deviceUid, lastCommand, ltk, nadUid, reserved;
    int retryCounter;
    long receiveAscensionNumber, sendAscensionNumber;
    String conveyanceID, manifest, mechanicalSealId;
    Timer timer;
    boolean waitingForFirstRecord;
    CSD(byte[] uid) {
        this.alarmStatus = 0x00;
        this.commandPending = false;
        this.conveyanceID = "";
        this.deviceOperatingMode = 0x00;
        this.doorStatus = 0x00;
        this.lastCommand = null;
        this.ltk = new byte[16];
        this.manifest = "";
        this.mechanicalSealId = "";
        this.receiveAscensionNumber = 0;
        this.reserved = new byte[0];
        this.restrictedErrorBits = 0x00;
        this.restrictedErrorSection = 0x00;
        this.restrictedStatusBits = 0x00;
        this.retryCounter = 0;
        this.sendAscensionNumber = 0;
        this.sensorErrorBits = 0x00;
        this.sensorOperatingMode = 0x00;
        this.timer = null;
        this.deviceUid = uid;
        this.waitingForFirstRecord = false;
    }
    
    byte getAlarmStatus() {
        return alarmStatus;
    }

    boolean getCommandPending() {
        return commandPending;
    }
    
    String getConveyanceID() {
        return conveyanceID;
    }
    
    byte getDeviceOperatingMode() {
        return deviceOperatingMode;
    }
    
    byte getDeviceType() {
        return deviceType;
    }
    
    byte[] getDeviceUid() {
        return deviceUid;
    }
    
    byte getDoorStatus() {
        return doorStatus;
    }
    
    byte[] getLastCommand() {
        return lastCommand;
    }
    
    byte[] getLtk() {
        return ltk;
    }
    
    String getManifest() {
        return manifest;
    }
    
    String getMechanicalSealId() {
        return mechanicalSealId;
    }
    
    byte[] getNadUid() {
        return nadUid;
    }
    
    long getReceiveAscensionNumber() {
        return receiveAscensionNumber;
    }
    
    byte[] getReserved() {
        return reserved;
    }
    
    byte getRestrictedErrorBits() {
        return restrictedErrorBits;
    }
    
    byte getRestrictedErrorSection() {
        return restrictedErrorSection;
    }
    
    byte getRestrictedStatusBits() {
        return restrictedStatusBits;
    }
    
    int getRetryCounter() {
        return retryCounter;
    }
    
    long getSendAscensionNumber() {
        return sendAscensionNumber;
    }
    
    byte getSensorErrorBits() {
        return sensorErrorBits;
    }
    
    byte getSensorOperatingMode() {
        return sensorOperatingMode;
    }
    
    Timer getTimer() {
        return timer;
    }
    
    boolean getWaitingForFirstRecord() {
        return waitingForFirstRecord;
    }
    
    void setAlarmStatus(byte alarmStatus) {
        this.alarmStatus = alarmStatus;
    }
    
    void setCommandPending(boolean commandPending) {
        this.commandPending = commandPending;
    }
    
    void setConveyanceID(String conveyanceID) {
        this.conveyanceID = conveyanceID;
    }
    
    void setDeviceOperatingMode(byte deviceOperatingMode) {
        this.deviceOperatingMode = deviceOperatingMode;
    }
    
    void setDeviceType(byte deviceType) {
        this.deviceType = deviceType;
    }
    
    void setDeviceUid(byte[] deviceUid) {
        this.deviceUid = deviceUid;
    }
    
    void setDoorStatus(byte doorStatus) {
        this.doorStatus = doorStatus;
    }
    
    void setLastCommand(byte[] lastCommand) {
        this.lastCommand = lastCommand;
    }
    
    void setLtk(byte[] ltk) {
        this.ltk = ltk;
    }
    
    void setManifest(String manifest) {
        this.manifest = manifest;
    }
    
    void setMechanicalSealId(String mechanicalSealId) {
        this.mechanicalSealId = mechanicalSealId;
    }
    
    void setNadUid(byte[] nadUid) {
        this.nadUid = nadUid;
    }
    
    void setReceiveAscensionNumber(long receiveAscensionNumber) {
        this.receiveAscensionNumber = receiveAscensionNumber;
    }
    
    void setReserved(byte[] reserved) {
        this.reserved = reserved;
    }
    
    void setRestrictedErrorBits(byte restrictedErrorBits) {
        this.restrictedErrorBits = restrictedErrorBits;
    }
    
    void setRestrictedErrorSection(byte restrictedErrorSection) {
        this.restrictedErrorSection = restrictedErrorSection;
    }
    
    void setRestrictedStatusBits(byte restrictedStatusBits) {
        this.restrictedStatusBits = restrictedStatusBits;
    }
    
    void setRetryCounter(int retryCounter) {
        this.retryCounter = retryCounter;
    }
    
    void setSendAscensionNumber(long sendAscensionNumber) {
        this.sendAscensionNumber = sendAscensionNumber;
    }
    
    void setSensorErrorBits(byte sensorErrorBits) {
        this.sensorErrorBits = sensorErrorBits;
    }
    
    void setSensorOperatingMode(byte sensorOperatingMode) {
        this.sensorOperatingMode = sensorOperatingMode;
    }
    
    void setTimer(Timer timer) {
        this.timer = timer;
    }
    
    void setWaitingForFirstRecord(boolean waitingForFirstRecord) {
        this.waitingForFirstRecord = waitingForFirstRecord;
    }
}
