/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;

/**
 *
 * @author Anton
 */
public class CSDRegistry {
    private static List<CSD> sdr = new ArrayList<CSD>();
    
    static void add(CSD entry) {
        sdr.add(entry);
    }
    
    static void reset() {
        sdr = new ArrayList<CSD>();
    }
    
    static byte getAlarmStatus(int index) {
        return sdr.get(index).getAlarmStatus();
    }
    
    static boolean getCommandPending(int index) {
        return sdr.get(index).getCommandPending();
    }
    
    static String getConveyanceID(int index) {
        return sdr.get(index).getConveyanceID();
    }
    
    static byte getDeviceOperatingMode(int index) {
        return sdr.get(index).getDeviceOperatingMode();
    }
    
    static byte[] getDeviceUid(int index) {
        return sdr.get(index).getDeviceUid();
    }
    
    static byte getDeviceType(int index) {
        return sdr.get(index).getDeviceType();
    }
    
    static byte getDoorStatus(int index) {
        return sdr.get(index).getDoorStatus();
    }
    
    static int getIndexOf(byte[] deviceUid) {
        int index = -1;
        for (int i = 0; i < sdr.size(); i++) {
            if (Arrays.equals(sdr.get(i).getDeviceUid(), deviceUid))
                index = i;
        }
        return index;
    }
    
    static byte[] getLastCommand(int index) {
        return sdr.get(index).getLastCommand();
    }
    
    static byte[] getLtk(int index) {
        return sdr.get(index).getLtk();
    }
    
    static String getManifest(int index) {
        return sdr.get(index).getManifest();
    }
    
    static String getMechanicalSealId(int index) {
        return sdr.get(index).getMechanicalSealId();
    }
    
    static byte[] getNadUid(int index) {
        return sdr.get(index).getNadUid();
    }
    
    static long getReceiveAscensionNumber(int index) {
        return sdr.get(index).getReceiveAscensionNumber();
    }
    
    static byte[] getReserved(int index) {
        return sdr.get(index).getReserved();
    }
    
    static byte getRestrictedErrorBits(int index) {
        return sdr.get(index).getRestrictedErrorBits();
    }
    
    static byte getRestrictedErrorSection(int index) {
        return sdr.get(index).getRestrictedErrorSection();
    }
    
    static byte getRestrictedStatusBits(int index) {
        return sdr.get(index).getRestrictedStatusBits();
    }
    
    static int getRetryCounter(int index) {
        return sdr.get(index).getRetryCounter();
    }
    
    static long getSendAscensionNumber(int index) {
        return sdr.get(index).getSendAscensionNumber();
    }
    
    static byte getSensorErrorBits(int index) {
        return sdr.get(index).getSensorErrorBits();
    }
    
    static byte getSensorOperatingMode(int index) {
        return sdr.get(index).getSensorOperatingMode();
    }
    
    static Timer getTimer(int index) {
        return sdr.get(index).getTimer();
    }
    
    static boolean getWaitingForFirstRecord(int index) {
        return sdr.get(index).getWaitingForFirstRecord();
    }
    
    static void setAlarmStatus(int index, byte alarmStatus) {
        sdr.get(index).setAlarmStatus(alarmStatus);
    }
    
    static void setCommandPending(int index, boolean commandPending) {
        sdr.get(index).setCommandPending(commandPending);
    }
    
    static void setConveyanceID(int index, String conveyanceID) {
        sdr.get(index).setConveyanceID(conveyanceID);
    }
    
    static void setDeviceOperatingMode(int index, byte deviceOperatingMode) {
        sdr.get(index).setDeviceOperatingMode(deviceOperatingMode);
    }
    
    static void setDeviceType(int index, byte deviceType) {
        sdr.get(index).setDeviceType(deviceType);
    }
    
    static void setDoorStatus(int index, byte doorStatus) {
        sdr.get(index).setDoorStatus(doorStatus);
    }
    
    static void setLastCommand(int index, byte[] lastCommand) {
        sdr.get(index).setLastCommand(lastCommand);
    }
    
    static void setLtk(int index, byte[] ltk) {
        sdr.get(index).setLtk(ltk);
    }
    
    static void setManifest(int index, String manifest) {
        sdr.get(index).setManifest(manifest);
    }
    
    static void setMechanicalSealId(int index, String mechanicalSealId) {
        sdr.get(index).setMechanicalSealId(mechanicalSealId);
    }
    
    static void setNadUid(int index, byte[] nadUid) {
        sdr.get(index).setNadUid(nadUid);
    }
    
    static void setReceiveAscensionNumber(int index, long receiveAscensionNumber) {
        sdr.get(index).setReceiveAscensionNumber(receiveAscensionNumber);
    }
    
    static void setReserved(int index, byte[] reserved) {
        sdr.get(index).setReserved(reserved);
    }
    
    static void setRestrictedErrorBits(int index, byte restrictedErrorBits) {
        sdr.get(index).setRestrictedErrorBits(restrictedErrorBits);
    }
    
    static void setRestrictedErrorSection(int index, byte restrictedErrorSection) {
        sdr.get(index).setRestrictedErrorSection(restrictedErrorSection);
    }
    
    static void setRestrictedStatusBits(int index, byte restrictedStatusBits) {
        sdr.get(index).setRestrictedStatusBits(restrictedStatusBits);
    }
    
    static void setRetryCounter(int index, int retryCounter) {
        sdr.get(index).setRetryCounter(retryCounter);
    }
    
    static void setSendAscensionNumber(int index, long sendAscensionNumber) {
        sdr.get(index).setSendAscensionNumber(sendAscensionNumber);
    }
    
    static void setSensorErrorBits(int index, byte sensorErrorBits) {
        sdr.get(index).setSensorErrorBits(sensorErrorBits);
    }
    
    static void setSensorOperatingMode(int index, byte sensorOperatingMode) {
        sdr.get(index).setSensorOperatingMode(sensorOperatingMode);
    }
    
    static void setTimer(int index, Timer timer) {
        sdr.get(index).setTimer(timer);
    }
    
    static void setWaitingForFirstRecord(int index, boolean waitingForFirstRecord) {
        sdr.get(index).setWaitingForFirstRecord(waitingForFirstRecord);
    }
}
