/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.TimerTask;

/**
 *
 * @author Anton
 */
public class CommandTask extends TimerTask {
    private static final int maxTries = 5;
    
    private int drIndex;
    private long sendAscensionNumber;
    private String commandName;
    CommandTask(int drIndex, String commandName, long sendAscensionNumber) {
        this.drIndex = drIndex;
        this.commandName = commandName;
        this.sendAscensionNumber = sendAscensionNumber;
    }
    
    @Override
    public void run() {
        int retryCounter = ECoCRegistry.getRetryCounter(drIndex);
        byte[] deviceUid = ECoCRegistry.getDeviceUid(drIndex);
        String deviceUidString = Convert.byteArrayToHexString(deviceUid);
        if (ECoCRegistry.getCommandPending(drIndex) && retryCounter < maxTries) {
            int lrIndex = LocationRegistry.getIndexOf(ECoCRegistry.getNadUid(drIndex));
            if (lrIndex > -1) {
                String protocol = LocationRegistry.getProtocol(lrIndex);
                String nadUidString = Convert.byteArrayToHexString(LocationRegistry.getNadUid(lrIndex));
                if (protocol.equals("TCP")) {
                    TCPListener.send(ECoCRegistry.getLastCommand(drIndex), LocationRegistry.getSocket(lrIndex));
                }
                else
                    UDPListener.send(ECoCRegistry.getLastCommand(drIndex), LocationRegistry.getSocketAddress(lrIndex));
                UserInterface.printDebugText("Sent " + commandName + " to " + deviceUidString + " with ascension " +
                        sendAscensionNumber + " via " + nadUidString + ", attempt #" + (retryCounter + 1) + "...");
                Syslog.write(Syslog.NOTICE, "Sent " + commandName + " to " + deviceUidString + " with ascension " +
                        sendAscensionNumber + " via " + nadUidString + ", attempt #" + (retryCounter + 1) + "...");
                ECoCRegistry.setRetryCounter(drIndex, retryCounter + 1);
            }
            
        }
        else {
            if (retryCounter >= maxTries) {
                UserInterface.printDebugText("Maximum number of retries exceeded for " + deviceUidString);
                UserInterface.printEcocLabel("Maximum number of retries exceeded for " + deviceUidString);
                Syslog.write(Syslog.ALERT, "Maximum number of retries exceeded for " + deviceUidString);
            }
            ECoCRegistry.setCommandPending(drIndex, false);
            UserInterface.refreshEcocButton();
            cancel();
        }
    }
}
