/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class Configure {
    private static boolean useEncryption = true;
    private static String syslogAddress = "192.168.1.250";
    private static int syslogPort = 514;
    private static int tcpPort = 11000;
    private static int udpPort = 11001;
    private static byte[] uid = {0x0D, 0x0E, 0x0A, 0x0D, 0x0B, 0x0E, 0x0E, 0x0F};
    
    static boolean getCheckAscensionFlag() {
        return true;
    }
    
    static String getSyslogAddress() {
        return syslogAddress;
    }
    
    static int getSyslogPort() {
        return syslogPort;
    }
    
    static int getTCPPort() {
        return tcpPort;
    }
    
    static int getUDPPort() {
        return udpPort;
    }
    
    static byte[] getUID() {
        return uid;
    }
    
    static boolean getUseEncryption() {
        return useEncryption;
    }
    
    static void setSyslogPort(int newSyslogPort) {
        syslogPort = newSyslogPort;
    }
    
    static void setTCPPort(int newTCPPort) {
        tcpPort = newTCPPort;
    }
    
    static void setUDPPort(int newUDPPort) {
        udpPort = newUDPPort;
    }
    
    static void setUID(byte[] newUID) {
        uid = newUID;
    }
}
