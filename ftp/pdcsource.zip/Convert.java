/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.TimeZone;

/**
 *
 * @author Anton
 */
public class Convert {
    static String byteToHexString(byte b) {
        StringBuilder sb = new StringBuilder(4);
        String s = Integer.toHexString(b & 0xff);
        if (s.length() == 1)
            sb.append("0");
        sb.append(s);
        return sb.toString();
    }
    
    static String byteArrayToASCII(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length);
        for (int i = 0; i < b.length; i++) {
            try {
                byte[] ba = new byte[1];
                if (b[i] > 0x20 && b[i] < 0x7F)
                    ba[0] = b[i];
                else
                    ba[0] = 0x2E;
                sb.append(new String(ba, "US-ASCII"));
            }
            catch (UnsupportedEncodingException e) {
                UserInterface.printDebugText("Failed to convery byte array to ASCII due to " + e + ".");
            }
        }
        return sb.toString();
    }
    
    static String byteArrayToHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(2 + b.length * 2);
        for (int i = 0; i < b.length; i++) {
            String s = Integer.toHexString(b[i] & 0xff);
            if (s.length() == 1)
                sb.append("0");
            sb.append(s);
        }
        return sb.toString();
    }
    
    static byte[] hexStringToByteArray(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < s.length(); i += 2) {
            b[i / 2] = (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
        }
        return b;
    }
    
    static byte[] utcNowToICDTime() {
        byte[] t = new byte[8];
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        t[0] = (byte)(c.get(Calendar.MONTH) + 1);
        t[1] = (byte)c.get(Calendar.DATE);
        t[2] = (byte)(c.get(Calendar.YEAR) - 2000);
        t[3] = (byte)(c.get(Calendar.DAY_OF_WEEK) - 1);
        t[4] = (byte)c.get(Calendar.HOUR_OF_DAY);
        t[5] = (byte)c.get(Calendar.MINUTE);
        t[6] = (byte)c.get(Calendar.SECOND);
        t[7] = (byte)Math.round((float)c.get(Calendar.MILLISECOND) / 10);
        return t;
    }
    
    static Calendar icdTimeToCalendar(byte[] t) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int month = t[0] - 1;
        int day = t[1];
        int year = 2000 + t[2];
        int hour = t[4];
        int minute = t[5];
        int second = t[6];
        c.set(year, month, day, hour, minute, second);
        return c;
    }
}
