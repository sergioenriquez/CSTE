/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.Socket;
import java.net.SocketAddress;
import java.util.Date;
import java.util.Timer;

/**
 *
 * @author Anton
 */
public class ECoC {
    // Constructor
    boolean commandPending;
    byte deviceOperatingMode, deviceType, masterAlarm, restrictedErrorBits, restrictedErrorSection, restrictedStatusBits,
            sensorErrorBits;
    byte[] deviceUid, lastCommand, ltk, nadUid, reserved;
    int retryCounter, testInterval;
    long receiveAscensionNumber, sendAscensionNumber;
    String conveyanceID, gpsLocation;
    //SocketAddress socketAddress;
    Timer timer;
    
    Date universalTime;
    boolean waitingForFirstRecord;
    ECoC(byte[] uid) {
        this.commandPending = false;
        this.conveyanceID = "";
        this.deviceOperatingMode = 0x00;
        this.gpsLocation = "";
        this.lastCommand = null;
        this.ltk = new byte[16];
        this.masterAlarm = 0x00;
        this.receiveAscensionNumber = 0;
        this.reserved = new byte[0];
        this.restrictedErrorBits = 0x00;
        this.restrictedErrorSection = 0x00;
        this.restrictedStatusBits = 0x00;
        this.retryCounter = 0;
        this.sendAscensionNumber = 0;
        this.sensorErrorBits = 0x00;
        this.testInterval = 0;
        this.timer = null;
        this.deviceUid = uid;
        this.universalTime = new Date();
        this.waitingForFirstRecord = false;
    }

    
    // Get methods
    boolean getCommandPending() {
        return commandPending;
    }
    
    String getConveyanceID() {
        return conveyanceID;
    }
    
    byte getDeviceOperatingMode() {
        return deviceOperatingMode;
    }
    
    byte getDeviceType() {
        return deviceType;
    }
    
    byte[] getDeviceUid() {
        return deviceUid;
    }
    
    String getGPSLocation() {
        return gpsLocation;
    }
    
    byte[] getLastCommand() {
        return lastCommand;
    }
    
    byte[] getLtk() {
        return ltk;
    }
    
    byte getMasterAlarm() {
        return masterAlarm;
    }
    
    byte[] getNadUid() {
        return nadUid;
    }
    
    long getReceiveAscensionNumber() {
        return receiveAscensionNumber;
    }
    
    byte[] getReserved() {
        return reserved;
    }
    
    byte getRestrictedErrorBits() {
        return restrictedErrorBits;
    }
    
    byte getRestrictedErrorSection() {
        return restrictedErrorSection;
    }
    
    byte getRestrictedStatusBits() {
        return restrictedStatusBits;
    }
    
    int getRetryCounter() {
        return retryCounter;
    }
    
    long getSendAscensionNumber() {
        return sendAscensionNumber;
    }
    
    byte getSensorErrorBits() {
        return sensorErrorBits;
    }
    
    int getTestInterval() {
        return testInterval;
    }
    
    Timer getTimer() {
        return timer;
    }
    
    Date getUniversalTime() {
        return universalTime;
    }
    
    boolean getWaitingForFirstRecord() {
        return waitingForFirstRecord;
    }
    
    // Set methods
    void setCommandPending(boolean commandPending) {
        this.commandPending = commandPending;
    }
    
    void setConveyanceID(String conveyanceID) {
        this.conveyanceID = conveyanceID;
    }
    
    void setDeviceOperatingMode(byte deviceOperatingMode) {
        this.deviceOperatingMode = deviceOperatingMode;
    }
    
    void setDeviceType(byte deviceType) {
        this.deviceType = deviceType;
    }
    
    void setDeviceUid(byte[] deviceUid) {
        this.deviceUid = deviceUid;
    }
    
    void setGPSLocation(String gpsLocation) {
        this.gpsLocation = gpsLocation;
    }
    
    void setLastCommand(byte[] lastCommand) {
        this.lastCommand = lastCommand;
    }
    
    void setLtk(byte[] ltk) {
        this.ltk = ltk;
    }
    
    void setMasterAlarm(byte masterAlarm) {
        this.masterAlarm = masterAlarm;
    }
    
    void setNadUid(byte[] nadUid) {
        this.nadUid = nadUid;
    }
    
    void setReceiveAscensionNumber(long receiveAscensionNumber) {
        this.receiveAscensionNumber = receiveAscensionNumber;
    }
    
    void setReserved(byte[] reserved) {
        this.reserved = reserved;
    }
    
    void setRestrictedErrorBits(byte restrictedErrorBits) {
        this.restrictedErrorBits = restrictedErrorBits;
    }
    
    void setRestrictedErrorSection(byte restrictedErrorSection) {
        this.restrictedErrorSection = restrictedErrorSection;
    }
    
    void setRestrictedStatusBits(byte restrictedStatusBits) {
        this.restrictedStatusBits = restrictedStatusBits;
    }
    
    void setRetryCounter(int retryCounter) {
        this.retryCounter = retryCounter;
    }
    
    void setSendAscensionNumber(long sendAscensionNumber) {
        this.sendAscensionNumber = sendAscensionNumber;
    }
    
    void setSensorErrorBits(byte sensorErrorBits) {
        this.sensorErrorBits = sensorErrorBits;
    }
    
    void setTestInterval(int testInterval) {
        this.testInterval = testInterval;
    }
    
    void setTimer(Timer timer) {
        this.timer = timer;
    }
    
    void setUniversalTime(Date universalTime) {
        this.universalTime = universalTime;
    }
    
    void setWaitingForFirstRecord(boolean waitingForFirstRecord) {
        this.waitingForFirstRecord = waitingForFirstRecord;
    }
}
