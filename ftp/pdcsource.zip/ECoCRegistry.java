/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Timer;

/**
 *
 * @author Anton
 */
public class ECoCRegistry {
    private static List<ECoC> dr = new ArrayList<ECoC>();
    
    static void add(ECoC entry) {
        dr.add(entry);
    }
    
    static void reset() {
        dr = new ArrayList<ECoC>();
    }
    
    static boolean getCommandPending(int index) {
        return dr.get(index).getCommandPending();
    }
    
    static String getConveyanceID(int index) {
        return dr.get(index).getConveyanceID();
    }
    
    static byte getDeviceOperatingMode(int index) {
        return dr.get(index).getDeviceOperatingMode();
    }
    
    static byte[] getDeviceUid(int index) {
        return dr.get(index).getDeviceUid();
    }
    
    static byte getDeviceType(int index) {
        return dr.get(index).getDeviceType();
    }
    
    static String getGPSLocation(int index) {
        return dr.get(index).getGPSLocation();
    }
    
    static int getIndexOf(byte[] deviceUid) {
        int index = -1;
        for (int i = 0; i < dr.size(); i++) {
            if (Arrays.equals(dr.get(i).getDeviceUid(), deviceUid))
                index = i;
        }
        return index;
    }
    
    static byte[] getLastCommand(int index) {
        return dr.get(index).getLastCommand();
    }
    
    static byte[] getLtk(int index) {
        return dr.get(index).getLtk();
    }
    
    static byte getMasterAlarm(int index) {
        return dr.get(index).getMasterAlarm();
    }
    
    static byte[] getNadUid(int index) {
        return dr.get(index).getNadUid();
    }
    
    static long getReceiveAscensionNumber(int index) {
        return dr.get(index).getReceiveAscensionNumber();
    }
    
    static byte[] getReserved(int index) {
        return dr.get(index).getReserved();
    }
    
    static byte getRestrictedErrorBits(int index) {
        return dr.get(index).getRestrictedErrorBits();
    }
    
    static byte getRestrictedErrorSection(int index) {
        return dr.get(index).getRestrictedErrorSection();
    }
    
    static byte getRestrictedStatusBits(int index) {
        return dr.get(index).getRestrictedStatusBits();
    }
    
    static int getRetryCounter(int index) {
        return dr.get(index).getRetryCounter();
    }
    
    static long getSendAscensionNumber(int index) {
        return dr.get(index).getSendAscensionNumber();
    }
    
    static byte getSensorErrorBits(int index) {
        return dr.get(index).getSensorErrorBits();
    }
    
    static int getTestInterval(int index) {
        return dr.get(index).getTestInterval();
    }
    
    static Timer getTimer(int index) {
        return dr.get(index).getTimer();
    }
    
    static Date getUniversalTime(int index) {
        return dr.get(index).getUniversalTime();
    }
    
    static boolean getWaitingForFirstRecord(int index) {
        return dr.get(index).getWaitingForFirstRecord();
    }
    
    // Set methods
    static void setCommandPending(int index, boolean commandPending) {
        dr.get(index).setCommandPending(commandPending);
    }
    
    static void setConveyanceID(int index, String conveyanceID) {
        dr.get(index).setConveyanceID(conveyanceID);
    }
    
    static void setDeviceOperatingMode(int index, byte deviceOperatingMode) {
        dr.get(index).setDeviceOperatingMode(deviceOperatingMode);
    }
    
    static void setDeviceType(int index, byte deviceType) {
        dr.get(index).setDeviceType(deviceType);
    }
    
    static void setGPSLocation(int index, String gpsLocation) {
        dr.get(index).setGPSLocation(gpsLocation);
    }
    
    static void setLastCommand(int index, byte[] lastCommand) {
        dr.get(index).setLastCommand(lastCommand);
    }
    
    static void setLtk(int index, byte[] ltk) {
        dr.get(index).setLtk(ltk);
    }
    
    static void setMasterAlarm(int index, byte masterAlarm) {
        dr.get(index).setMasterAlarm(masterAlarm);
    }
    
    static void setNadUid(int index, byte[] nadUid) {
        dr.get(index).setNadUid(nadUid);
    }
    
    static void setReceiveAscensionNumber(int index, long receiveAscensionNumber) {
        dr.get(index).setReceiveAscensionNumber(receiveAscensionNumber);
    }
    
    static void setReserved(int index, byte[] reserved) {
        dr.get(index).setReserved(reserved);
    }
    
    static void setRestrictedErrorBits(int index, byte restrictedErrorBits) {
        dr.get(index).setRestrictedErrorBits(restrictedErrorBits);
    }
    
    static void setRestrictedErrorSection(int index, byte restrictedErrorSection) {
        dr.get(index).setRestrictedErrorSection(restrictedErrorSection);
    }
    
    static void setRestrictedStatusBits(int index, byte restrictedStatusBits) {
        dr.get(index).setRestrictedStatusBits(restrictedStatusBits);
    }
    
    static void setRetryCounter(int index, int retryCounter) {
        dr.get(index).setRetryCounter(retryCounter);
    }
    
    static void setSendAscensionNumber(int index, long sendAscensionNumber) {
        dr.get(index).setSendAscensionNumber(sendAscensionNumber);
    }
    
    static void setSensorErrorBits(int index, byte sensorErrorBits) {
        dr.get(index).setSensorErrorBits(sensorErrorBits);
    }
    
    static void setTestInterval(int index, int testInterval) {
        dr.get(index).setTestInterval(testInterval);
    }
    
    static void setTimer(int index, Timer timer) {
        dr.get(index).setTimer(timer);
    }
    
    static void setUniversalTime(int index, Date universalTime) {
        dr.get(index).setUniversalTime(universalTime);
    }
    
    static void setWaitingForFirstRecord(int index, boolean waitingForFirstRecord) {
        dr.get(index).setWaitingForFirstRecord(waitingForFirstRecord);
    }
}
