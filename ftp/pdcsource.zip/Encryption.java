/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.modes.CCMBlockCipher;
import org.bouncycastle.crypto.params.CCMParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;

/**
 *
 * @author Anton
 */
public class Encryption {
    static byte[] decrypt(byte[] key, int micLength, byte[] nonce, byte[] c) {
        byte[] p = null;
        CCMBlockCipher cipher = new CCMBlockCipher(new AESEngine());
        cipher.init(false, new CCMParameters(new KeyParameter(key), micLength, nonce, null));
        p = new byte[cipher.getOutputSize(c.length)];
        cipher.processBytes(c, 0, c.length, p, 0);
        try {
            cipher.doFinal(p, 0);
        }
        catch (Exception e) {
            UserInterface.printDebugText("CCM decryption failed: " + e);
        }
        return p;
    }
    
    static byte[] deriveTCK(byte[] key, byte[] p) {
        byte[] TCK = null;
        BufferedBlockCipher cipher = new BufferedBlockCipher(new AESEngine());
        cipher.init(true, new KeyParameter(key));
        TCK = new byte[cipher.getOutputSize(p.length)];
        cipher.processBytes(p, 0, p.length, TCK, 0);
        try {
            cipher.doFinal(TCK, 0);
        }
        catch (Exception e) {
            UserInterface.printDebugText("TCK derivation failed: " + e);
        }
        return TCK;
    }
    
    static byte[] encrypt(byte[] key, int micLength, byte[] nonce, byte[] p) {
        byte[] c = null;
        CCMBlockCipher cipher = new CCMBlockCipher(new AESEngine());
	cipher.init(true, new CCMParameters(new KeyParameter(key), micLength, nonce, null));
        c = new byte[cipher.getOutputSize(p.length)];
        cipher.processBytes(p, 0, p.length, c, 0);
        try {
            cipher.doFinal(c, 0);
        }
        catch (Exception e) {
            UserInterface.printDebugText("CCM encryption failed: " + e);
        }
        return c;
    }
    
    static void testRekey() {
        byte[] RK = Hex.decode("F65143C3652AF21962AA86C7B1E55B21");
        byte[] p = Hex.decode("89E020F34DBB54907298650100000001");
        byte[] nonce = Hex.decode("89E0200100000001");
        byte[] LTK = Hex.decode("5CFFEA7E13EA6FCC8045CB6F8D31B942");
        
        byte[] TCK = deriveTCK(RK, p);
        UserInterface.printDebugText("TCK: " + Convert.byteArrayToHexString(TCK));
        
        byte[] ciphertext = encrypt(TCK, 128, nonce, LTK);
        UserInterface.printDebugText("Ciphertext: " + Convert.byteArrayToHexString(ciphertext));
        
        byte[] plaintext = decrypt(TCK, 128, nonce, ciphertext);
        UserInterface.printDebugText("Plaintext: " + Convert.byteArrayToHexString(plaintext));
    }
    
    static void runTest() {
        byte[] LTK = Hex.decode("5CFFEA7E13EA6FCC8045CB6F8D31B942");
        byte[] P1 = Hex.decode("880000F354B5448C619A6C0000000000");
        byte[] nonce = Hex.decode("88C1090100000001");
        byte[] plaintext = Hex.decode("00");
        
        byte[] TCK = deriveTCK(LTK, P1);
        UserInterface.printDebugText("TCK: " + Convert.byteArrayToHexString(TCK));
        
        byte[] ciphertext = encrypt(TCK, 64, nonce, plaintext);
        UserInterface.printDebugText("Ciphertext: " + Convert.byteArrayToHexString(ciphertext));
        
        plaintext = decrypt(TCK, 64, nonce, ciphertext);
        UserInterface.printDebugText("Plaintext: " + Convert.byteArrayToHexString(plaintext));
    }
}
