/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class EventLogRecordFromECoC {
    boolean isValid;
    byte ackAscensionNumber, deviceOperatingMode, deviceType, eventType, icdRevisionNumber, lockStatus, messageLength,
            messageType, reserved, restrictedErrorBits, restrictedStatusBits;
    byte[] ascensionNumber, body, conveyanceId, deviceStatusSection, deviceUid, gpsLocation, logRecordNumber, universalTime, header;
    EventLogRecordFromECoC(byte[] message) {
        // Initialize booleans
        isValid = false;
        
        // Compare message to expected length
        if (message.length == 77) {
            // Extract header
            header = new byte[16];
            System.arraycopy(message, 0, header, 0, header.length);
            
            // Parse header
            deviceType = header[0];
            messageType = header[1];
            messageLength = header[2];
            deviceUid = new byte[8];
            System.arraycopy(header, 3, deviceUid, 0, deviceUid.length);
            icdRevisionNumber = header[11];
            ascensionNumber = new byte[4];
            System.arraycopy(header, 12, ascensionNumber, 0, ascensionNumber.length);
            
            // Extract body
            body = new byte[61];
            System.arraycopy(message, header.length, body, 0, body.length);
            
            // Parse body
            ackAscensionNumber = body[0];
            logRecordNumber = new byte[2];
            System.arraycopy(body, 1, logRecordNumber, 0, logRecordNumber.length);
            eventType = body[3];
            universalTime = new byte[8];
            System.arraycopy(body, 4, universalTime, 0, universalTime.length);
            deviceStatusSection = new byte[41];
            System.arraycopy(body, 12, deviceStatusSection, 0, deviceStatusSection.length);
            reserved = deviceStatusSection[0];
            deviceOperatingMode = deviceStatusSection[1];
            restrictedStatusBits = deviceStatusSection[2];
            restrictedErrorBits = deviceStatusSection[3];
            conveyanceId = new byte[16];
            System.arraycopy(deviceStatusSection, 4, conveyanceId, 0, conveyanceId.length);
            gpsLocation = new byte[20];
            System.arraycopy(deviceStatusSection, 20, gpsLocation, 0, gpsLocation.length);
            lockStatus = deviceStatusSection[40];
            
            // Validate message length from header
            if (messageLength != body.length) {
                UserInterface.printDebugText("Message length from header is incorrect. Expecting " + messageLength + ", got " + body.length);
            }
            else
                isValid = true;
        }
        else {
            UserInterface.printDebugText("Incorrect length for event log record. Expecting 77, got " + message.length);
            Syslog.write(Syslog.ERROR, "Incorrect length for event log record. Expecting 77, got " + message.length);
        }
    }
}
