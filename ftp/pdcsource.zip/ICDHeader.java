/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class ICDHeader {
    boolean validHeader = false;
    byte deviceType, icdRevisionNumber, messageLength, messageType;
    byte[] deviceUid, ascensionNumber;
    ICDHeader(byte[] message) {
        // Assume the header is valid if the message is greater than 16 bytes
        if (message.length > 16)
            validHeader = true;
        
        // Parse the header if it is valid
        if (validHeader) {
            deviceType = message[0];
            messageType = message[1];
            messageLength = message[2];
            deviceUid = new byte[8];
            System.arraycopy(message, 3, deviceUid, 0, 8);
            icdRevisionNumber = message[11];
            ascensionNumber = new byte[4];
            System.arraycopy(message, 12, ascensionNumber, 0, 4);
        }
    }
}
