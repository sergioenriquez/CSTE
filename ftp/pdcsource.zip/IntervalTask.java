/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.TimerTask;

/**
 *
 * @author Anton
 */
public class IntervalTask extends TimerTask {
    private int index;
    public IntervalTask(int index) {
        this.index = index;
    }
    
    @Override
    public void run() {
        UserInterface.printDebugText("IntervalTask has fired.");
    }
}
