/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Anton
 */
public class LocationRegistry {
    private static List<LocationRegistryRecord> lr = new ArrayList<LocationRegistryRecord>();
    
    static int getIndexOf(byte[] nadUid) {
        int index = -1;
        for (int i = 0; i < lr.size(); i++) {
            if (Arrays.equals(lr.get(i).getNadUid(), nadUid))
                index = i;
        }
        return index;
    }
    
    static byte[] getNadUid(int index) {
        return lr.get(index).getNadUid();
    }
    
    static String getProtocol(int index) {
        return lr.get(index).getProtocol();
    }
    
    static Socket getSocket(int index) {
        return lr.get(index).getSocket();
    }
    
    static SocketAddress getSocketAddress(int index) {
        return lr.get(index).getSocketAddress();
    }
    
    static void setProtocol(int index, String protocol) {
        lr.get(index).setProtocol(protocol);
    }
    
    static void setSocket(int index, Socket socket) {
        lr.get(index).setSocket(socket);
    }
    
    static void setSocketAddress(int index, SocketAddress socketAddress) {
        lr.get(index).setSocketAddress(socketAddress);
    }
    
    static void updateTcp(byte[] nadUid, Socket socket) {
        int index = getIndexOf(nadUid);
        if (index == -1) {
            lr.add(new LocationRegistryRecord(nadUid));
            index = getIndexOf(nadUid);
        }
        setProtocol(index, "TCP");
        setSocket(index, socket);
    }
    
    static void updateUdp(byte[] nadUid, SocketAddress socketAddress) {
        int index = getIndexOf(nadUid);
        if (index == -1) {
            lr.add(new LocationRegistryRecord(nadUid));
            index = getIndexOf(nadUid);
        }
        setProtocol(index, "UDP");
        setSocketAddress(index, socketAddress);
    }
}