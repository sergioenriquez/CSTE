/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.Socket;
import java.net.SocketAddress;

/**
 *
 * @author Anton
 */
public class LocationRegistryRecord {
    String protocol;
    Socket socket;
    SocketAddress socketAddress;
    byte[] nadUid;
    LocationRegistryRecord(byte[] nadUid) {
        this.nadUid = nadUid;
    }
    
    byte[] getNadUid() {
        return nadUid;
    }
    
    String getProtocol() {
        return protocol;
    }
    
    Socket getSocket() {
        return socket;
    }
    
    SocketAddress getSocketAddress() {
        return socketAddress;
    }
    
    void setProtocol(String protocol) {
        this.protocol = protocol;
    }
    
    void setSocket(Socket socket) {
        this.socket = socket;
    }
    
    void setSocketAddress(SocketAddress socketAddress) {
        this.socketAddress = socketAddress;
    }
}