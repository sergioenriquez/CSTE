/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.util.Random;

/**
 *
 * @author Anton
 */
public class MessageHandler {    
    static synchronized byte[] getNadUidFromReceiveData(byte[] receiveData) {
        byte[] nadUid = new byte[8];
        System.arraycopy(receiveData, 3, nadUid, 0, nadUid.length);
        return nadUid;
    }
    
    static synchronized byte[] getNadUidFromSendData(byte[] sendData) {
        byte[] nadUid = new byte[8];
        System.arraycopy(sendData, 11, nadUid, 0, nadUid.length);
        return nadUid;
    }
    
    static synchronized byte[] stripPreamble(byte[] receiveData) {
        int preambleLength = 11;
        byte[] message = new byte[receiveData.length - preambleLength];
        System.arraycopy(receiveData, preambleLength, message, 0, message.length);
        return message;
    }
    
    static synchronized void parseTcp(byte[] receiveData, Socket s) {
        // Extract function code from preamble
        byte[] functionCodeBytes = new byte[4];
        System.arraycopy(receiveData, 1, functionCodeBytes, 2, 2);
        int functionCode = ByteBuffer.wrap(functionCodeBytes).getInt();
        
        // Extract NAD UID from preamble
        byte[] nadUid = new byte[8];
        System.arraycopy(receiveData, 3, nadUid, 0, nadUid.length);
        
        // Initialize response
        byte[] sendData = null;
        
        UserInterface.printDebugText("Function code: " + functionCode);
        
        // Function code 0: Heartbeat request
        if (functionCode == 0) {
            LocationRegistry.updateTcp(nadUid, s);
            sendData = makeHeartbeatResponse();
        }
        // Function code 10: ICD message
        else if (functionCode == 10) {
            LocationRegistry.updateTcp(nadUid, s);
            byte[] message = stripPreamble(receiveData);
            ICDHeader header = new ICDHeader(message);
            if (header.validHeader) {
                // Message type 0x00: Unrestricted status message
                if (header.deviceType == (byte)0x82 && header.messageType == 0x00)
                    sendData = parseUnrestrictedStatusMessage(nadUid, message);
                // Message type 0x80: Restricted status message from CSD
                else if (header.deviceType == (byte)0x81 && header.messageType == (byte)0x80)
                    sendData = parseRestrictedStatusMessageFromCSD(nadUid, message);
                // Message type 0x80: Restricted status message from ECoC
                else if (header.deviceType == (byte)0x82 && header.messageType == (byte)0x80)
                    sendData = parseRestrictedStatusMessageFromECoC(nadUid, message);
                // Message type 0x81: Event log record
                else if (header.deviceType == (byte)0x82 && header.messageType == (byte)0x81)
                    sendData = parseEventLogRecord(nadUid, message);
                // Anything else!
                else
                    UserInterface.printDebugText("Non-recognized device or message type. Contents: " + Convert.byteArrayToHexString(message));
            }
            else
                UserInterface.printDebugText("Invalid header. Contents: " + Convert.byteArrayToHexString(message));
        }
        else
            UserInterface.printDebugText("Invalid function code. Contents: " + Convert.byteArrayToHexString(receiveData));
        
        // Send response
        if (sendData != null)
            TCPListener.send(sendData, s);
    }
    
    static synchronized void parseUdp(byte[] receiveData, SocketAddress sa) {
        // Extract function code from preamble
        byte[] functionCodeBytes = new byte[4];
        System.arraycopy(receiveData, 1, functionCodeBytes, 2, 2);
        int functionCode = ByteBuffer.wrap(functionCodeBytes).getInt();
        
        // Extract NAD UID from preamble
        byte[] nadUid = new byte[8];
        System.arraycopy(receiveData, 3, nadUid, 0, nadUid.length);
        
        // Initialize response
        byte[] sendData = null;
        
        // Function code 0: Heartbeat request
        if (functionCode == 0) {
            LocationRegistry.updateUdp(nadUid, sa);
            sendData = makeHeartbeatResponse();
        }
        // Function code 10: ICD message
        else if (functionCode == 10) {
            LocationRegistry.updateUdp(nadUid, sa);
            byte[] message = stripPreamble(receiveData);
            ICDHeader header = new ICDHeader(message);
            if (header.validHeader) {
                // Message type 0x00: Unrestricted status message
                if (header.deviceType == (byte)0x82 && header.messageType == 0x00)
                    sendData = parseUnrestrictedStatusMessage(nadUid, message);
                // Message type 0x80: Restricted status message from CSD
                else if (header.deviceType == (byte)0x81 && header.messageType == (byte)0x80)
                    sendData = parseRestrictedStatusMessageFromCSD(nadUid, message);
                // Message type 0x80: Restricted status message from ECoC
                else if (header.deviceType == (byte)0x82 && header.messageType == (byte)0x80)
                    sendData = parseRestrictedStatusMessageFromECoC(nadUid, message);
                // Message type 0x81: Event log record
                else if (header.deviceType == (byte)0x82 && header.messageType == (byte)0x81)
                    sendData = parseEventLogRecord(nadUid, message);
                // Anything else!
                else
                    UserInterface.printDebugText("Non-recognized device or message type. Contents: " + Convert.byteArrayToHexString(message));
            }
            else
                UserInterface.printDebugText("Invalid header. Contents: " + Convert.byteArrayToHexString(message));
        }
        else
            UserInterface.printDebugText("Invalid function code. Contents: " + Convert.byteArrayToHexString(receiveData));
        
        // Send response
        if (sendData != null)
            UDPListener.send(sendData, sa);
    }
    
    static synchronized byte[] parseEventLogRecord(byte[] nadUid, byte[] message) {
        // Initialize return message
        byte[] sendData = null;
        
        UserInterface.printDebugText("IN: " + Convert.byteArrayToHexString(message));
        
        // Parse and validate message structure
        EventLogRecordFromECoC elr = new EventLogRecordFromECoC(message);
        if (!elr.isValid) {
            UserInterface.printDebugText("Received invalid event log record");
            Syslog.write(Syslog.ERROR, "Received invalid event log record");
            return sendData;
        }
        
        // Find UID in the device registry
        String deviceUidString = Convert.byteArrayToHexString(elr.deviceUid);
        int index = ECoCRegistry.getIndexOf(elr.deviceUid);
        if (index == -1) {
            UserInterface.printDebugText("Discarding event log record from unknown device " + deviceUidString);
            Syslog.write(Syslog.ERROR, "Discarding event log record from unknown device " + deviceUidString);
            return sendData;
        }
        
        // Ensure that logs are expected
        if (!ECoCRegistry.getCommandPending(index)) {
            UserInterface.printDebugText("Discarding unexpected event log record from " + deviceUidString);
            Syslog.write(Syslog.ERROR, "Discarding unexpected event log record from " + deviceUidString);
            return sendData;
        }
        
        // Parse event log record number
        byte[] bufferedLogRecordNumber = new byte[4];
        System.arraycopy(elr.logRecordNumber, 0, bufferedLogRecordNumber, 2, 2);
        int logRecordNumber = ByteBuffer.wrap(bufferedLogRecordNumber).getInt();
        
        // Validate ascension number
        byte[] bufferedReceiveAscensionNumber = new byte[8];
        System.arraycopy(elr.ascensionNumber, 0, bufferedReceiveAscensionNumber, 4, 4);
        long receiveAscensionNumber = ByteBuffer.wrap(bufferedReceiveAscensionNumber).getLong();
        long lastReceiveAscensionNumber = ECoCRegistry.getReceiveAscensionNumber(index);
        if (receiveAscensionNumber > lastReceiveAscensionNumber) {
            // Valid ascension number
            UserInterface.printDebugText("Received event log record " + logRecordNumber + " from " + deviceUidString);
            Syslog.write(Syslog.NOTICE, "Received event log record " + logRecordNumber + " from " + deviceUidString);
            if (receiveAscensionNumber > lastReceiveAscensionNumber + 1) {
                // Skipped messages
                UserInterface.printDebugText("Ascension number of event log record from " + deviceUidString +
                        " indicates skipped messages: expecting " + (lastReceiveAscensionNumber + 1) + ", received " +
                        receiveAscensionNumber);
                Syslog.write(Syslog.WARNING, "Ascension number of event log record from " + deviceUidString +
                        " indicates skipped messages: expecting " + (lastReceiveAscensionNumber + 1) + ", received " +
                        receiveAscensionNumber);
            }
            
            // Update device registry
            ECoCRegistry.setReceiveAscensionNumber(index, receiveAscensionNumber);
            
            // Refresh device table
            UserInterface.updateEcocTable(index);
        }
        else {
            if (receiveAscensionNumber == lastReceiveAscensionNumber) {
                // Retransmission
                UserInterface.printDebugText("Event log record " + logRecordNumber + " from " + deviceUidString + " is a retransmission, resending ACK");
                Syslog.write(Syslog.NOTICE, "Event log record " + logRecordNumber + " from " + deviceUidString + " is a retransmission, resending ACK");
                sendData = ECoCRegistry.getLastCommand(index);
            }
            else {
                // Invalid ascension number
                UserInterface.printDebugText("Ascension number of event log record " + logRecordNumber + " from " + deviceUidString +
                        " is invalid: expecting " + (lastReceiveAscensionNumber + 1) + ", received " + receiveAscensionNumber);
                Syslog.write(Syslog.ERROR, "Ascension number of event log record " + logRecordNumber + " from " + deviceUidString +
                        " is invalid: expecting " + (lastReceiveAscensionNumber + 1) + ", received " + receiveAscensionNumber);
            }
            return sendData;
        }
                
        // See if this is the first log in the sequence
        byte[] sendAscensionNumberBytes = ByteBuffer.allocate(8).putLong(ECoCRegistry.getSendAscensionNumber(index)).array();
        if (ECoCRegistry.getWaitingForFirstRecord(index) && (elr.ackAscensionNumber == sendAscensionNumberBytes[7])) {
            UserInterface.printDebugText("Received first log in the sequence");
            Syslog.write(Syslog.NOTICE, "Received first log in the sequence");
            ECoCRegistry.setWaitingForFirstRecord(index, false);  
        }
        
        // Generate ACK
        UserInterface.printDebugText("Sending ACK to " + deviceUidString + "...");
        ECoCRegistry.setSendAscensionNumber(index, ECoCRegistry.getSendAscensionNumber(index) + 1);
        byte[] params = new byte[1];
        params[0] = elr.ascensionNumber[3];
        sendData = makeRestrictedCommand(elr.deviceUid, (byte)0x01, params);
        ECoCRegistry.setLastCommand(index, sendData);
        
        // See if this is the last log in the sequence
        if (elr.eventType == (byte)0xFF) {
            UserInterface.printDebugText("Received last log in the sequence");
            Syslog.write(Syslog.NOTICE, "Received last log in the sequence");
            UserInterface.printDebugText("Message from " + deviceUidString + " is a valid response to the previous command");
            UserInterface.printEcocLabel("Message from " + deviceUidString + " is a valid response to the previous command");
            Syslog.write(Syslog.NOTICE, "Message from " + deviceUidString + " is a valid response to the previous command");
            ECoCRegistry.setCommandPending(index, false);
            ECoCRegistry.getTimer(index).cancel();
            UserInterface.refreshEcocButton();
        }
        else {
            // Establish timeout timer
            ECoCRegistry.getTimer(index).cancel();
            //Timer timer = new Timer();
            //timer.schedule(new TimeoutTask(index), 2000);
            //DeviceRegistry.setTimer(index, timer);
        }

        return sendData;
    }
    
    static synchronized byte[] parseRestrictedStatusMessageFromECoC(byte[] nadUid, byte[] message) {
        UserInterface.printDebugText("Restricted status message: " + Convert.byteArrayToHexString(message));
        
        // Initialize return message
        byte[] sendData = null;
        
        // Process message
        RestrictedStatusMessageFromECoC rsm = new RestrictedStatusMessageFromECoC(message);
        if (rsm.isValid) {
            String deviceUidString = Convert.byteArrayToHexString(rsm.deviceUid);
            
            // Check to see if message was unsolicited
            if (rsm.isUnsolicited) {
                UserInterface.printDebugText("Received unsolicited restricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received unsolicited restricted status from " + deviceUidString);
            }
            else {
                UserInterface.printDebugText("Received solicited restricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received solicited restricted status from " + deviceUidString);
            }
            
            // Create new database entry if needed
            int index = ECoCRegistry.getIndexOf(rsm.deviceUid);
            if (index == -1) {
                ECoCRegistry.add(new ECoC(rsm.deviceUid));
                index = ECoCRegistry.getIndexOf(rsm.deviceUid);
                UserInterface.printDebugText("New UID " + deviceUidString + " added to the device registry");
            }
            
            // Update device registry
            ECoCRegistry.setNadUid(index, nadUid);
            
            // Validate ascension number
            byte[] modifiedReceiveAscensionNumber = new byte[8];
            System.arraycopy(rsm.ascensionNumber, 0, modifiedReceiveAscensionNumber, 4, 4);
            long receiveAscensionNumber = ByteBuffer.wrap(modifiedReceiveAscensionNumber).getLong();
            long lastReceiveAscensionNumber = ECoCRegistry.getReceiveAscensionNumber(index);
            if (receiveAscensionNumber > lastReceiveAscensionNumber) {
                // Check for skipped messages
                if (receiveAscensionNumber > lastReceiveAscensionNumber + 1) {
                    UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                    Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                }
                
                // Update device registry
                ECoCRegistry.setDeviceType(index, rsm.deviceType);
                ECoCRegistry.setReceiveAscensionNumber(index, receiveAscensionNumber);
                ECoCRegistry.setRestrictedErrorSection(index, rsm.restrictedErrorSection);
                ECoCRegistry.setDeviceOperatingMode(index, rsm.deviceOperatingMode);
                ECoCRegistry.setRestrictedStatusBits(index, rsm.restrictedStatusBits);
                ECoCRegistry.setRestrictedErrorBits(index, rsm.restrictedErrorBits);
                ECoCRegistry.setSensorErrorBits(index, rsm.sensorErrorBits);
                byte[] modifiedConveyanceId = new byte[15];
                System.arraycopy(rsm.conveyanceId, 1, modifiedConveyanceId, 0, modifiedConveyanceId.length);
                ECoCRegistry.setConveyanceID(index, Convert.byteArrayToASCII(modifiedConveyanceId));
                ECoCRegistry.setUniversalTime(index, Convert.icdTimeToCalendar(rsm.universalTime).getTime());
                ECoCRegistry.setGPSLocation(index, Convert.byteArrayToASCII(rsm.gpsLocation));
                ECoCRegistry.setMasterAlarm(index, rsm.masterAlarm);
                ECoCRegistry.setReserved(index, rsm.reserved);
                
                // Check to see if a command is already pending
                boolean commandPending = ECoCRegistry.getCommandPending(index);
                if (rsm.isUnsolicited) {
                    if (commandPending) {
                        UserInterface.printDebugText("Outstanding command to " + deviceUidString + " has been preempted");
                        UserInterface.printEcocLabel("Outstanding command to " + deviceUidString + " has been preempted");
                        Syslog.write(Syslog.ALERT, "Outstanding command to " + deviceUidString + " has been preempted");
                        ECoCRegistry.setCommandPending(index, false);
                        ECoCRegistry.getTimer(index).cancel();
                        UserInterface.refreshEcocButton();
                    }
                    UserInterface.printDebugText("Sending ACK to " + deviceUidString + "...");
                    ECoCRegistry.setSendAscensionNumber(index, ECoCRegistry.getSendAscensionNumber(index) + 1);
                    byte[] params = new byte[1];
                    params[0] = rsm.ascensionNumber[3];
                    sendData = makeRestrictedCommand(rsm.deviceUid, (byte)0x01, params);
                    ECoCRegistry.setLastCommand(index, sendData);
                }
                else { 
                    byte[] sendAscensionNumberBytes = ByteBuffer.allocate(8).putLong(ECoCRegistry.getSendAscensionNumber(index)).array();
                    if (commandPending && (rsm.ackAscensionNumber == sendAscensionNumberBytes[7])) {
                        UserInterface.printDebugText("Message from " + deviceUidString + " is a valid response to the previous command");
                        UserInterface.printEcocLabel("Message from " + deviceUidString + " is a valid response to the previous command");
                        Syslog.write(Syslog.NOTICE, "Message from " + deviceUidString + " is a valid response to the previous command");
                        ECoCRegistry.setCommandPending(index, false);
                        ECoCRegistry.getTimer(index).cancel();
                        UserInterface.refreshEcocButton();
                    }
                    else if (!commandPending) {
                        UserInterface.printDebugText("Was not expecting solicited status from " + deviceUidString);
                        Syslog.write(Syslog.WARNING, "Was not expecting solicited status from " + deviceUidString);
                    }
                    else {
                        UserInterface.printDebugText("ACK ascension number check failed on message from " + deviceUidString);
                        UserInterface.printDebugText("rsm.ackAscensionNumber: " + Convert.byteToHexString(rsm.ackAscensionNumber));
                        UserInterface.printDebugText("sendAscensionNumberBytes[7]: " + Convert.byteToHexString(sendAscensionNumberBytes[7]));
                        Syslog.write(Syslog.ERROR, "ACK ascension number check failed on message from " + deviceUidString);
                    }
                }
            
                // Refresh device table
                UserInterface.updateEcocTable(index);
            }
            // Duplicate ascension case
            else if (receiveAscensionNumber == lastReceiveAscensionNumber) {
                if (rsm.isUnsolicited) {
                    UserInterface.printDebugText("Resending ACK to " + deviceUidString + "...");
                    sendData = ECoCRegistry.getLastCommand(index);
                }
                else {
                    UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                    Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                }
            }
            // Invalid ascension case
            else {
                UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
            }
        }
        
        return sendData;
    }
    
    static synchronized byte[] parseRestrictedStatusMessageFromCSD(byte[] nadUid, byte[] message) {
        UserInterface.printDebugText("Restricted status message: " + Convert.byteArrayToHexString(message));
        
        // Initialize return message
        byte[] sendData = null;
        
        // Process message
        RestrictedStatusMessageFromCSD rsm = new RestrictedStatusMessageFromCSD(message);
        if (rsm.isValid) {
            String deviceUidString = Convert.byteArrayToHexString(rsm.deviceUid);
            
            // Check to see if message was unsolicited
            if (rsm.isUnsolicited) {
                UserInterface.printDebugText("Received unsolicited restricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received unsolicited restricted status from " + deviceUidString);
            }
            else {
                UserInterface.printDebugText("Received solicited restricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received solicited restricted status from " + deviceUidString);
            }
            
            // Create new database entry if needed
            int index = CSDRegistry.getIndexOf(rsm.deviceUid);
            if (index == -1) {
                CSDRegistry.add(new CSD(rsm.deviceUid));
                index = CSDRegistry.getIndexOf(rsm.deviceUid);
                UserInterface.printDebugText("New UID " + deviceUidString + " added to the device registry");
            }
            
            // Update device registry
            CSDRegistry.setNadUid(index, nadUid);
            
            // Validate ascension number
            byte[] modifiedReceiveAscensionNumber = new byte[8];
            System.arraycopy(rsm.ascensionNumber, 0, modifiedReceiveAscensionNumber, 4, 4);
            long receiveAscensionNumber = ByteBuffer.wrap(modifiedReceiveAscensionNumber).getLong();
            long lastReceiveAscensionNumber = CSDRegistry.getReceiveAscensionNumber(index);
            if (receiveAscensionNumber > lastReceiveAscensionNumber) {
                // Check for skipped messages
                if (receiveAscensionNumber > lastReceiveAscensionNumber + 1) {
                    UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                    Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                }
                
                // Update device registry
                CSDRegistry.setDeviceType(index, rsm.deviceType);
                CSDRegistry.setReceiveAscensionNumber(index, receiveAscensionNumber);
                CSDRegistry.setRestrictedErrorSection(index, rsm.restrictedErrorSection);
                CSDRegistry.setDeviceOperatingMode(index, rsm.deviceOperatingMode);
                CSDRegistry.setSensorOperatingMode(index, rsm.sensorOperatingMode);
                CSDRegistry.setRestrictedStatusBits(index, rsm.restrictedStatusBits);
                CSDRegistry.setRestrictedErrorBits(index, rsm.restrictedErrorBits);
                CSDRegistry.setSensorErrorBits(index, rsm.sensorErrorBits);
                CSDRegistry.setMechanicalSealId(index, Convert.byteArrayToASCII(rsm.mechanicalSealId));
                byte[] modifiedConveyanceId = new byte[15];
                System.arraycopy(rsm.conveyanceId, 1, modifiedConveyanceId, 0, modifiedConveyanceId.length);
                CSDRegistry.setConveyanceID(index, Convert.byteArrayToASCII(modifiedConveyanceId));
                CSDRegistry.setManifest(index, Convert.byteArrayToASCII(rsm.manifest));
                CSDRegistry.setAlarmStatus(index, rsm.alarmStatus);
                CSDRegistry.setDoorStatus(index, rsm.doorStatus);
                CSDRegistry.setReserved(index, rsm.reserved);
                
                // Check to see if a command is already pending
                boolean commandPending = CSDRegistry.getCommandPending(index);
                if (rsm.isUnsolicited) {
                    if (commandPending) {
                        UserInterface.printDebugText("Outstanding command to " + deviceUidString + " has been preempted");
                        UserInterface.printEcocLabel("Outstanding command to " + deviceUidString + " has been preempted");
                        Syslog.write(Syslog.ALERT, "Outstanding command to " + deviceUidString + " has been preempted");
                        CSDRegistry.setCommandPending(index, false);
                        CSDRegistry.getTimer(index).cancel();
                        UserInterface.refreshEcocButton();
                    }
                    UserInterface.printDebugText("Sending ACK to " + deviceUidString + "...");
                    CSDRegistry.setSendAscensionNumber(index, CSDRegistry.getSendAscensionNumber(index) + 1);
                    byte[] params = new byte[1];
                    params[0] = rsm.ascensionNumber[3];
                    sendData = makeRestrictedCommand(rsm.deviceUid, (byte)0x01, params);
                    CSDRegistry.setLastCommand(index, sendData);
                }
                else { 
                    byte[] sendAscensionNumberBytes = ByteBuffer.allocate(8).putLong(CSDRegistry.getSendAscensionNumber(index)).array();
                    if (commandPending && (rsm.ackAscensionNumber == sendAscensionNumberBytes[7])) {
                        UserInterface.printDebugText("Message from " + deviceUidString + " is a valid response to the previous command");
                        UserInterface.printEcocLabel("Message from " + deviceUidString + " is a valid response to the previous command");
                        Syslog.write(Syslog.NOTICE, "Message from " + deviceUidString + " is a valid response to the previous command");
                        CSDRegistry.setCommandPending(index, false);
                        CSDRegistry.getTimer(index).cancel();
                        UserInterface.refreshEcocButton();
                    }
                    else if (!commandPending) {
                        UserInterface.printDebugText("Was not expecting solicited status from " + deviceUidString);
                        Syslog.write(Syslog.WARNING, "Was not expecting solicited status from " + deviceUidString);
                    }
                    else {
                        UserInterface.printDebugText("ACK ascension number check failed on message from " + deviceUidString);
                        UserInterface.printDebugText("rsm.ackAscensionNumber: " + Convert.byteToHexString(rsm.ackAscensionNumber));
                        UserInterface.printDebugText("sendAscensionNumberBytes[7]: " + Convert.byteToHexString(sendAscensionNumberBytes[7]));
                        Syslog.write(Syslog.ERROR, "ACK ascension number check failed on message from " + deviceUidString);
                    }
                }
            
                // Refresh device table
                UserInterface.updateCsdTable(index);
            }
            // Duplicate ascension case
            else if (receiveAscensionNumber == lastReceiveAscensionNumber) {
                if (rsm.isUnsolicited) {
                    UserInterface.printDebugText("Resending ACK to " + deviceUidString + "...");
                    sendData = CSDRegistry.getLastCommand(index);
                }
                else {
                    UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                    Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                }
            }
            // Invalid ascension case
            else {
                UserInterface.printDebugText("Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
                Syslog.write(Syslog.WARNING, "Expecting ascension " + (lastReceiveAscensionNumber + 1) + " from " + deviceUidString + ", received " + receiveAscensionNumber);
            }
        }
        
        return sendData;
    }
    
    static synchronized byte[] parseUnrestrictedStatusMessage(byte[] nadUid, byte[] message) {
        // Initialize return message
        byte[] sendData = null;
        
        // Process message
        UnrestrictedStatusMessageFromECoC usm = new UnrestrictedStatusMessageFromECoC(message);
        if (usm.isValid) {
            String deviceUidString = Convert.byteArrayToHexString(usm.deviceUid);
            
            // Check to see if message was unsolicited
            if (usm.isUnsolicited) {
                UserInterface.printDebugText("Received unsolicited unrestricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received unsolicited unrestricted status from " + deviceUidString);
            }
            else {
                UserInterface.printDebugText("Received solicited unrestricted status from " + deviceUidString);
                Syslog.write(Syslog.NOTICE, "Received solicited unrestricted status from " + deviceUidString);
            }
            
            // Create new database entry if needed
            int index = ECoCRegistry.getIndexOf(usm.deviceUid);
            if (index == -1) {
                ECoCRegistry.add(new ECoC(usm.deviceUid));
                index = ECoCRegistry.getIndexOf(usm.deviceUid);
                UserInterface.printDebugText("New UID " + deviceUidString + " added to the device registry");
            }
        
            // Update device registry
            ECoCRegistry.setDeviceType(index, usm.deviceType);
            ECoCRegistry.setNadUid(index, nadUid);
            
            // Check to see if a command is already pending
            boolean commandPending = ECoCRegistry.getCommandPending(index);
            if (commandPending) {
                if (usm.isUnsolicited) {
                    UserInterface.printDebugText("Outstanding command to " + deviceUidString + " has been preempted");
                    UserInterface.printEcocLabel("Outstanding command to " + deviceUidString + " has been preempted");
                    Syslog.write(Syslog.ALERT, "Outstanding command to " + deviceUidString + " has been preempted");
                }
                else {
                    UserInterface.printDebugText("Message from " + deviceUidString + " is a valid response to the previous command");
                    UserInterface.printEcocLabel("Message from " + deviceUidString + " is a valid response to the previous command");
                    Syslog.write(Syslog.NOTICE, "Message from " + deviceUidString + " is a valid response to the previous command");
                }
                ECoCRegistry.setCommandPending(index, false);
                ECoCRegistry.getTimer(index).cancel();
                UserInterface.refreshEcocButton();
            }
            
            // See if new LTK is needed
            if (usm.noLtk) {
                UserInterface.printDebugText("Issuing new LTK to " + deviceUidString + "...");
                byte[] ltk = new byte[16];
                new Random().nextBytes(ltk);
                ECoCRegistry.setLtk(index, ltk);
                ECoCRegistry.setSendAscensionNumber(index, 0);
                ECoCRegistry.setReceiveAscensionNumber(index, 0);
                UserInterface.printDebugText("LTK: " + Convert.byteArrayToHexString(ltk));
                sendData = makeRekeyMessage(usm.deviceUid, ltk);
                ECoCRegistry.setLastCommand(index, sendData);
            }
        
            // Refresh device table
            UserInterface.updateEcocTable(index);
        }
        
        return sendData;
    }
    
    static byte[] makeUnrestrictedCommand(byte[] destinationUID, byte opcode) {
        // Preamble
        byte[] preamble = new byte[19];
        preamble[0] = 0x01;
        preamble[1] = 0x00;
        preamble[2] = 0x0B;
        System.arraycopy(Configure.getUID(), 0, preamble, 3, 8);
        System.arraycopy(destinationUID, 0, preamble, 11, 8);
        
        // Header
        byte[] header = new byte[16];
        header[0] = (byte)0x88;
        header[1] = (byte)0xC0;
        header[2] = 0x02;
        System.arraycopy(Configure.getUID(), 0, header, 3, 8);
        header[11] = 0x02;
        
        // Opcode + checksum + zero pad
        byte[] payload = new byte[2];
        payload[0] = opcode;
        int checksum = opcode;
        for (int i = 0; i < header.length; i++)
            checksum += header[i];
        payload[1] = (byte)(checksum % 256);
        
        // Message
        byte[] message = new byte[preamble.length + header.length + payload.length];
        System.arraycopy(preamble, 0, message, 0, preamble.length);
        System.arraycopy(header, 0, message, preamble.length, header.length);
        System.arraycopy(payload, 0, message, preamble.length + header.length, payload.length);
        
        return message;
    }
    
    static byte[] makeRestrictedCommand(byte[] destinationUID, byte opcode, byte[] params) {
        // Preamble
        byte[] preamble = new byte[19];
        preamble[0] = 0x01;
        preamble[1] = 0x00;
        preamble[2] = 0x0B;
        System.arraycopy(Configure.getUID(), 0, preamble, 3, 8);
        System.arraycopy(destinationUID, 0, preamble, 11, 8);
        
        // Header
        byte[] header = new byte[16];
        header[0] = (byte)0x88;
        header[1] = (byte)0xC1;
        header[2] = (byte)(1 + params.length + 8);
        System.arraycopy(Configure.getUID(), 0, header, 3, 8);
        header[11] = 0x02;
        long sendAscensionNumber = ECoCRegistry.getSendAscensionNumber(ECoCRegistry.getIndexOf(destinationUID));
        byte[] sendAscensionNumberBytes = ByteBuffer.allocate(8).putLong(sendAscensionNumber).array();
        System.arraycopy(sendAscensionNumberBytes, 4, header, 12, 4);
        
        // Body
        byte[] body = new byte[1 + params.length];
        body[0] = opcode;
        System.arraycopy(params, 0, body, 1, params.length);
        
        // Opcode + params + MIC
        //byte[] payload = new byte[1 + params.length + 8];
        //payload[0] = opcode;
        //System.arraycopy(params, 0, payload, 1, params.length);
        
        byte[] payload = new byte[body.length + 8];
        if (Configure.getUseEncryption()) {
            int index = ECoCRegistry.getIndexOf(destinationUID);
            byte[] p1 = new byte[16];
            p1[0] = (byte)0x88;
            System.arraycopy(Configure.getUID(), 0, p1, 3, 8);
            byte[] tck = Encryption.deriveTCK(ECoCRegistry.getLtk(index), p1);
            byte[] nonce = new byte[8];
            System.arraycopy(header, 0, nonce, 0, 3);
            System.arraycopy(header, 11, nonce, 3, 5);
            payload = Encryption.encrypt(tck, 64, nonce, body);
        }
        else {
            System.arraycopy(body, 0, payload, 0, body.length);
        }
            
        
        // Message
        byte[] message = new byte[preamble.length + header.length + payload.length];
        System.arraycopy(preamble, 0, message, 0, preamble.length);
        System.arraycopy(header, 0, message, preamble.length, header.length);
        System.arraycopy(payload, 0, message, preamble.length + header.length, payload.length);
        
        return message;
    }
    
    static byte[] makeHeartbeatResponse() {
        byte[] sendData = new byte[11];
        
        // Revision number (1 byte)
        sendData[0] = 0x01;
        
        // Function code (2 bytes)
        sendData[1] = 0x00;
        sendData[2] = 0x00;
        
        // Source UID (8 bytes)
        byte[] pdcUid = Configure.getUID();
        System.arraycopy(pdcUid, 0, sendData, 3, pdcUid.length);
        
        return sendData;
    }
    
    static byte[] makeRekeyMessage(byte[] destinationUID, byte[] LTK) {
        // Static rekey key
        byte[] RK = {0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
        
        // Preamble
        byte[] preamble = new byte[19];
        preamble[0] = 0x01;
        preamble[1] = 0x00;
        preamble[2] = 0x0B;
        System.arraycopy(Configure.getUID(), 0, preamble, 3, 8);
        System.arraycopy(destinationUID, 0, preamble, 11, 8);
        
        // Header
        byte[] header = new byte[16];
        header[0] = (byte)0x89;
        header[1] = (byte)0xE0;
        header[2] = 0x20;
        System.arraycopy(Configure.getUID(), 0, header, 3, 8);
        header[11] = 0x02;
        byte[] rekeyAscensionNumberBytes = ByteBuffer.allocate(8).putLong(1).array();
        System.arraycopy(rekeyAscensionNumberBytes, 4, header, 12, 4);
        
        // Payload
        byte[] nonce = new byte[8];
        System.arraycopy(header, 0, nonce, 0, 3);
        System.arraycopy(header, 11, nonce, 3, 5);
        byte[] payload = Encryption.encrypt(Encryption.deriveTCK(RK, header), 128, nonce, LTK);
        
        // Message
        byte[] message = new byte[preamble.length + header.length + payload.length];
        System.arraycopy(preamble, 0, message, 0, preamble.length);
        System.arraycopy(header, 0, message, preamble.length, header.length);
        System.arraycopy(payload, 0, message, preamble.length + header.length, payload.length);
        
        return message;
    }
}
