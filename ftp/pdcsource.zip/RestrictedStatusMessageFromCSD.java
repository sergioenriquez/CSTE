/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class RestrictedStatusMessageFromCSD {
    boolean isUnsolicited, isValid;
    byte ackAscensionNumber, alarmStatus, deviceOperatingMode, deviceType, doorStatus, icdRevisionNumber, messageLength,
            messageType, restrictedErrorBits, restrictedErrorSection, restrictedStatusBits, sensorErrorBits, sensorOperatingMode;
    byte[] ascensionNumber, body, conveyanceId, deviceUid, header, manifest, mechanicalSealId, reserved, restrictedDataSection;
    RestrictedStatusMessageFromCSD(byte[] message) {
        // Initialize booleans
        isValid = false;
        
        // Compare message to expected length
        if (message.length == 96) {
            // Extract header
            header = new byte[16];
            System.arraycopy(message, 0, header, 0, header.length);
            
            // Parse header
            deviceType = header[0];
            messageType = header[1];
            messageLength = header[2];
            deviceUid = new byte[8];
            System.arraycopy(header, 3, deviceUid, 0, deviceUid.length);
            icdRevisionNumber = header[11];
            ascensionNumber = new byte[4];
            System.arraycopy(header, 12, ascensionNumber, 0, ascensionNumber.length);
            
            // Extract and decrypt body
            body = new byte[80];
            byte[] payload = new byte[80];
            System.arraycopy(message, header.length, payload, 0, payload.length);
            if (Configure.getUseEncryption()) {
                int index = ECoCRegistry.getIndexOf(deviceUid);
                byte[] p1 = new byte[16];
                p1[0] = (byte)0x88;
                System.arraycopy(Configure.getUID(), 0, p1, 3, 8);
                byte[] ltk = new byte[16];
                if (index != -1)
                    ltk = ECoCRegistry.getLtk(index);
                byte[] tck = Encryption.deriveTCK(ltk, p1);
                byte[] nonce = new byte[8];
                System.arraycopy(header, 0, nonce, 0, 3);
                System.arraycopy(header, 11, nonce, 3, 5);
                byte[] plaintext = Encryption.decrypt(tck, 64, nonce, payload);
                UserInterface.printDebugText("Plaintext: " + Convert.byteArrayToHexString(plaintext));
                System.arraycopy(plaintext, 0, body, 0, plaintext.length);
            }
            else
                System.arraycopy(message, header.length, body, 0, body.length);
            
            // Parse body
            restrictedErrorSection = body[0];
            isUnsolicited = (restrictedErrorSection & 0x02) == 0x02;
            restrictedDataSection = new byte[71];
            System.arraycopy(body, 1, restrictedDataSection, 0, restrictedDataSection.length);
            ackAscensionNumber = restrictedDataSection[0];
            deviceOperatingMode = restrictedDataSection[1];
            sensorOperatingMode = restrictedDataSection[2];
            restrictedStatusBits = restrictedDataSection[3];
            restrictedErrorBits = restrictedDataSection[4];
            sensorErrorBits = restrictedDataSection[5];
            mechanicalSealId = new byte[15];
            System.arraycopy(restrictedDataSection, 6, mechanicalSealId, 0, mechanicalSealId.length);
            conveyanceId = new byte[16];
            System.arraycopy(restrictedDataSection, 21, conveyanceId, 0, conveyanceId.length);
            manifest = new byte[16];
            System.arraycopy(restrictedDataSection, 37, manifest, 0, manifest.length);
            alarmStatus = restrictedDataSection[53];
            doorStatus = restrictedDataSection[54];
            reserved = new byte[16];
            System.arraycopy(restrictedDataSection, 55, reserved, 0, reserved.length);
            
            // Validate message length from header
            if (messageLength != body.length) {
                UserInterface.printDebugText("Message length from header is incorrect. Expecting " + messageLength + ", got " + body.length);
            }
            else
                isValid = true;
        }
        else {
            UserInterface.printDebugText("Incorrect length for restricted status message. Expecting 96, got " + message.length);
            Syslog.write(Syslog.ERROR, "Incorrect length for restricted status message. Expecting 96, got " + message.length);
        }
    }
}
