/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 *
 * @author Anton
 */
public class Syslog {
    static final int EMERGENCY = 0;
    static final int ALERT = 1;
    static final int CRITICAL = 2;
    static final int ERROR = 3;
    static final int WARNING = 4;
    static final int NOTICE = 5;
    static final int INFORMATIONAL = 6;
    static final int DEBUG = 7;
    
    static void write(int priority, String s) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("<");
            sb.append(8 + priority);
            sb.append(">1 ");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            sb.append(sdf.format(new Date()));
            sb.append(" PDC - - - - ");
            sb.append(s);
            byte[] message = sb.toString().getBytes("UTF-8");
            
            DatagramSocket ds = new DatagramSocket();
            InetSocketAddress isa = new InetSocketAddress(InetAddress.getByName(Configure.getSyslogAddress()), Configure.getSyslogPort());
            ds.send(new DatagramPacket(message, message.length, isa));
            ds.close();
        }
        catch (Exception e) {
            // Do nothing
        }
    }
}
