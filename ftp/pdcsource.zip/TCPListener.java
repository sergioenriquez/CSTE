/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Anton
 */
public class TCPListener implements Runnable {
    private static ServerSocket serverSocket = null;
    
    @Override
    public void run() {
        int tcpPort = Configure.getTCPPort();
        byte[] bufferedData = new byte[1024];
        try {
            serverSocket = new ServerSocket(tcpPort);
            UserInterface.printDebugText("Waiting for bytes on TCP/" + tcpPort + "...");
            Socket socket = serverSocket.accept();
            while (true) {
                InputStream inputStream = socket.getInputStream();
                byte[] receiveData = new byte[inputStream.read(bufferedData)];
                System.arraycopy(bufferedData, 0, receiveData, 0, receiveData.length);
                MessageHandler.parseTcp(receiveData, socket);
            }
        }
        catch (Exception e) {
            UserInterface.printDebugText("Restarting TCP listener");
            ThreadController.restartTCPListener();
        }
    }
    
    static void send(byte[] sendData, Socket socket) {
        UserInterface.printDebugText("OUT: " + Convert.byteArrayToHexString(sendData));
        try {
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(sendData);
        }
        catch (Exception e) {
            UserInterface.printDebugText("Exception thrown in TCPListener.send(): " + e);
        }
    }
    
    static void stop() {
        try {
            serverSocket.close();
        }
        catch (Exception e) {
            UserInterface.printDebugText("Exception thrown in TCPListener.stop(): " + e);
        }
    }
}
