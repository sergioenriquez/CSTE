/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.Timer;

/**
 *
 * @author Anton
 */
public class Test {    
    /*void commission() {
        int[] rows = deviceTable.getSelectedRows();
        for (int i = 0; i < rows.length; i++) {
            String uidString = (String)deviceTable.getValueAt(rows[i], UID_COL);
            byte[] uid = Convert.hexStringToByteArray(uidString);
            int index = Database.getIndexOf(uid);
            printDebugText("Sending get status (NOP) command to " + uidString + "...");
            printEcocLabel("Sending get status (NOP) command to " + uidString + "...");
            Database.setSendAscensionNumber(index, Database.getSendAscensionNumber(index) + 1);
            Database.setLastCommand(index, MessageHandler.makeCommand(uid, Opcode.NOP, new byte[0]));
            Database.setCommandPending(index, true);
            Database.setRetryCounter(index, 0);
            Timer timer = new Timer();
            timer.schedule(new CommandTask(index), 0, 2000);
            Database.setTimer(index, timer);
            refreshEcocButton();
        }
    }                                    

    private void getRestrictedStatusButtonActionPerformed(java.awt.event.ActionEvent evt) {                                          
        int[] rows = deviceTable.getSelectedRows();
        for (int i = 0; i < rows.length; i++) {
            String uidString = (String)deviceTable.getValueAt(rows[i], UID_COL);
            byte[] uid = Convert.hexStringToByteArray(uidString);
            int index = Database.getIndexOf(uid);
            byte[] params = new byte[16];
            try {
                String conveyanceIDString = JOptionPane.showInputDialog(this.getParent(), "Enter new conveyance ID as a 15 character string:", "Change conveyance ID for " + uidString, JOptionPane.QUESTION_MESSAGE);
                byte[] conveyanceID = conveyanceIDString.getBytes("US-ASCII");
                System.arraycopy(conveyanceID, 0, params, 1, Math.min(conveyanceID.length, 15));
            }
            catch (Exception e) {
                printDebugText("Unrecognizable conveyance ID. Are you sure that is ASCII?");
            }
            printDebugText("Sending commission (CWT) command to " + uidString + "...");
            printEcocLabel("Sending commission (CWT) command to " + uidString + "...");
            Database.setSendAscensionNumber(index, Database.getSendAscensionNumber(index) + 1);
            Database.setLastCommand(index, MessageHandler.makeCommand(uid, Opcode.CWT, params));
            Database.setCommandPending(index, true);
            Database.setRetryCounter(index, 0);
            Timer timer = new Timer();
            timer.schedule(new CommandTask(index), 0, 2000);
            Database.setTimer(index, timer);
            refreshEcocButton();
        }
    }*/
    
    static void testTimer() {
        Timer timer = new Timer();
        timer.schedule(new IntervalTask(0), 0, 1000);
        UserInterface.printDebugText("Timer interval set for 1 second.");
        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            UserInterface.printDebugText("Thread was interrupted.");
        }
        timer.cancel();
        UserInterface.printDebugText("Timer canceled.");
        timer = new Timer();
        timer.schedule(new IntervalTask(0), 0, 5000);
        UserInterface.printDebugText("Timer interval set for 5 seconds.");
    }
}
