/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class ThreadController {
    static void startTCPListener() {
        TCPListener tcpListener = new TCPListener();
        new Thread(tcpListener).start();
    }
    
    static void startUDPListener() {
        UDPListener udpListener = new UDPListener();
        new Thread(udpListener).start();
    }
    
    static void restartTCPListener() {
        TCPListener.stop();
        startTCPListener();
    }
    
    static void restartUDPListener() {
        UDPListener.stop();
        startUDPListener();
    }
    
    static void stopUDPListener() {
        UDPListener.stop();
    }
}
