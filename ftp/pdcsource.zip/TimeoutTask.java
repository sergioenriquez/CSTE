/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.util.TimerTask;

/**
 *
 * @author Anton
 */
public class TimeoutTask extends TimerTask {
    // Constructor
    private int index;
    public TimeoutTask(int index) {
        this.index = index;
    }
    
    @Override
    public void run() {
        String uidString = Convert.byteArrayToHexString(ECoCRegistry.getDeviceUid(index));
        UserInterface.printDebugText("Timed out waiting for next event log record from " + uidString + ".");
        UserInterface.printEcocLabel("Timed out waiting for next event log record from " + uidString + ".");
        ECoCRegistry.setCommandPending(index, false);
        //DeviceRegistry.setSendAscensionNumber(index, ECoCRegistry.getSendAscensionNumber(index) - 1);
        cancel();
    }
}
