/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;

/**
 *
 * @author Anton
 */
public class UDPListener implements Runnable {
    private static DatagramSocket datagramSocket = null;
    
    @Override
    public void run() {
        int udpPort = Configure.getUDPPort();
        byte[] bufferedData = new byte[1024];
        DatagramPacket datagramPacket = new DatagramPacket(bufferedData, bufferedData.length);
        try {
            datagramSocket = new DatagramSocket(udpPort);
            UserInterface.printDebugText("Waiting for bytes on UDP/" + udpPort + "...");
            while (true) {
                datagramSocket.receive(datagramPacket);
                byte[] receiveData = new byte[datagramPacket.getLength()];
                System.arraycopy(bufferedData, 0, receiveData, 0, receiveData.length);
                MessageHandler.parseUdp(receiveData, datagramPacket.getSocketAddress());
            }
        }
        catch (Exception e) {
            UserInterface.printDebugText("Restarting UDP listener");
            ThreadController.restartUDPListener();
        }
    }
    
    static void send(byte[] sendData, SocketAddress sa) {
        UserInterface.printDebugText("OUT: " + Convert.byteArrayToHexString(sendData));
        try {
            datagramSocket.send(new DatagramPacket(sendData, sendData.length, sa));
        }
        catch (Exception e) {
            UserInterface.printDebugText("Exception thrown in UDPListener.send(): " + e);
        }
    }
    
    static void stop() {
        datagramSocket.close();
    }
}
