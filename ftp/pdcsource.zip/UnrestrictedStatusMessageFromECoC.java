/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package portabledatacenter;

/**
 *
 * @author Anton
 */
public class UnrestrictedStatusMessageFromECoC {
    boolean isUnsolicited, isValid, noLtk;
    byte checksum, deviceSection, deviceType, encryptionErrorBits, icdRevisionNumber, messageLength, messageType;
    byte[] ascensionNumber, body, deviceUid, errorSection, header, rekeyCounter;
    UnrestrictedStatusMessageFromECoC(byte[] message) {
        // Initialize booleans
        isValid = false;
        
        // Compare message length to expected length
        if (message.length == 32) {
            // Extract header
            header = new byte[16];
            System.arraycopy(message, 0, header, 0, header.length);
            
            // Parse header
            deviceType = header[0];
            messageType = header[1];
            messageLength = header[2];
            deviceUid = new byte[8];
            System.arraycopy(header, 3, deviceUid, 0, deviceUid.length);
            icdRevisionNumber = header[11];
            ascensionNumber = new byte[4];
            System.arraycopy(header, 12, ascensionNumber, 0, ascensionNumber.length);
            
            // Extract body
            body = new byte[16];
            System.arraycopy(message, header.length, body, 0, body.length);
            
            // Parse body
            deviceSection = body[0];
            isUnsolicited = (deviceSection & 0x02) == 0x02;
            errorSection = new byte[15];
            System.arraycopy(body, 1, errorSection, 0, errorSection.length);
            encryptionErrorBits = errorSection[0];
            noLtk = (encryptionErrorBits & 0x80) == 0x80;
            rekeyCounter = new byte[4];
            System.arraycopy(errorSection, 1, rekeyCounter, 0, rekeyCounter.length);
            checksum = body[15];
            
            // Validate message length from header and checksum
            int computedChecksum = 0;
            for (int i = 0; i < 31; i++)
                computedChecksum += message[i];
            computedChecksum %= 256;
            if (messageLength != body.length) {
                UserInterface.printDebugText("Message length from header is incorrect. Expecting " + messageLength + ", got " + body.length);
            }
            else if (checksum != (byte)computedChecksum) {
                UserInterface.printDebugText("Checksum error: " + Convert.byteArrayToHexString(message));
                UserInterface.printDebugText("Expecting " + Convert.byteToHexString((byte)computedChecksum) + ", received " + Convert.byteToHexString((byte)checksum));
            }
            else
                isValid = true;
        }
        else {
            UserInterface.printDebugText("Incorrect length for unrestricted status message. Expecting 32, got " + message.length);
            Syslog.write(Syslog.ERROR, "Incorrect length for unrestricted status message. Expecting 32, got " + message.length);
        }
    }
}